# Gmail API Integration and Email Processing Verification

## Overview

This document outlines the verification process for Gmail API integration, email reading, parsing, and categorization functionality for the PookAi application. The goal is to ensure that the application can successfully authenticate with Gmail, retrieve emails, parse them correctly, and organize them into appropriate buckets based on sender domains and user preferences.

## Gmail API Authentication Flow

### Authentication Process

1. **OAuth 2.0 Flow**:
   - User initiates Gmail connection through frontend
   - Application redirects to Google OAuth consent screen
   - User grants permissions for Gmail access
   - Google returns authorization code to callback URL
   - Backend exchanges code for access and refresh tokens
   - Tokens are securely stored in database

2. **Required Scopes**:
   ```
   https://www.googleapis.com/auth/gmail.readonly
   ```

3. **Token Management**:
   - Access tokens expire after 1 hour
   - Refresh tokens must be used to obtain new access tokens
   - Implement token refresh logic in API requests
   - Handle token revocation scenarios

### Authentication Verification Steps

```typescript
// Test authentication flow with the gmail-inbox library
import { Inbox } from 'gmail-inbox';

async function verifyGmailAuthentication(accessToken: string, refreshToken: string) {
  try {
    // Initialize inbox with tokens
    const inbox = new Inbox({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      redirectUri: process.env.GOOGLE_REDIRECT_URI,
      accessToken,
      refreshToken
    });
    
    // Attempt to authenticate
    const authenticated = await inbox.authenticateAccount();
    console.log('Authentication successful:', authenticated);
    
    // Test fetching latest messages
    const messages = await inbox.getLatestMessages(5);
    console.log('Successfully retrieved messages:', messages.length);
    
    return {
      success: true,
      authenticated,
      messageCount: messages.length,
      firstMessage: messages[0] ? {
        from: messages[0].from,
        subject: messages[0].subject,
        date: messages[0].receivedOn
      } : null
    };
  } catch (error) {
    console.error('Gmail authentication verification failed:', error);
    return {
      success: false,
      error: error.message,
      details: error.stack
    };
  }
}
```

## Email Retrieval and Parsing

### Email Retrieval Process

1. **Fetching Messages**:
   - Retrieve messages in batches to avoid quota limits
   - Start with most recent messages (last 30 days)
   - Implement pagination for large inboxes
   - Track progress for long-running operations

2. **Message Selection**:
   - Focus on primary inbox messages
   - Exclude spam, trash, and draft folders
   - Include unread and read messages
   - Prioritize messages with attachments or from frequent senders

3. **Handling Rate Limits**:
   - Gmail API quota: 1 billion units/day per project
   - Each message read costs ~5-20 units
   - Implement exponential backoff for 429 responses
   - Schedule batch operations during off-peak hours

### Email Parsing Verification Steps

```typescript
// Test email parsing functionality
async function verifyEmailParsing(inbox: any, messageCount: number = 20) {
  try {
    // Get messages
    const messages = await inbox.getLatestMessages(messageCount);
    
    // Parse and analyze messages
    const parsedMessages = messages.map(message => {
      // Extract sender information
      const senderMatch = message.from.match(/([^<]+)<([^>]+)>/);
      const senderName = senderMatch ? senderMatch[1].trim() : null;
      const senderEmail = senderMatch ? senderMatch[2].trim() : message.from;
      
      // Extract domain
      const domain = senderEmail.split('@')[1];
      
      return {
        messageId: message.messageId,
        threadId: message.threadId,
        sender: {
          name: senderName,
          email: senderEmail,
          domain
        },
        subject: message.subject,
        receivedOn: message.receivedOn,
        snippet: message.snippet,
        isRead: !message.labelIds.includes('UNREAD'),
        hasAttachments: message.labelIds.includes('HAS_ATTACHMENT')
      };
    });
    
    // Analyze parsing results
    const domains = {};
    parsedMessages.forEach(msg => {
      const domain = msg.sender.domain;
      domains[domain] = (domains[domain] || 0) + 1;
    });
    
    // Get top domains
    const topDomains = Object.entries(domains)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([domain, count]) => ({ domain, count }));
    
    return {
      success: true,
      totalParsed: parsedMessages.length,
      uniqueDomains: Object.keys(domains).length,
      topDomains,
      sampleMessages: parsedMessages.slice(0, 3)
    };
  } catch (error) {
    console.error('Email parsing verification failed:', error);
    return {
      success: false,
      error: error.message,
      details: error.stack
    };
  }
}
```

## Email Categorization and Bucketing

### Categorization Process

1. **Domain-Based Bucketing**:
   - Group emails by sender domain
   - Calculate frequency and recency metrics
   - Identify newsletter domains vs. transactional domains
   - Detect personal vs. business communications

2. **Sender Classification**:
   - Categorize senders into predefined buckets:
     - `call-me`: High priority, requires immediate attention
     - `remind-me`: Medium priority, needs follow-up
     - `newsletter`: Regular updates, can be summarized
     - `ignore`: Low priority, can be skipped
     - `spam`: Unwanted communications

3. **Machine Learning Assistance**:
   - Use content analysis to suggest categories
   - Learn from user preferences over time
   - Identify patterns in user's email organization

### Categorization Verification Steps

```typescript
// Test email categorization functionality
async function verifyEmailCategorization(parsedMessages: any[]) {
  try {
    // Define category detection rules
    const categoryRules = {
      'call-me': (msg) => {
        const urgentTerms = ['urgent', 'important', 'action required', 'payment', 'invoice', 'deadline'];
        return urgentTerms.some(term => 
          msg.subject.toLowerCase().includes(term) || 
          (msg.snippet && msg.snippet.toLowerCase().includes(term))
        );
      },
      'remind-me': (msg) => {
        const reminderTerms = ['reminder', 'don\'t forget', 'upcoming', 'scheduled', 'meeting'];
        return reminderTerms.some(term => 
          msg.subject.toLowerCase().includes(term) || 
          (msg.snippet && msg.snippet.toLowerCase().includes(term))
        );
      },
      'newsletter': (msg) => {
        // Check for newsletter domains
        const newsletterDomains = ['newsletter', 'updates', 'digest', 'weekly', 'daily'];
        const domain = msg.sender.domain.toLowerCase();
        
        // Check for newsletter-like subjects
        const newsletterSubjects = ['newsletter', 'weekly', 'update', 'digest', 'roundup'];
        
        return newsletterDomains.some(term => domain.includes(term)) ||
               newsletterSubjects.some(term => msg.subject.toLowerCase().includes(term));
      }
    };
    
    // Categorize messages
    const categorizedMessages = parsedMessages.map(msg => {
      let category = 'ignore'; // Default category
      
      // Check each category rule
      for (const [cat, rule] of Object.entries(categoryRules)) {
        if (rule(msg)) {
          category = cat;
          break;
        }
      }
      
      return {
        ...msg,
        suggestedCategory: category
      };
    });
    
    // Analyze categorization results
    const categoryCounts = {};
    categorizedMessages.forEach(msg => {
      const category = msg.suggestedCategory;
      categoryCounts[category] = (categoryCounts[category] || 0) + 1;
    });
    
    // Group by domain and category
    const domainCategories = {};
    categorizedMessages.forEach(msg => {
      const domain = msg.sender.domain;
      if (!domainCategories[domain]) {
        domainCategories[domain] = {};
      }
      
      const category = msg.suggestedCategory;
      domainCategories[domain][category] = (domainCategories[domain][category] || 0) + 1;
    });
    
    return {
      success: true,
      categoryCounts,
      domainCategories,
      sampleCategorized: categorizedMessages.slice(0, 5).map(msg => ({
        sender: msg.sender.email,
        subject: msg.subject,
        category: msg.suggestedCategory
      }))
    };
  } catch (error) {
    console.error('Email categorization verification failed:', error);
    return {
      success: false,
      error: error.message,
      details: error.stack
    };
  }
}
```

## End-to-End Verification Script

```typescript
// Complete verification script
import { Inbox } from 'gmail-inbox';
import dotenv from 'dotenv';
import { EmailIntegration, EmailSender, EmailMetadata, Domain } from '../models';
import { sequelize } from '../config/database';

dotenv.config();

async function verifyGmailIntegration(userId: string) {
  console.log('Starting Gmail integration verification...');
  
  try {
    // 1. Get user's Gmail integration
    const integration = await EmailIntegration.findOne({
      where: {
        user_id: userId,
        provider: 'gmail',
        status: 'connected'
      }
    });
    
    if (!integration) {
      throw new Error('No active Gmail integration found for user');
    }
    
    console.log('Found Gmail integration for user:', integration.email);
    
    // 2. Initialize inbox with tokens
    const inbox = new Inbox({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      redirectUri: process.env.GOOGLE_REDIRECT_URI,
      accessToken: integration.access_token,
      refreshToken: integration.refresh_token
    });
    
    // 3. Authenticate
    const authenticated = await inbox.authenticateAccount();
    console.log('Authentication successful:', authenticated);
    
    // 4. Retrieve and parse messages
    const messageCount = 50; // Adjust based on testing needs
    console.log(`Retrieving ${messageCount} messages...`);
    const messages = await inbox.getLatestMessages(messageCount);
    console.log(`Retrieved ${messages.length} messages`);
    
    // 5. Parse messages
    console.log('Parsing messages...');
    const parsedMessages = messages.map(message => {
      // Extract sender information
      const senderMatch = message.from.match(/([^<]+)<([^>]+)>/);
      const senderName = senderMatch ? senderMatch[1].trim() : null;
      const senderEmail = senderMatch ? senderMatch[2].trim() : message.from;
      
      // Extract domain
      const domain = senderEmail.split('@')[1];
      
      return {
        messageId: message.messageId,
        threadId: message.threadId,
        sender: {
          name: senderName,
          email: senderEmail,
          domain
        },
        subject: message.subject,
        receivedOn: message.receivedOn,
        snippet: message.snippet,
        isRead: !message.labelIds.includes('UNREAD'),
        hasAttachments: message.labelIds.includes('HAS_ATTACHMENT')
      };
    });
    
    // 6. Categorize messages
    console.log('Categorizing messages...');
    const categoryRules = {
      'call-me': (msg) => {
        const urgentTerms = ['urgent', 'important', 'action required', 'payment', 'invoice', 'deadline'];
        return urgentTerms.some(term => 
          msg.subject.toLowerCase().includes(term) || 
          (msg.snippet && msg.snippet.toLowerCase().includes(term))
        );
      },
      'remind-me': (msg) => {
        const reminderTerms = ['reminder', 'don\'t forget', 'upcoming', 'scheduled', 'meeting'];
        return reminderTerms.some(term => 
          msg.subject.toLowerCase().includes(term) || 
          (msg.snippet && msg.snippet.toLowerCase().includes(term))
        );
      },
      'newsletter': (msg) => {
        // Check for newsletter domains
        const newsletterDomains = ['newsletter', 'updates', 'digest', 'weekly', 'daily'];
        const domain = msg.sender.domain.toLowerCase();
        
        // Check for newsletter-like subjects
        const newsletterSubjects = ['newsletter', 'weekly', 'update', 'digest', 'roundup'];
        
        return newsletterDomains.some(term => domain.includes(term)) ||
               newsletterSubjects.some(term => msg.subject.toLowerCase().includes(term));
      }
    };
    
    const categorizedMessages = parsedMessages.map(msg => {
      let category = 'ignore'; // Default category
      
      // Check each category rule
      for (const [cat, rule] of Object.entries(categoryRules)) {
        if (rule(msg)) {
          category = cat;
          break;
        }
      }
      
      return {
        ...msg,
        suggestedCategory: category
      };
    });
    
    // 7. Save to database (test transaction)
    console.log('Testing database operations...');
    
    // Use transaction to prevent partial saves
    const transaction = await sequelize.transaction();
    
    try {
      // Track domains and senders
      const domains = {};
      const senders = {};
      
      // Process each message
      for (const msg of categorizedMessages.slice(0, 10)) { // Limit to 10 for testing
        const { sender, suggestedCategory } = msg;
        
        // Check if domain exists
        let domain = domains[sender.domain];
        if (!domain) {
          // Find or create domain
          const [domainRecord] = await Domain.findOrCreate({
            where: {
              user_id: userId,
              domain_name: sender.domain
            },
            defaults: {
              email_count: 1,
              primary_category: suggestedCategory
            },
            transaction
          });
          
          domains[sender.domain] = domainRecord;
          domain = domainRecord;
        } else {
          // Update domain count
          await domain.increment('email_count', { transaction });
        }
        
        // Check if sender exists
        let senderKey = `${sender.email}`;
        if (!senders[senderKey]) {
          // Find or create sender
          const [senderRecord] = await EmailSender.findOrCreate({
            where: {
              user_id: userId,
              email: sender.email
            },
            defaults: {
              name: sender.name,
              domain: sender.domain,
              category: suggestedCategory,
              email_count: 1,
              latest_subject: msg.subject,
              latest_date: msg.receivedOn,
              latest_preview: msg.snippet
            },
            transaction
          });
          
          senders[senderKey] = senderRecord;
        } else {
          // Update sender
          await senders[senderKey].update({
            email_count: senders[senderKey].email_count + 1,
            latest_subject: msg.subject,
            latest_date: msg.receivedOn,
            latest_preview: msg.snippet
          }, { transaction });
        }
        
        // Create email metadata
        await EmailMetadata.create({
          user_id: userId,
          message_id: msg.messageId,
          thread_id: msg.threadId,
          sender_id: senders[senderKey].id,
          subject: msg.subject,
          received_at: msg.receivedOn,
          snippet: msg.snippet,
          is_read: msg.isRead,
          has_attachments: msg.hasAttachments
        }, { transaction });
      }
      
      // Commit transaction
      await transaction.commit();
      console.log('Database operations successful');
    } catch (error) {
      // Rollback transaction on error
      await transaction.rollback();
      throw error;
    }
    
    // 8. Generate verification report
    const domainCount = Object.keys(domains).length;
    const senderCount = Object.keys(senders).length;
    
    const categoryCounts = {};
    categorizedMessages.forEach(msg => {
      const category = msg.suggestedCategory;
      categoryCounts[category] = (categoryCounts[category] || 0) + 1;
    });
    
    return {
      success: true,
      authentication: {
        status: 'connected',
        email: integration.email
      },
      messages: {
        retrieved: messages.length,
        parsed: parsedMessages.length
      },
      categorization: {
        categories: categoryCounts
      },
      database: {
        domains: domainCount,
        senders: senderCount,
        emails: Math.min(10, categorizedMessages.length) // We limited to 10 in the test
      },
      sampleData: {
        domains: Object.keys(domains).slice(0, 5),
        senders: Object.values(senders).slice(0, 5).map(s => ({
          name: s.name,
          email: s.email,
          category: s.category
        }))
      }
    };
  } catch (error) {
    console.error('Gmail integration verification failed:', error);
    return {
      success: false,
      error: error.message,
      details: error.stack
    };
  }
}

// Execute verification (would be called from API endpoint or CLI)
// verifyGmailIntegration('user123').then(console.log).catch(console.error);
```

## Verification Checklist

### Authentication
- [ ] OAuth flow completes successfully
- [ ] Access tokens are stored securely
- [ ] Refresh tokens work correctly
- [ ] Token expiration is handled properly
- [ ] Revoked access is detected and reported

### Email Retrieval
- [ ] Messages are retrieved correctly
- [ ] Pagination works for large inboxes
- [ ] Rate limits are respected
- [ ] Error handling is robust
- [ ] Progress tracking is accurate

### Email Parsing
- [ ] Sender information is extracted correctly
- [ ] Domains are identified properly
- [ ] Subject and content are preserved
- [ ] Metadata (read status, attachments) is captured
- [ ] Special characters and encodings are handled

### Email Categorization
- [ ] Domain-based bucketing works correctly
- [ ] Sender classification is accurate
- [ ] Category suggestions are reasonable
- [ ] User preferences are respected
- [ ] Edge cases are handled properly

### Database Operations
- [ ] Domains are created and updated correctly
- [ ] Senders are created and updated correctly
- [ ] Email metadata is stored properly
- [ ] Transactions ensure data integrity
- [ ] Duplicate handling works correctly

## Common Issues and Solutions

### Authentication Issues
- **Invalid Credentials**: Ensure client ID and secret are correct
- **Expired Tokens**: Implement automatic token refresh
- **Revoked Access**: Prompt user to re-authenticate
- **Insufficient Permissions**: Request correct scopes during OAuth

### API Quota Issues
- **Rate Limiting**: Implement exponential backoff
- **Daily Quota**: Batch operations and prioritize important emails
- **User Quota**: Limit frequency of inbox scans
- **Concurrent Requests**: Queue operations to avoid parallel requests

### Data Processing Issues
- **Malformed Emails**: Handle edge cases in email format
- **Large Attachments**: Skip or limit attachment processing
- **Special Characters**: Ensure proper encoding handling
- **Missing Fields**: Provide defaults for null or undefined values

### Database Issues
- **Concurrent Updates**: Use transactions for atomic operations
- **Duplicate Records**: Implement proper uniqueness constraints
- **Large Datasets**: Implement pagination and batching
- **Orphaned Records**: Use foreign keys and cascading deletes

## Next Steps

1. **Integration Testing**:
   - Test end-to-end flow with real Gmail accounts
   - Verify all components work together correctly
   - Measure performance and optimize as needed

2. **Error Handling Improvements**:
   - Add more robust error recovery
   - Implement retry mechanisms
   - Add detailed logging for troubleshooting

3. **Performance Optimization**:
   - Identify bottlenecks in processing
   - Implement caching where appropriate
   - Optimize database queries and indexes

4. **User Experience Enhancements**:
   - Add progress indicators for long operations
   - Improve category suggestions based on user feedback
   - Implement incremental updates for efficiency
