# PookAi Database Schema and Models Design

## Overview

This document outlines the database schema and models required to support the PookAi backend, focusing on email categorization, sender management, and voice call features. The schema is designed to efficiently store and retrieve data for the API endpoints defined in the API Endpoints Design document.

## Database Schema

### Users Table

```sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  timezone VARCHAR(50) DEFAULT 'UTC',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

**TypeScript Model:**
```typescript
interface User {
  id: string;
  email: string;
  name: string;
  timezone: string;
  created_at: Date;
  updated_at: Date;
}
```

**Purpose:**
- Store user authentication and profile information
- Track user timezone for call scheduling
- Maintain audit trail with timestamps

### EmailIntegrations Table

```sql
CREATE TABLE email_integrations (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  provider VARCHAR(50) NOT NULL, -- 'gmail', 'outlook', etc.
  email VARCHAR(255) NOT NULL,
  access_token TEXT NOT NULL,
  refresh_token TEXT NOT NULL,
  token_expiry TIMESTAMP NOT NULL,
  scopes TEXT[] NOT NULL,
  last_sync TIMESTAMP,
  status VARCHAR(50) DEFAULT 'connected', -- 'connected', 'disconnected', 'error'
  error_message TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, provider, email)
);
```

**TypeScript Model:**
```typescript
interface EmailIntegration {
  id: string;
  user_id: string;
  provider: 'gmail' | 'outlook' | string;
  email: string;
  access_token: string;
  refresh_token: string;
  token_expiry: Date;
  scopes: string[];
  last_sync: Date | null;
  status: 'connected' | 'disconnected' | 'error';
  error_message: string | null;
  created_at: Date;
  updated_at: Date;
}
```

**Purpose:**
- Store OAuth tokens securely for Gmail API access
- Track token expiry for automatic refresh
- Monitor integration health and sync status
- Support multiple email providers in the future

### EmailSenders Table

```sql
CREATE TABLE email_senders (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(255),
  email VARCHAR(255) NOT NULL,
  domain VARCHAR(255) NOT NULL,
  category VARCHAR(50) DEFAULT 'unassigned', -- 'call-me', 'remind-me', 'keep-quiet', 'why-did-i-signup', 'dont-tell-anyone', 'unassigned'
  sender_type VARCHAR(50), -- 'newsletter', 'tool', 'meeting', 'promotional', 'personal'
  email_count INTEGER DEFAULT 0,
  latest_subject TEXT,
  latest_date TIMESTAMP,
  latest_preview TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, email)
);

CREATE INDEX idx_email_senders_user_category ON email_senders(user_id, category);
CREATE INDEX idx_email_senders_domain ON email_senders(domain);
```

**TypeScript Model:**
```typescript
interface EmailSender {
  id: string;
  user_id: string;
  name: string | null;
  email: string;
  domain: string;
  category: 'call-me' | 'remind-me' | 'keep-quiet' | 'why-did-i-signup' | 'dont-tell-anyone' | 'unassigned';
  sender_type: 'newsletter' | 'tool' | 'meeting' | 'promotional' | 'personal' | null;
  email_count: number;
  latest_subject: string | null;
  latest_date: Date | null;
  latest_preview: string | null;
  avatar_url: string | null;
  created_at: Date;
  updated_at: Date;
}
```

**Purpose:**
- Store sender information extracted from emails
- Track categorization and metadata
- Support filtering and sorting by domain, category
- Maintain latest email preview for UI display

### Domains Table

```sql
CREATE TABLE domains (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  domain VARCHAR(255) NOT NULL,
  sender_count INTEGER DEFAULT 0,
  email_count INTEGER DEFAULT 0,
  domain_type VARCHAR(50), -- 'newsletter', 'tool', 'meeting', 'promotional', 'personal'
  category_distribution JSONB, -- {'call-me': 2, 'remind-me': 3, ...}
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, domain)
);
```

**TypeScript Model:**
```typescript
interface Domain {
  id: string;
  user_id: string;
  domain: string;
  sender_count: number;
  email_count: number;
  domain_type: 'newsletter' | 'tool' | 'meeting' | 'promotional' | 'personal' | null;
  category_distribution: Record<string, number>;
  created_at: Date;
  updated_at: Date;
}
```

**Purpose:**
- Aggregate sender data by domain
- Track domain-level statistics
- Support domain-based categorization
- Enable domain-level recommendations

### EmailMetadata Table

```sql
CREATE TABLE email_metadata (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  sender_id INTEGER REFERENCES email_senders(id) ON DELETE CASCADE,
  message_id VARCHAR(255) NOT NULL,
  thread_id VARCHAR(255) NOT NULL,
  subject TEXT,
  received_at TIMESTAMP NOT NULL,
  snippet TEXT,
  is_read BOOLEAN DEFAULT false,
  has_attachments BOOLEAN DEFAULT false,
  labels TEXT[],
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, message_id)
);

CREATE INDEX idx_email_metadata_user_sender ON email_metadata(user_id, sender_id);
CREATE INDEX idx_email_metadata_received_at ON email_metadata(received_at);
```

**TypeScript Model:**
```typescript
interface EmailMetadata {
  id: string;
  user_id: string;
  sender_id: string;
  message_id: string;
  thread_id: string;
  subject: string | null;
  received_at: Date;
  snippet: string | null;
  is_read: boolean;
  has_attachments: boolean;
  labels: string[];
  created_at: Date;
}
```

**Purpose:**
- Store email metadata without full content
- Link emails to senders
- Support email preview and listing
- Enable filtering by date, read status, etc.

### UserPreferences Table

```sql
CREATE TABLE user_preferences (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  -- Immediate call triggers
  urgent_financial BOOLEAN DEFAULT true,
  investor_updates BOOLEAN DEFAULT true,
  customer_issues BOOLEAN DEFAULT true,
  team_urgent BOOLEAN DEFAULT false,
  -- Digest preferences
  partnership_deals BOOLEAN DEFAULT false,
  product_launches BOOLEAN DEFAULT true,
  -- Meeting reminders
  meeting_reminder_timing VARCHAR(20) DEFAULT '30-minutes', -- '15-minutes', '30-minutes', '1-hour', '2-hours', '1-day'
  meeting_reminder_frequency VARCHAR(20) DEFAULT 'all-meetings', -- 'all-meetings', 'important-only', 'external-only', 'investor-calls'
  meeting_reminder_method VARCHAR(20) DEFAULT 'call-and-digest', -- 'call-only', 'digest-only', 'call-and-digest'
  -- Call settings
  preferred_call_time VARCHAR(5) DEFAULT '09:00', -- 24-hour format 'HH:MM'
  voice_preference VARCHAR(50) DEFAULT 'nova',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id)
);
```

**TypeScript Model:**
```typescript
interface UserPreferences {
  id: string;
  user_id: string;
  // Immediate call triggers
  urgent_financial: boolean;
  investor_updates: boolean;
  customer_issues: boolean;
  team_urgent: boolean;
  // Digest preferences
  partnership_deals: boolean;
  product_launches: boolean;
  // Meeting reminders
  meeting_reminder_timing: '15-minutes' | '30-minutes' | '1-hour' | '2-hours' | '1-day';
  meeting_reminder_frequency: 'all-meetings' | 'important-only' | 'external-only' | 'investor-calls';
  meeting_reminder_method: 'call-only' | 'digest-only' | 'call-and-digest';
  // Call settings
  preferred_call_time: string; // 'HH:MM' format
  voice_preference: string;
  created_at: Date;
  updated_at: Date;
}
```

**Purpose:**
- Store user preferences for call triggers
- Configure meeting reminder settings
- Set voice and call time preferences
- Support personalized user experience

### ScanJobs Table

```sql
CREATE TABLE scan_jobs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(50) NOT NULL, -- 'queued', 'processing', 'completed', 'failed'
  progress INTEGER DEFAULT 0, -- 0-100
  senders_found INTEGER DEFAULT 0,
  new_senders INTEGER DEFAULT 0,
  error_message TEXT,
  started_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_scan_jobs_user_status ON scan_jobs(user_id, status);
```

**TypeScript Model:**
```typescript
interface ScanJob {
  id: string;
  user_id: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  progress: number; // 0-100
  senders_found: number;
  new_senders: number;
  error_message: string | null;
  started_at: Date;
  completed_at: Date | null;
  created_at: Date;
}
```

**Purpose:**
- Track email scanning jobs
- Monitor progress and completion status
- Store scan results and statistics
- Support job queuing and processing

### Calls Table

```sql
CREATE TABLE calls (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  call_type VARCHAR(50) NOT NULL, -- 'urgent', 'digest', 'meeting-reminder'
  status VARCHAR(50) NOT NULL, -- 'scheduled', 'in-progress', 'completed', 'failed'
  scheduled_at TIMESTAMP NOT NULL,
  completed_at TIMESTAMP,
  duration_seconds INTEGER,
  content_summary TEXT,
  twilio_call_sid VARCHAR(255),
  transcript_id INTEGER REFERENCES call_transcripts(id),
  satisfaction_rating FLOAT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_calls_user_status ON calls(user_id, status);
CREATE INDEX idx_calls_scheduled_at ON calls(scheduled_at);
```

**TypeScript Model:**
```typescript
interface Call {
  id: string;
  user_id: string;
  call_type: 'urgent' | 'digest' | 'meeting-reminder';
  status: 'scheduled' | 'in-progress' | 'completed' | 'failed';
  scheduled_at: Date;
  completed_at: Date | null;
  duration_seconds: number | null;
  content_summary: string | null;
  twilio_call_sid: string | null;
  transcript_id: string | null;
  satisfaction_rating: number | null;
  created_at: Date;
  updated_at: Date;
}
```

**Purpose:**
- Track call history and status
- Store call metadata and results
- Link to call transcripts
- Support call scheduling and monitoring

### CallTranscripts Table

```sql
CREATE TABLE call_transcripts (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  transcript_text TEXT NOT NULL,
  voice_id VARCHAR(50) NOT NULL,
  audio_url TEXT,
  word_count INTEGER,
  duration_seconds INTEGER,
  created_at TIMESTAMP DEFAULT NOW()
);
```

**TypeScript Model:**
```typescript
interface CallTranscript {
  id: string;
  user_id: string;
  transcript_text: string;
  voice_id: string;
  audio_url: string | null;
  word_count: number | null;
  duration_seconds: number | null;
  created_at: Date;
}
```

**Purpose:**
- Store generated call transcripts
- Link to audio files
- Track transcript metadata
- Support voice synthesis

### CallEmailReferences Table

```sql
CREATE TABLE call_email_references (
  id SERIAL PRIMARY KEY,
  call_id INTEGER REFERENCES calls(id) ON DELETE CASCADE,
  email_id INTEGER REFERENCES email_metadata(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(call_id, email_id)
);
```

**TypeScript Model:**
```typescript
interface CallEmailReference {
  id: string;
  call_id: string;
  email_id: string;
  created_at: Date;
}
```

**Purpose:**
- Link calls to referenced emails
- Track which emails triggered calls
- Support call content generation
- Enable email-call traceability

### NewsletterSummaries Table

```sql
CREATE TABLE newsletter_summaries (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  email_id INTEGER REFERENCES email_metadata(id) ON DELETE CASCADE,
  summary_text TEXT NOT NULL,
  key_topics TEXT[],
  created_at TIMESTAMP DEFAULT NOW()
);
```

**TypeScript Model:**
```typescript
interface NewsletterSummary {
  id: string;
  user_id: string;
  email_id: string;
  summary_text: string;
  key_topics: string[];
  created_at: Date;
}
```

**Purpose:**
- Store generated newsletter summaries
- Track key topics and themes
- Support digest call content
- Enable newsletter management

## Data Models and Relationships

### Core Entity Relationships

1. **User → EmailIntegrations**
   - One-to-many: A user can connect multiple email accounts
   - Primary integration point for Gmail API

2. **User → EmailSenders**
   - One-to-many: A user has multiple email senders
   - Core data for categorization and bucketing

3. **EmailSenders → EmailMetadata**
   - One-to-many: A sender has multiple emails
   - Supports email preview and listing

4. **User → Domains**
   - One-to-many: A user has multiple domains
   - Aggregates sender data for domain-level analysis

5. **User → UserPreferences**
   - One-to-one: Each user has one preferences record
   - Configures call and notification behavior

6. **User → Calls**
   - One-to-many: A user receives multiple calls
   - Tracks call history and scheduling

7. **Calls → CallTranscripts**
   - One-to-one: Each call has one transcript
   - Stores voice content for calls

8. **Calls → CallEmailReferences → EmailMetadata**
   - Many-to-many: Calls reference multiple emails
   - Tracks which emails triggered which calls

### Data Flow Diagram

```
┌─────────┐     ┌─────────────────┐     ┌───────────────┐
│  Users  │────▶│EmailIntegrations │────▶│  Gmail API   │
└─────────┘     └─────────────────┘     └───────────────┘
     │                                          │
     │                                          ▼
     │                                  ┌───────────────┐
     │                                  │  ScanJobs    │
     │                                  └───────────────┘
     │                                          │
     ├─────────┬─────────┬─────────┐           │
     ▼         ▼         ▼         ▼           ▼
┌─────────┐┌─────────┐┌─────────┐┌─────────┐┌─────────┐
│UserPrefs││ Domains ││EmailSenders│EmailMetadata│
└─────────┘└─────────┘└─────────┘└─────────┘└─────────┘
     │                    │           │
     │                    │           ▼
     │                    │    ┌───────────────┐
     │                    │    │NewsletterSummaries│
     │                    │    └───────────────┘
     │                    │           │
     ▼                    ▼           ▼
┌─────────┐           ┌───────────────┐
│  Calls  │◀──────────│CallEmailReferences│
└─────────┘           └───────────────┘
     │
     ▼
┌─────────────┐     ┌───────────────┐     ┌───────────────┐
│CallTranscripts│───▶│  ElevenLabs  │────▶│    Twilio    │
└─────────────┘     └───────────────┘     └───────────────┘
```

## Database Indexing Strategy

### Primary Indexes
- User ID on all tables for efficient user-specific queries
- Email sender domain for domain-based analysis
- Category fields for filtering by category
- Timestamp fields for chronological sorting and filtering

### Composite Indexes
- (user_id, category) on EmailSenders for category-filtered queries
- (user_id, sender_id) on EmailMetadata for sender-specific email queries
- (user_id, status) on Calls for call status filtering

### Performance Considerations
- Partial indexes for frequently filtered subsets
- Expression indexes for complex query patterns
- Regular VACUUM and analyze operations
- Monitoring of query performance

## Data Migration and Seeding

### Initial Setup
1. Create database schema with all tables
2. Create indexes for performance optimization
3. Seed default user preferences

### Gmail Integration
1. Store OAuth tokens securely
2. Implement token refresh mechanism
3. Handle connection errors gracefully

### Data Processing Flow
1. Scan Gmail inbox using gmail-inbox library
2. Extract sender information and metadata
3. Categorize senders based on domain and content
4. Generate domain-level statistics
5. Store email metadata for reference

## Schema Evolution Strategy

### Version Control
- Track schema changes in version control
- Use migration scripts for schema updates
- Document breaking changes

### Backward Compatibility
- Maintain API compatibility during schema changes
- Use nullable columns for new fields
- Implement data backfill for existing records

### Performance Monitoring
- Monitor query performance after schema changes
- Adjust indexes based on query patterns
- Optimize for common access patterns

## Security Considerations

### Data Protection
- Encrypt sensitive fields (tokens, personal data)
- Implement row-level security for multi-tenant isolation
- Regular security audits and penetration testing

### Access Control
- Role-based access control for API endpoints
- Strict validation of user permissions
- Audit logging for sensitive operations

### Compliance
- GDPR-compliant data deletion capabilities
- Data retention policies
- Privacy by design principles

## Implementation Recommendations

1. **Use ORM with TypeScript**
   - Implement using Drizzle ORM for type safety
   - Define models with strict typing
   - Leverage migrations for schema changes

2. **Implement Connection Pooling**
   - Use connection pooling for efficient database access
   - Configure appropriate pool sizes based on load
   - Monitor connection usage

3. **Optimize for Read Performance**
   - Cache frequently accessed data
   - Use materialized views for complex aggregations
   - Implement efficient pagination

4. **Ensure Data Integrity**
   - Use transactions for multi-table operations
   - Implement proper error handling and rollbacks
   - Validate data before insertion

5. **Monitor and Scale**
   - Set up monitoring for database performance
   - Plan for horizontal scaling as user base grows
   - Implement sharding strategy for future growth
