# PookAi Backend Unit Testing Strategy

## Overview

This document outlines the unit testing strategy for the PookAi backend, focusing on controllers, services, and API endpoints. The goal is to ensure that all components function correctly, handle errors appropriately, and cover edge cases before proceeding to integration testing.

## Testing Framework and Tools

- **Jest**: Primary testing framework
- **Supertest**: HTTP assertions for API testing
- **Sinon**: Mocking and stubbing
- **Nock**: HTTP request mocking
- **Faker**: Test data generation

## Directory Structure

```
server/
├── tests/
│   ├── unit/
│   │   ├── controllers/
│   │   │   ├── email.controller.test.ts
│   │   │   ├── domain.controller.test.ts
│   │   │   ├── call.controller.test.ts
│   │   │   └── integration.controller.test.ts
│   │   ├── services/
│   │   │   ├── gmail.service.test.ts
│   │   │   ├── twilio.service.test.ts
│   │   │   ├── elevenlabs.service.test.ts
│   │   │   └── newsletter.service.test.ts
│   │   ├── models/
│   │   │   ├── email.model.test.ts
│   │   │   ├── call.model.test.ts
│   │   │   └── integration.model.test.ts
│   │   └── routes/
│   │       ├── email.routes.test.ts
│   │       ├── domain.routes.test.ts
│   │       ├── call.routes.test.ts
│   │       └── integration.routes.test.ts
│   ├── integration/
│   │   ├── email-flow.test.ts
│   │   ├── call-flow.test.ts
│   │   └── newsletter-flow.test.ts
│   └── mocks/
│       ├── gmail-api.mock.ts
│       ├── twilio-api.mock.ts
│       └── elevenlabs-api.mock.ts
└── jest.config.js
```

## Test Cases by Component

### 1. Gmail Service Tests

**File: `tests/unit/services/gmail.service.test.ts`**

```typescript
import { GmailService } from '../../../services/gmail.service';
import { EmailIntegration, EmailSender, EmailMetadata, ScanJob, Domain } from '../../../models';
import sinon from 'sinon';

// Mock the gmail-inbox library
jest.mock('gmail-inbox', () => {
  return {
    Inbox: jest.fn().mockImplementation(() => {
      return {
        authenticateAccount: jest.fn().mockResolvedValue(true),
        getLatestMessages: jest.fn().mockResolvedValue([
          {
            messageId: 'msg1',
            threadId: 'thread1',
            from: 'Stripe <receipts@stripe.com>',
            subject: 'Payment Receipt',
            receivedOn: '2025-05-30T10:00:00Z',
            snippet: 'Your payment of $50 was successful',
            labelIds: ['INBOX', 'UNREAD']
          },
          {
            messageId: 'msg2',
            threadId: 'thread2',
            from: 'GitHub <notifications@github.com>',
            subject: 'New Pull Request',
            receivedOn: '2025-05-29T15:30:00Z',
            snippet: 'A new pull request has been opened',
            labelIds: ['INBOX']
          }
        ]),
        findMessages: jest.fn().mockResolvedValue([
          {
            messageId: 'msg1',
            threadId: 'thread1',
            from: 'Stripe <receipts@stripe.com>',
            subject: 'Payment Receipt',
            receivedOn: '2025-05-30T10:00:00Z',
            snippet: 'Your payment of $50 was successful',
            labelIds: ['INBOX', 'UNREAD']
          }
        ]),
        getMessageById: jest.fn().mockResolvedValue({
          messageId: 'msg1',
          threadId: 'thread1',
          from: 'Stripe <receipts@stripe.com>',
          to: 'User <user@example.com>',
          subject: 'Payment Receipt',
          receivedOn: '2025-05-30T10:00:00Z',
          snippet: 'Your payment of $50 was successful',
          body: {
            html: '<html><body>Your payment was successful</body></html>',
            text: 'Your payment was successful'
          },
          labelIds: ['INBOX', 'UNREAD']
        })
      };
    })
  };
});

describe('GmailService', () => {
  let gmailService: GmailService;
  let findOneStub: sinon.SinonStub;
  let createStub: sinon.SinonStub;
  let updateStub: sinon.SinonStub;
  let findAllStub: sinon.SinonStub;
  
  beforeEach(() => {
    // Create stubs for database models
    findOneStub = sinon.stub(EmailIntegration, 'findOne');
    createStub = sinon.stub(EmailSender, 'create');
    updateStub = sinon.stub(ScanJob, 'update');
    findAllStub = sinon.stub(EmailSender, 'findAll');
    
    // Initialize service
    gmailService = new GmailService('user123');
  });
  
  afterEach(() => {
    // Restore stubs
    sinon.restore();
  });
  
  describe('initialize', () => {
    it('should initialize successfully with valid credentials', async () => {
      // Arrange
      findOneStub.resolves({
        id: 'integration1',
        user_id: 'user123',
        provider: 'gmail',
        email: 'user@example.com',
        access_token: 'access123',
        refresh_token: 'refresh123',
        token_expiry: new Date(Date.now() + 3600 * 1000),
        scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
        status: 'connected'
      });
      
      // Act
      const result = await gmailService.initialize();
      
      // Assert
      expect(result).toBe(true);
      expect(findOneStub.calledOnce).toBe(true);
    });
    
    it('should fail initialization with no active integration', async () => {
      // Arrange
      findOneStub.resolves(null);
      
      // Act
      const result = await gmailService.initialize();
      
      // Assert
      expect(result).toBe(false);
      expect(findOneStub.calledOnce).toBe(true);
    });
    
    it('should handle initialization errors', async () => {
      // Arrange
      findOneStub.rejects(new Error('Database error'));
      
      // Act & Assert
      await expect(gmailService.initialize()).rejects.toThrow('Database error');
    });
  });
  
  describe('scanInbox', () => {
    beforeEach(async () => {
      // Setup for successful initialization
      findOneStub.resolves({
        id: 'integration1',
        user_id: 'user123',
        provider: 'gmail',
        email: 'user@example.com',
        access_token: 'access123',
        refresh_token: 'refresh123',
        token_expiry: new Date(Date.now() + 3600 * 1000),
        scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
        status: 'connected'
      });
      
      await gmailService.initialize();
    });
    
    it('should scan inbox and process messages', async () => {
      // Arrange
      updateStub.resolves([1]);
      createStub.resolves({ id: 'sender1' });
      
      // Mock EmailMetadata.create
      const emailMetadataCreateStub = sinon.stub(EmailMetadata, 'create').resolves({ id: 'email1' });
      
      // Mock EmailMetadata.findOne
      const emailMetadataFindOneStub = sinon.stub(EmailMetadata, 'findOne').resolves(null);
      
      // Mock Domain.findOne and Domain.create
      const domainFindOneStub = sinon.stub(Domain, 'findOne').resolves(null);
      const domainCreateStub = sinon.stub(Domain, 'create').resolves({ id: 'domain1' });
      
      // Act
      await gmailService.scanInbox('job123');
      
      // Assert
      expect(updateStub.calledWith(
        { status: 'processing', progress: 10 },
        { where: { id: 'job123' } }
      )).toBe(true);
      
      expect(updateStub.calledWith(
        { 
          status: 'completed', 
          progress: 100,
          senders_found: 2,
          new_senders: 2,
          completed_at: sinon.match.date
        },
        { where: { id: 'job123' } }
      )).toBe(true);
      
      expect(createStub.calledTwice).toBe(true);
      expect(emailMetadataCreateStub.calledTwice).toBe(true);
    });
    
    it('should handle scan errors', async () => {
      // Arrange
      updateStub.resolves([1]);
      
      // Force an error during processing
      createStub.rejects(new Error('Database error'));
      
      // Act
      await expect(gmailService.scanInbox('job123')).rejects.toThrow('Database error');
      
      // Assert
      expect(updateStub.calledWith(
        { 
          status: 'failed', 
          error_message: 'Database error',
          completed_at: sinon.match.date
        },
        { where: { id: 'job123' } }
      )).toBe(true);
    });
  });
  
  describe('findEmailsFromSender', () => {
    beforeEach(async () => {
      // Setup for successful initialization
      findOneStub.resolves({
        id: 'integration1',
        user_id: 'user123',
        provider: 'gmail',
        email: 'user@example.com',
        access_token: 'access123',
        refresh_token: 'refresh123',
        token_expiry: new Date(Date.now() + 3600 * 1000),
        scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
        status: 'connected'
      });
      
      await gmailService.initialize();
    });
    
    it('should find emails from a specific sender', async () => {
      // Arrange
      const senderFindOneStub = sinon.stub(EmailSender, 'findOne').resolves({
        id: 'sender1',
        user_id: 'user123',
        name: 'Stripe',
        email: 'receipts@stripe.com',
        domain: 'stripe.com'
      });
      
      // Act
      const result = await gmailService.findEmailsFromSender('sender1', 5);
      
      // Assert
      expect(result.length).toBe(1);
      expect(result[0].messageId).toBe('msg1');
      expect(result[0].from).toBe('Stripe <receipts@stripe.com>');
      expect(senderFindOneStub.calledOnce).toBe(true);
    });
    
    it('should throw error if sender not found', async () => {
      // Arrange
      const senderFindOneStub = sinon.stub(EmailSender, 'findOne').resolves(null);
      
      // Act & Assert
      await expect(gmailService.findEmailsFromSender('sender1', 5)).rejects.toThrow('Sender not found: sender1');
      expect(senderFindOneStub.calledOnce).toBe(true);
    });
  });
  
  // Additional tests for helper methods
  describe('Helper methods', () => {
    it('should extract email from sender string', () => {
      // Use a public method that calls the private method for testing
      const email = gmailService['extractEmailFromSender']('Stripe <receipts@stripe.com>');
      expect(email).toBe('receipts@stripe.com');
    });
    
    it('should extract name from sender string', () => {
      const name = gmailService['extractNameFromSender']('Stripe <receipts@stripe.com>');
      expect(name).toBe('Stripe');
    });
    
    it('should extract domain from email', () => {
      const domain = gmailService['extractDomainFromEmail']('receipts@stripe.com');
      expect(domain).toBe('stripe.com');
    });
    
    it('should guess sender type based on domain and message', () => {
      const type = gmailService['guessSenderType']('newsletter.com', { subject: 'Weekly Newsletter' });
      expect(type).toBe('newsletter');
    });
  });
});
```

### 2. Email Controller Tests

**File: `tests/unit/controllers/email.controller.test.ts`**

```typescript
import { EmailController } from '../../../controllers/email.controller';
import { EmailSender, ScanJob, Domain, EmailMetadata } from '../../../models';
import { GmailService } from '../../../services/gmail.service';
import sinon from 'sinon';
import { Request, Response } from 'express';

// Mock GmailService
jest.mock('../../../services/gmail.service');

describe('EmailController', () => {
  let emailController: EmailController;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let jsonSpy: jest.SpyInstance;
  let statusSpy: jest.SpyInstance;
  
  beforeEach(() => {
    // Initialize controller
    emailController = new EmailController();
    
    // Setup request and response objects
    req = {
      user: { id: 'user123' },
      params: {},
      query: {},
      body: {}
    };
    
    res = {
      json: jest.fn(),
      status: jest.fn().mockReturnThis()
    };
    
    jsonSpy = jest.spyOn(res, 'json');
    statusSpy = jest.spyOn(res, 'status');
  });
  
  afterEach(() => {
    sinon.restore();
    jest.clearAllMocks();
  });
  
  describe('getSenders', () => {
    it('should return senders with pagination', async () => {
      // Arrange
      const findAndCountAllStub = sinon.stub(EmailSender, 'findAndCountAll').resolves({
        count: 2,
        rows: [
          {
            id: 'sender1',
            name: 'Stripe',
            email: 'receipts@stripe.com',
            domain: 'stripe.com',
            category: 'call-me',
            email_count: 10,
            latest_subject: 'Payment Receipt',
            latest_date: '2025-05-30T10:00:00Z',
            latest_preview: 'Your payment was successful'
          },
          {
            id: 'sender2',
            name: 'GitHub',
            email: 'notifications@github.com',
            domain: 'github.com',
            category: 'remind-me',
            email_count: 5,
            latest_subject: 'New Pull Request',
            latest_date: '2025-05-29T15:30:00Z',
            latest_preview: 'A new pull request has been opened'
          }
        ]
      });
      
      // Act
      await emailController.getSenders(req as Request, res as Response);
      
      // Assert
      expect(findAndCountAllStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          senders: expect.any(Array),
          pagination: {
            page: 1,
            limit: 50,
            total: 2,
            pages: 1
          }
        }
      });
      expect(jsonSpy.mock.calls[0][0].data.senders.length).toBe(2);
    });
    
    it('should filter senders by category', async () => {
      // Arrange
      req.query = { category: 'call-me' };
      
      const findAndCountAllStub = sinon.stub(EmailSender, 'findAndCountAll').resolves({
        count: 1,
        rows: [
          {
            id: 'sender1',
            name: 'Stripe',
            email: 'receipts@stripe.com',
            domain: 'stripe.com',
            category: 'call-me',
            email_count: 10,
            latest_subject: 'Payment Receipt',
            latest_date: '2025-05-30T10:00:00Z',
            latest_preview: 'Your payment was successful'
          }
        ]
      });
      
      // Act
      await emailController.getSenders(req as Request, res as Response);
      
      // Assert
      expect(findAndCountAllStub.calledOnce).toBe(true);
      expect(findAndCountAllStub.firstCall.args[0].where).toHaveProperty('category', 'call-me');
      expect(jsonSpy.mock.calls[0][0].data.senders.length).toBe(1);
    });
    
    it('should handle database errors', async () => {
      // Arrange
      const findAndCountAllStub = sinon.stub(EmailSender, 'findAndCountAll').rejects(new Error('Database error'));
      
      // Act
      await emailController.getSenders(req as Request, res as Response);
      
      // Assert
      expect(findAndCountAllStub.calledOnce).toBe(true);
      expect(statusSpy).toHaveBeenCalledWith(500);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to retrieve email senders',
          details: 'Database error'
        }
      });
    });
  });
  
  describe('scanEmails', () => {
    it('should start a new scan job', async () => {
      // Arrange
      req.body = { provider: 'gmail' };
      
      const findOneStub = sinon.stub(ScanJob, 'findOne').resolves(null);
      const createStub = sinon.stub(ScanJob, 'create').resolves({
        id: 'job123',
        user_id: 'user123',
        status: 'queued',
        progress: 0,
        started_at: new Date()
      });
      
      // Mock startScanProcess method
      const startScanProcessStub = sinon.stub(emailController as any, 'startScanProcess').resolves();
      
      // Act
      await emailController.scanEmails(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(createStub.calledOnce).toBe(true);
      expect(startScanProcessStub.calledOnce).toBe(true);
      expect(startScanProcessStub.firstCall.args).toEqual(['user123', 'job123', 'gmail']);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          jobId: 'job123',
          status: 'processing',
          estimatedCompletion: expect.any(Date)
        }
      });
    });
    
    it('should reject if scan already in progress', async () => {
      // Arrange
      req.body = { provider: 'gmail' };
      
      const findOneStub = sinon.stub(ScanJob, 'findOne').resolves({
        id: 'job123',
        user_id: 'user123',
        status: 'processing',
        progress: 50
      });
      
      // Act
      await emailController.scanEmails(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(statusSpy).toHaveBeenCalledWith(409);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'SCAN_IN_PROGRESS',
          message: 'A scan is already in progress',
          details: {
            jobId: 'job123',
            progress: 50
          }
        }
      });
    });
    
    it('should force rescan if requested', async () => {
      // Arrange
      req.body = { provider: 'gmail', forceRescan: true };
      
      const findOneStub = sinon.stub(ScanJob, 'findOne').resolves({
        id: 'job123',
        user_id: 'user123',
        status: 'processing',
        progress: 50
      });
      
      const createStub = sinon.stub(ScanJob, 'create').resolves({
        id: 'job456',
        user_id: 'user123',
        status: 'queued',
        progress: 0,
        started_at: new Date()
      });
      
      // Mock startScanProcess method
      const startScanProcessStub = sinon.stub(emailController as any, 'startScanProcess').resolves();
      
      // Act
      await emailController.scanEmails(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(createStub.calledOnce).toBe(true);
      expect(startScanProcessStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          jobId: 'job456',
          status: 'processing',
          estimatedCompletion: expect.any(Date)
        }
      });
    });
  });
  
  describe('getScanStatus', () => {
    it('should return scan job status', async () => {
      // Arrange
      req.params = { jobId: 'job123' };
      
      const findOneStub = sinon.stub(ScanJob, 'findOne').resolves({
        id: 'job123',
        user_id: 'user123',
        status: 'completed',
        progress: 100,
        senders_found: 10,
        new_senders: 5,
        error_message: null,
        started_at: new Date('2025-05-30T10:00:00Z'),
        completed_at: new Date('2025-05-30T10:05:00Z')
      });
      
      // Act
      await emailController.getScanStatus(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          jobId: 'job123',
          status: 'completed',
          progress: 100,
          sendersFound: 10,
          newSenders: 5,
          error: null,
          startedAt: expect.any(Date),
          completedAt: expect.any(Date)
        }
      });
    });
    
    it('should return 404 if job not found', async () => {
      // Arrange
      req.params = { jobId: 'job123' };
      
      const findOneStub = sinon.stub(ScanJob, 'findOne').resolves(null);
      
      // Act
      await emailController.getScanStatus(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(statusSpy).toHaveBeenCalledWith(404);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'JOB_NOT_FOUND',
          message: 'Scan job not found'
        }
      });
    });
  });
  
  describe('updateSenderCategory', () => {
    it('should update sender category', async () => {
      // Arrange
      req.params = { id: 'sender123' };
      req.body = { category: 'call-me' };
      
      const updateStub = sinon.stub(EmailSender, 'update').resolves([1]);
      const findOneStub = sinon.stub(EmailSender, 'findOne').resolves({
        id: 'sender123',
        user_id: 'user123',
        name: 'Stripe',
        email: 'receipts@stripe.com',
        domain: 'stripe.com',
        category: 'call-me',
        updated_at: new Date()
      });
      
      // Mock updateDomainCategoryStats method
      const updateDomainCategoryStatsStub = sinon.stub(emailController as any, 'updateDomainCategoryStats').resolves();
      
      // Act
      await emailController.updateSenderCategory(req as Request, res as Response);
      
      // Assert
      expect(updateStub.calledOnce).toBe(true);
      expect(findOneStub.calledOnce).toBe(true);
      expect(updateDomainCategoryStatsStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          sender: {
            id: 'sender123',
            category: 'call-me',
            updatedAt: expect.any(Date)
          }
        }
      });
    });
    
    it('should reject invalid category', async () => {
      // Arrange
      req.params = { id: 'sender123' };
      req.body = { category: 'invalid-category' };
      
      // Act
      await emailController.updateSenderCategory(req as Request, res as Response);
      
      // Assert
      expect(statusSpy).toHaveBeenCalledWith(400);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'INVALID_CATEGORY',
          message: 'Invalid category value',
          details: expect.stringContaining('Category must be one of:')
        }
      });
    });
    
    it('should return 404 if sender not found', async () => {
      // Arrange
      req.params = { id: 'sender123' };
      req.body = { category: 'call-me' };
      
      const updateStub = sinon.stub(EmailSender, 'update').resolves([0]);
      
      // Act
      await emailController.updateSenderCategory(req as Request, res as Response);
      
      // Assert
      expect(updateStub.calledOnce).toBe(true);
      expect(statusSpy).toHaveBeenCalledWith(404);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'SENDER_NOT_FOUND',
          message: 'Sender not found'
        }
      });
    });
  });
  
  // Additional tests for other methods
  // bulkUpdateSenders, getEmailPreview, etc.
});
```

### 3. Call Controller Tests

**File: `tests/unit/controllers/call.controller.test.ts`**

```typescript
import { CallController } from '../../../controllers/call.controller';
import { Call, CallTranscript, CallEmailReference, EmailMetadata, UserPreferences, EmailSender } from '../../../models';
import { TwilioService } from '../../../services/twilio.service';
import { ElevenLabsService } from '../../../services/elevenlabs.service';
import sinon from 'sinon';
import { Request, Response } from 'express';

// Mock TwilioService and ElevenLabsService
jest.mock('../../../services/twilio.service');
jest.mock('../../../services/elevenlabs.service');

describe('CallController', () => {
  let callController: CallController;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let jsonSpy: jest.SpyInstance;
  let statusSpy: jest.SpyInstance;
  
  beforeEach(() => {
    // Initialize controller
    callController = new CallController();
    
    // Setup request and response objects
    req = {
      user: { id: 'user123' },
      params: {},
      query: {},
      body: {}
    };
    
    res = {
      json: jest.fn(),
      status: jest.fn().mockReturnThis()
    };
    
    jsonSpy = jest.spyOn(res, 'json');
    statusSpy = jest.spyOn(res, 'status');
  });
  
  afterEach(() => {
    sinon.restore();
    jest.clearAllMocks();
  });
  
  describe('scheduleUrgentCall', () => {
    it('should schedule an urgent call', async () => {
      // Arrange
      req.body = {
        content: 'Critical payment failure from Stripe',
        priority: 'high',
        context: {
          senderIds: ['sender456'],
          emailIds: ['email789']
        }
      };
      
      const findOneStub = sinon.stub(UserPreferences, 'findOne').resolves({
        id: 'pref123',
        user_id: 'user123',
        voice_preference: 'nova'
      });
      
      const createTranscriptStub = sinon.stub(CallTranscript, 'create').resolves({
        id: 'transcript123',
        user_id: 'user123',
        transcript_text: 'Critical payment failure from Stripe',
        voice_id: 'nova'
      });
      
      const createCallStub = sinon.stub(Call, 'create').resolves({
        id: 'call123',
        user_id: 'user123',
        call_type: 'urgent',
        status: 'scheduled',
        scheduled_at: new Date(Date.now() + 60 * 1000),
        content_summary: 'Critical payment failure from Stripe',
        transcript_id: 'transcript123'
      });
      
      const createRefStub = sinon.stub(CallEmailReference, 'create').resolves({
        id: 'ref123',
        call_id: 'call123',
        email_id: 'email789'
      });
      
      // Mock processUrgentCall method
      const processUrgentCallStub = sinon.stub(callController as any, 'processUrgentCall').resolves();
      
      // Act
      await callController.scheduleUrgentCall(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(createTranscriptStub.calledOnce).toBe(true);
      expect(createCallStub.calledOnce).toBe(true);
      expect(createRefStub.calledOnce).toBe(true);
      expect(processUrgentCallStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          call: {
            id: 'call123',
            type: 'urgent',
            status: 'scheduled',
            scheduledAt: expect.any(Date),
            estimatedDuration: expect.any(Number)
          }
        }
      });
    });
    
    it('should reject if content is missing', async () => {
      // Arrange
      req.body = {
        priority: 'high',
        context: {
          senderIds: ['sender456'],
          emailIds: ['email789']
        }
      };
      
      // Act
      await callController.scheduleUrgentCall(req as Request, res as Response);
      
      // Assert
      expect(statusSpy).toHaveBeenCalledWith(400);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'INVALID_REQUEST',
          message: 'Content is required'
        }
      });
    });
    
    it('should handle database errors', async () => {
      // Arrange
      req.body = {
        content: 'Critical payment failure from Stripe',
        priority: 'high'
      };
      
      const findOneStub = sinon.stub(UserPreferences, 'findOne').rejects(new Error('Database error'));
      
      // Act
      await callController.scheduleUrgentCall(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(statusSpy).toHaveBeenCalledWith(500);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to schedule urgent call',
          details: 'Database error'
        }
      });
    });
  });
  
  describe('getNextDigestCall', () => {
    it('should return next digest call preview', async () => {
      // Arrange
      const findPrefStub = sinon.stub(UserPreferences, 'findOne').resolves({
        id: 'pref123',
        user_id: 'user123',
        preferred_call_time: '09:00'
      });
      
      const countCallMeStub = sinon.stub(EmailSender, 'count')
        .onFirstCall().resolves(2)  // call-me count
        .onSecondCall().resolves(5); // remind-me count
      
      const findAllStub = sinon.stub(EmailSender, 'findAll').resolves([
        {
          id: 'sender1',
          name: 'Stripe',
          domain: 'stripe.com'
        },
        {
          id: 'sender2',
          name: 'GitHub',
          domain: 'github.com'
        },
        {
          id: 'sender3',
          name: null,
          domain: 'example.com'
        }
      ]);
      
      // Act
      await callController.getNextDigestCall(req as Request, res as Response);
      
      // Assert
      expect(findPrefStub.calledOnce).toBe(true);
      expect(countCallMeStub.calledTwice).toBe(true);
      expect(findAllStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          nextCall: {
            scheduledAt: expect.any(Date),
            contentPreview: {
              callMeItems: 2,
              remindMeItems: 5,
              meetingReminders: 0,
              topSenders: ['Stripe', 'GitHub', 'example.com']
            },
            estimatedDuration: 180
          }
        }
      });
    });
    
    it('should use default time if no preferences found', async () => {
      // Arrange
      const findPrefStub = sinon.stub(UserPreferences, 'findOne').resolves(null);
      
      const countCallMeStub = sinon.stub(EmailSender, 'count')
        .onFirstCall().resolves(0)
        .onSecondCall().resolves(0);
      
      const findAllStub = sinon.stub(EmailSender, 'findAll').resolves([]);
      
      // Act
      await callController.getNextDigestCall(req as Request, res as Response);
      
      // Assert
      expect(findPrefStub.calledOnce).toBe(true);
      expect(countCallMeStub.calledTwice).toBe(true);
      expect(findAllStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          nextCall: {
            scheduledAt: expect.any(Date),
            contentPreview: {
              callMeItems: 0,
              remindMeItems: 0,
              meetingReminders: 0,
              topSenders: []
            },
            estimatedDuration: 180
          }
        }
      });
    });
  });
  
  describe('generateTranscript', () => {
    it('should generate transcript from email content', async () => {
      // Arrange
      req.body = {
        emailIds: ['email123', 'email456'],
        callType: 'urgent',
        voiceId: 'nova'
      };
      
      const findAllStub = sinon.stub(EmailMetadata, 'findAll').resolves([
        {
          id: 'email123',
          subject: 'Payment failed for subscription',
          snippet: 'Your payment method was declined...',
          sender: {
            name: 'Stripe',
            email: 'receipts@stripe.com'
          }
        }
      ]);
      
      // Mock transcript generation methods
      const generateUrgentTranscriptStub = sinon.stub(callController as any, 'generateUrgentTranscript')
        .returns('Hey there! Quick urgent update: Stripe sent an email with the subject "Payment failed for subscription". Here\'s a preview: Your payment method was declined.... This seemed important based on your preferences, so I wanted to let you know right away.');
      
      // Act
      await callController.generateTranscript(req as Request, res as Response);
      
      // Assert
      expect(findAllStub.calledOnce).toBe(true);
      expect(generateUrgentTranscriptStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          transcript: expect.stringContaining('Hey there! Quick urgent update'),
          estimatedDuration: expect.any(Number),
          wordCount: expect.any(Number)
        }
      });
    });
    
    it('should reject if emailIds are missing', async () => {
      // Arrange
      req.body = {
        callType: 'urgent',
        voiceId: 'nova'
      };
      
      // Act
      await callController.generateTranscript(req as Request, res as Response);
      
      // Assert
      expect(statusSpy).toHaveBeenCalledWith(400);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'INVALID_REQUEST',
          message: 'Email IDs are required'
        }
      });
    });
    
    it('should return 404 if no emails found', async () => {
      // Arrange
      req.body = {
        emailIds: ['email123', 'email456'],
        callType: 'urgent',
        voiceId: 'nova'
      };
      
      const findAllStub = sinon.stub(EmailMetadata, 'findAll').resolves([]);
      
      // Act
      await callController.generateTranscript(req as Request, res as Response);
      
      // Assert
      expect(findAllStub.calledOnce).toBe(true);
      expect(statusSpy).toHaveBeenCalledWith(404);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'EMAILS_NOT_FOUND',
          message: 'No emails found with the provided IDs'
        }
      });
    });
  });
  
  // Tests for private methods
  describe('Private methods', () => {
    it('should process urgent call correctly', async () => {
      // This test would need to mock a lot of dependencies
      // and is more complex, so we'll skip the implementation details
    });
    
    it('should generate urgent transcript correctly', () => {
      const emails = [
        {
          subject: 'Payment failed for subscription',
          snippet: 'Your payment method was declined...',
          sender: {
            name: 'Stripe',
            email: 'receipts@stripe.com'
          }
        }
      ];
      
      const transcript = callController['generateUrgentTranscript'](emails);
      expect(transcript).toContain('Hey there! Quick urgent update');
      expect(transcript).toContain('Stripe');
      expect(transcript).toContain('Payment failed for subscription');
    });
    
    it('should generate digest transcript correctly', () => {
      const emails = [
        {
          subject: 'Payment failed for subscription',
          snippet: 'Your payment method was declined...',
          sender: {
            name: 'Stripe',
            email: 'receipts@stripe.com'
          }
        },
        {
          subject: 'New Pull Request',
          snippet: 'A new pull request has been opened',
          sender: {
            name: 'GitHub',
            email: 'notifications@github.com'
          }
        }
      ];
      
      const transcript = callController['generateDigestTranscript'](emails);
      expect(transcript).toContain('Good morning! Here\'s your daily email digest');
      expect(transcript).toContain('2 important emails');
      expect(transcript).toContain('Stripe sent "Payment failed for subscription"');
      expect(transcript).toContain('GitHub sent "New Pull Request"');
    });
  });
});
```

### 4. Integration Controller Tests

**File: `tests/unit/controllers/integration.controller.test.ts`**

```typescript
import { IntegrationController } from '../../../controllers/integration.controller';
import { EmailIntegration } from '../../../models';
import sinon from 'sinon';
import { Request, Response } from 'express';

describe('IntegrationController', () => {
  let integrationController: IntegrationController;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let jsonSpy: jest.SpyInstance;
  let statusSpy: jest.SpyInstance;
  
  beforeEach(() => {
    // Initialize controller
    integrationController = new IntegrationController();
    
    // Setup request and response objects
    req = {
      user: { id: 'user123' },
      params: {},
      query: {},
      body: {}
    };
    
    res = {
      json: jest.fn(),
      status: jest.fn().mockReturnThis()
    };
    
    jsonSpy = jest.spyOn(res, 'json');
    statusSpy = jest.spyOn(res, 'status');
  });
  
  afterEach(() => {
    sinon.restore();
    jest.clearAllMocks();
  });
  
  describe('connectEmail', () => {
    it('should connect a new Gmail account', async () => {
      // Arrange
      req.body = {
        provider: 'gmail',
        authCode: 'auth123',
        redirectUri: 'https://pookai.com/auth/callback'
      };
      
      // Mock private methods
      const exchangeAuthCodeStub = sinon.stub(integrationController as any, 'exchangeAuthCode').resolves({
        access_token: 'access123',
        refresh_token: 'refresh123',
        expires_in: 3600,
        scope: 'https://www.googleapis.com/auth/gmail.readonly'
      });
      
      const getUserEmailStub = sinon.stub(integrationController as any, 'getUserEmail').resolves('user@example.com');
      
      const findOneStub = sinon.stub(EmailIntegration, 'findOne').resolves(null);
      
      const createStub = sinon.stub(EmailIntegration, 'create').resolves({
        id: 'integration123',
        user_id: 'user123',
        provider: 'gmail',
        email: 'user@example.com',
        access_token: 'access123',
        refresh_token: 'refresh123',
        token_expiry: expect.any(Date),
        scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
        status: 'connected',
        created_at: new Date()
      });
      
      // Act
      await integrationController.connectEmail(req as Request, res as Response);
      
      // Assert
      expect(exchangeAuthCodeStub.calledOnce).toBe(true);
      expect(getUserEmailStub.calledOnce).toBe(true);
      expect(findOneStub.calledOnce).toBe(true);
      expect(createStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          integration: {
            id: 'integration123',
            provider: 'gmail',
            email: 'user@example.com',
            status: 'connected',
            connectedAt: expect.any(Date)
          }
        }
      });
    });
    
    it('should update existing Gmail integration', async () => {
      // Arrange
      req.body = {
        provider: 'gmail',
        authCode: 'auth123',
        redirectUri: 'https://pookai.com/auth/callback'
      };
      
      // Mock private methods
      const exchangeAuthCodeStub = sinon.stub(integrationController as any, 'exchangeAuthCode').resolves({
        access_token: 'access123',
        refresh_token: 'refresh123',
        expires_in: 3600,
        scope: 'https://www.googleapis.com/auth/gmail.readonly'
      });
      
      const getUserEmailStub = sinon.stub(integrationController as any, 'getUserEmail').resolves('user@example.com');
      
      const findOneStub = sinon.stub(EmailIntegration, 'findOne').resolves({
        id: 'integration123',
        user_id: 'user123',
        provider: 'gmail',
        email: 'user@example.com'
      });
      
      const updateStub = sinon.stub(EmailIntegration, 'update').resolves([1]);
      
      // Act
      await integrationController.connectEmail(req as Request, res as Response);
      
      // Assert
      expect(exchangeAuthCodeStub.calledOnce).toBe(true);
      expect(getUserEmailStub.calledOnce).toBe(true);
      expect(findOneStub.calledOnce).toBe(true);
      expect(updateStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          integration: {
            id: 'integration123',
            provider: 'gmail',
            email: 'user@example.com',
            status: 'connected',
            connectedAt: expect.any(Date)
          }
        }
      });
    });
    
    it('should reject unsupported providers', async () => {
      // Arrange
      req.body = {
        provider: 'outlook',
        authCode: 'auth123',
        redirectUri: 'https://pookai.com/auth/callback'
      };
      
      // Act
      await integrationController.connectEmail(req as Request, res as Response);
      
      // Assert
      expect(statusSpy).toHaveBeenCalledWith(400);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'UNSUPPORTED_PROVIDER',
          message: 'Only Gmail is supported at this time'
        }
      });
    });
    
    it('should reject missing required fields', async () => {
      // Arrange
      req.body = {
        provider: 'gmail'
        // Missing authCode
      };
      
      // Act
      await integrationController.connectEmail(req as Request, res as Response);
      
      // Assert
      expect(statusSpy).toHaveBeenCalledWith(400);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: false,
        error: {
          code: 'INVALID_REQUEST',
          message: 'Provider and authCode are required'
        }
      });
    });
  });
  
  describe('getEmailStatus', () => {
    it('should return connected status', async () => {
      // Arrange
      const findOneStub = sinon.stub(EmailIntegration, 'findOne').resolves({
        id: 'integration123',
        user_id: 'user123',
        provider: 'gmail',
        email: 'user@example.com',
        access_token: 'access123',
        refresh_token: 'refresh123',
        token_expiry: new Date(Date.now() + 3600 * 1000), // Not expired
        scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
        status: 'connected',
        last_sync: new Date('2025-05-30T10:00:00Z')
      });
      
      // Mock checkConnectionHealth method
      const checkConnectionHealthStub = sinon.stub(integrationController as any, 'checkConnectionHealth').resolves(true);
      
      // Act
      await integrationController.getEmailStatus(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(checkConnectionHealthStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          connected: true,
          provider: 'gmail',
          email: 'user@example.com',
          lastSync: expect.any(Date),
          permissions: ['https://www.googleapis.com/auth/gmail.readonly'],
          health: 'healthy'
        }
      });
    });
    
    it('should refresh expired token', async () => {
      // Arrange
      const findOneStub = sinon.stub(EmailIntegration, 'findOne').resolves({
        id: 'integration123',
        user_id: 'user123',
        provider: 'gmail',
        email: 'user@example.com',
        access_token: 'access123',
        refresh_token: 'refresh123',
        token_expiry: new Date(Date.now() - 3600 * 1000), // Expired
        scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
        status: 'connected',
        last_sync: new Date('2025-05-30T10:00:00Z')
      });
      
      // Mock refreshToken method
      const refreshTokenStub = sinon.stub(integrationController as any, 'refreshToken').resolves({
        access_token: 'new_access123',
        expires_in: 3600
      });
      
      // Mock update method
      const updateStub = sinon.stub(EmailIntegration, 'update').resolves([1]);
      
      // Mock checkConnectionHealth method
      const checkConnectionHealthStub = sinon.stub(integrationController as any, 'checkConnectionHealth').resolves(true);
      
      // Act
      await integrationController.getEmailStatus(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(refreshTokenStub.calledOnce).toBe(true);
      expect(updateStub.calledOnce).toBe(true);
      expect(checkConnectionHealthStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          connected: true,
          provider: 'gmail',
          email: 'user@example.com',
          lastSync: expect.any(Date),
          permissions: ['https://www.googleapis.com/auth/gmail.readonly'],
          health: 'healthy'
        }
      });
    });
    
    it('should handle token refresh failure', async () => {
      // Arrange
      const findOneStub = sinon.stub(EmailIntegration, 'findOne').resolves({
        id: 'integration123',
        user_id: 'user123',
        provider: 'gmail',
        email: 'user@example.com',
        access_token: 'access123',
        refresh_token: 'refresh123',
        token_expiry: new Date(Date.now() - 3600 * 1000), // Expired
        scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
        status: 'connected',
        last_sync: new Date('2025-05-30T10:00:00Z')
      });
      
      // Mock refreshToken method to fail
      const refreshTokenStub = sinon.stub(integrationController as any, 'refreshToken').rejects(new Error('Refresh failed'));
      
      // Mock update method
      const updateStub = sinon.stub(EmailIntegration, 'update').resolves([1]);
      
      // Act
      await integrationController.getEmailStatus(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(refreshTokenStub.calledOnce).toBe(true);
      expect(updateStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          connected: false,
          provider: 'gmail',
          email: 'user@example.com',
          status: 'error',
          error: 'Authentication expired'
        }
      });
    });
    
    it('should return disconnected status if no integration found', async () => {
      // Arrange
      const findOneStub = sinon.stub(EmailIntegration, 'findOne').resolves(null);
      
      // Act
      await integrationController.getEmailStatus(req as Request, res as Response);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(jsonSpy).toHaveBeenCalledWith({
        success: true,
        data: {
          connected: false
        }
      });
    });
  });
});
```

### 5. Twilio Service Tests

**File: `tests/unit/services/twilio.service.test.ts`**

```typescript
import { TwilioService } from '../../../services/twilio.service';
import { Call } from '../../../models';
import sinon from 'sinon';

describe('TwilioService', () => {
  let twilioService: TwilioService;
  let originalEnv: NodeJS.ProcessEnv;
  
  beforeEach(() => {
    // Save original environment
    originalEnv = process.env;
    
    // Set up test environment variables
    process.env.TWILIO_ACCOUNT_SID = 'test_account_sid';
    process.env.TWILIO_AUTH_TOKEN = 'test_auth_token';
    process.env.TWILIO_PHONE_NUMBER = '+15551234567';
    
    // Initialize service
    twilioService = new TwilioService();
  });
  
  afterEach(() => {
    // Restore original environment
    process.env = originalEnv;
    
    sinon.restore();
  });
  
  describe('initiateCall', () => {
    it('should initiate a call successfully', async () => {
      // Act
      const callSid = await twilioService.initiateCall('+15557654321', 'https://example.com/audio.mp3', 'call123');
      
      // Assert
      expect(callSid).toMatch(/^CA/);
    });
    
    it('should throw error if credentials not configured', async () => {
      // Arrange
      process.env.TWILIO_ACCOUNT_SID = '';
      
      // Reinitialize service with empty credentials
      twilioService = new TwilioService();
      
      // Act & Assert
      await expect(twilioService.initiateCall('+15557654321', 'https://example.com/audio.mp3', 'call123'))
        .rejects.toThrow('Twilio credentials not configured');
    });
  });
  
  describe('generateTwiML', () => {
    it('should generate valid TwiML', () => {
      // Act
      const twiml = twilioService.generateTwiML('https://example.com/audio.mp3');
      
      // Assert
      expect(twiml).toContain('<?xml version="1.0" encoding="UTF-8"?>');
      expect(twiml).toContain('<Response>');
      expect(twiml).toContain('<Play>https://example.com/audio.mp3</Play>');
      expect(twiml).toContain('<Say>This is the end of your PookAi update. Have a great day!</Say>');
      expect(twiml).toContain('</Response>');
    });
  });
  
  describe('processStatusWebhook', () => {
    it('should update call status to completed', async () => {
      // Arrange
      const webhookData = {
        CallSid: 'CA123456789',
        CallStatus: 'completed',
        CallDuration: '45'
      };
      
      const findOneStub = sinon.stub(Call, 'findOne').resolves({
        id: 'call123',
        user_id: 'user123',
        twilio_call_sid: 'CA123456789'
      });
      
      const updateStub = sinon.stub(Call, 'update').resolves([1]);
      
      // Act
      await twilioService.processStatusWebhook(webhookData);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(updateStub.calledOnce).toBe(true);
      expect(updateStub.firstCall.args[0]).toEqual({
        status: 'completed',
        duration_seconds: 45,
        completed_at: sinon.match.date
      });
    });
    
    it('should update call status to failed', async () => {
      // Arrange
      const webhookData = {
        CallSid: 'CA123456789',
        CallStatus: 'failed',
        CallDuration: '0'
      };
      
      const findOneStub = sinon.stub(Call, 'findOne').resolves({
        id: 'call123',
        user_id: 'user123',
        twilio_call_sid: 'CA123456789'
      });
      
      const updateStub = sinon.stub(Call, 'update').resolves([1]);
      
      // Act
      await twilioService.processStatusWebhook(webhookData);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      expect(updateStub.calledOnce).toBe(true);
      expect(updateStub.firstCall.args[0]).toEqual({
        status: 'failed',
        completed_at: sinon.match.date
      });
    });
    
    it('should handle call not found', async () => {
      // Arrange
      const webhookData = {
        CallSid: 'CA123456789',
        CallStatus: 'completed',
        CallDuration: '45'
      };
      
      const findOneStub = sinon.stub(Call, 'findOne').resolves(null);
      
      // Act
      await twilioService.processStatusWebhook(webhookData);
      
      // Assert
      expect(findOneStub.calledOnce).toBe(true);
      // No update should be called
    });
  });
});
```

### 6. ElevenLabs Service Tests

**File: `tests/unit/services/elevenlabs.service.test.ts`**

```typescript
import { ElevenLabsService } from '../../../services/elevenlabs.service';

describe('ElevenLabsService', () => {
  let elevenLabsService: ElevenLabsService;
  let originalEnv: NodeJS.ProcessEnv;
  
  beforeEach(() => {
    // Save original environment
    originalEnv = process.env;
    
    // Set up test environment variables
    process.env.ELEVENLABS_API_KEY = 'test_api_key';
    
    // Initialize service
    elevenLabsService = new ElevenLabsService();
  });
  
  afterEach(() => {
    // Restore original environment
    process.env = originalEnv;
  });
  
  describe('generateAudio', () => {
    it('should generate audio successfully', async () => {
      // Act
      const audioUrl = await elevenLabsService.generateAudio('Hello, this is a test', 'nova');
      
      // Assert
      expect(audioUrl).toMatch(/^https:\/\/storage\.pookai\.com\/audio\/call_/);
      expect(audioUrl).toMatch(/\.mp3$/);
    });
    
    it('should throw error if API key not configured', async () => {
      // Arrange
      process.env.ELEVENLABS_API_KEY = '';
      
      // Reinitialize service with empty API key
      elevenLabsService = new ElevenLabsService();
      
      // Act & Assert
      await expect(elevenLabsService.generateAudio('Hello, this is a test', 'nova'))
        .rejects.toThrow('ElevenLabs API key not configured');
    });
  });
  
  describe('getVoices', () => {
    it('should return available voices', async () => {
      // Act
      const voices = await elevenLabsService.getVoices();
      
      // Assert
      expect(voices).toBeInstanceOf(Array);
      expect(voices.length).toBeGreaterThan(0);
      expect(voices[0]).toHaveProperty('voice_id');
      expect(voices[0]).toHaveProperty('name');
      expect(voices[0]).toHaveProperty('description');
      expect(voices[0]).toHaveProperty('gender');
    });
    
    it('should throw error if API key not configured', async () => {
      // Arrange
      process.env.ELEVENLABS_API_KEY = '';
      
      // Reinitialize service with empty API key
      elevenLabsService = new ElevenLabsService();
      
      // Act & Assert
      await expect(elevenLabsService.getVoices())
        .rejects.toThrow('ElevenLabs API key not configured');
    });
  });
});
```

### 7. Newsletter Service Tests

**File: `tests/unit/services/newsletter.service.test.ts`**

```typescript
import { NewsletterService } from '../../../services/newsletter.service';
import { EmailMetadata, NewsletterSummary, EmailSender } from '../../../models';
import sinon from 'sinon';

describe('NewsletterService', () => {
  let newsletterService: NewsletterService;
  
  beforeEach(() => {
    // Initialize service
    newsletterService = new NewsletterService();
  });
  
  afterEach(() => {
    sinon.restore();
  });
  
  describe('summarizeNewsletters', () => {
    it('should summarize newsletter emails', async () => {
      // Arrange
      const emailIds = ['email123', 'email456'];
      const userId = 'user123';
      
      const findAllStub = sinon.stub(EmailMetadata, 'findAll').resolves([
        {
          id: 'email123',
          subject: 'Weekly Tech Newsletter',
          snippet: 'This week in tech: AI advancements, new programming languages, and more exciting developments in the world of technology.',
          sender: {
            name: 'TechWeekly',
            email: 'news@techweekly.com'
          }
        },
        {
          id: 'email456',
          subject: 'Startup Digest',
          snippet: 'Latest funding rounds, acquisitions, and startup news from around the globe.',
          sender: {
            name: 'StartupDigest',
            email: 'digest@startupdigest.com'
          }
        }
      ]);
      
      const findOneSummaryStub = sinon.stub(NewsletterSummary, 'findOne')
        .onFirstCall().resolves(null)
        .onSecondCall().resolves({
          id: 'summary456',
          user_id: 'user123',
          email_id: 'email456',
          summary_text: 'Latest funding rounds, acquisitions, and startup news from around the globe.',
          key_topics: ['funding', 'acquisitions', 'startup']
        });
      
      const createSummaryStub = sinon.stub(NewsletterSummary, 'create').resolves({
        id: 'summary123',
        user_id: 'user123',
        email_id: 'email123',
        summary_text: 'This week in tech: AI advancements, new programming languages, and more exciting developments in the world of technology.',
        key_topics: ['AI', 'programming', 'technology']
      });
      
      // Act
      const summaries = await newsletterService.summarizeNewsletters(emailIds, userId, 200);
      
      // Assert
      expect(findAllStub.calledOnce).toBe(true);
      expect(findOneSummaryStub.calledTwice).toBe(true);
      expect(createSummaryStub.calledOnce).toBe(true);
      expect(summaries.length).toBe(2);
      expect(summaries[0]).toHaveProperty('emailId', 'email123');
      expect(summaries[0]).toHaveProperty('subject', 'Weekly Tech Newsletter');
      expect(summaries[0]).toHaveProperty('summary');
      expect(summaries[0]).toHaveProperty('keyTopics');
      expect(summaries[1]).toHaveProperty('emailId', 'email456');
    });
    
    it('should handle empty email list', async () => {
      // Arrange
      const emailIds = [];
      const userId = 'user123';
      
      const findAllStub = sinon.stub(EmailMetadata, 'findAll').resolves([]);
      
      // Act
      const summaries = await newsletterService.summarizeNewsletters(emailIds, userId, 200);
      
      // Assert
      expect(findAllStub.calledOnce).toBe(true);
      expect(summaries.length).toBe(0);
    });
  });
  
  describe('Helper methods', () => {
    it('should generate simple summary from text', () => {
      // Arrange
      const text = 'This is a test summary. It has multiple sentences. We want to truncate it properly.';
      
      // Act
      const summary = newsletterService['generateSimpleSummary'](text, 30);
      
      // Assert
      expect(summary).toBe('This is a test summary.');
    });
    
    it('should handle empty text in summary generation', () => {
      // Act
      const summary = newsletterService['generateSimpleSummary']('', 100);
      
      // Assert
      expect(summary).toBe('No content available to summarize.');
    });
    
    it('should extract key topics from text', () => {
      // Arrange
      const subject = 'Weekly Tech Newsletter';
      const text = 'This week in tech: AI advancements, new programming languages, and more exciting developments in the world of technology.';
      
      // Act
      const topics = newsletterService['extractKeyTopics'](subject, text);
      
      // Assert
      expect(topics).toBeInstanceOf(Array);
      expect(topics.length).toBeGreaterThan(0);
      // Topics should include capitalized words like "Weekly", "Tech", "Newsletter", "AI"
    });
  });
});
```

### 8. API Route Tests

**File: `tests/unit/routes/email.routes.test.ts`**

```typescript
import request from 'supertest';
import express from 'express';
import emailRoutes from '../../../routes/email.routes';
import { EmailController } from '../../../controllers/email.controller';
import { authMiddleware } from '../../../middleware/auth.middleware';
import sinon from 'sinon';

// Mock auth middleware
jest.mock('../../../middleware/auth.middleware', () => ({
  authMiddleware: jest.fn((req, res, next) => {
    req.user = { id: 'user123' };
    next();
  })
}));

describe('Email Routes', () => {
  let app: express.Application;
  
  beforeEach(() => {
    // Create Express app
    app = express();
    app.use(express.json());
    
    // Apply routes
    app.use('/api', emailRoutes);
  });
  
  afterEach(() => {
    sinon.restore();
    jest.clearAllMocks();
  });
  
  describe('GET /api/senders', () => {
    it('should return senders', async () => {
      // Arrange
      const getSendersSpy = sinon.stub(EmailController.prototype, 'getSenders')
        .callsFake((req, res) => {
          res.json({
            success: true,
            data: {
              senders: [
                {
                  id: 'sender1',
                  name: 'Stripe',
                  email: 'receipts@stripe.com'
                }
              ],
              pagination: {
                page: 1,
                limit: 50,
                total: 1,
                pages: 1
              }
            }
          });
        });
      
      // Act
      const response = await request(app).get('/api/senders');
      
      // Assert
      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.senders).toBeInstanceOf(Array);
      expect(getSendersSpy.calledOnce).toBe(true);
    });
  });
  
  describe('POST /api/senders/scan', () => {
    it('should start email scan', async () => {
      // Arrange
      const scanEmailsSpy = sinon.stub(EmailController.prototype, 'scanEmails')
        .callsFake((req, res) => {
          res.json({
            success: true,
            data: {
              jobId: 'job123',
              status: 'processing',
              estimatedCompletion: new Date()
            }
          });
        });
      
      // Act
      const response = await request(app)
        .post('/api/senders/scan')
        .send({ provider: 'gmail' });
      
      // Assert
      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.jobId).toBe('job123');
      expect(scanEmailsSpy.calledOnce).toBe(true);
    });
  });
  
  describe('GET /api/senders/scan/:jobId', () => {
    it('should return scan status', async () => {
      // Arrange
      const getScanStatusSpy = sinon.stub(EmailController.prototype, 'getScanStatus')
        .callsFake((req, res) => {
          res.json({
            success: true,
            data: {
              jobId: 'job123',
              status: 'completed',
              progress: 100,
              sendersFound: 10,
              newSenders: 5
            }
          });
        });
      
      // Act
      const response = await request(app).get('/api/senders/scan/job123');
      
      // Assert
      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.jobId).toBe('job123');
      expect(response.body.data.status).toBe('completed');
      expect(getScanStatusSpy.calledOnce).toBe(true);
    });
  });
  
  describe('PUT /api/senders/:id/category', () => {
    it('should update sender category', async () => {
      // Arrange
      const updateSenderCategorySpy = sinon.stub(EmailController.prototype, 'updateSenderCategory')
        .callsFake((req, res) => {
          res.json({
            success: true,
            data: {
              sender: {
                id: 'sender123',
                category: 'call-me',
                updatedAt: new Date()
              }
            }
          });
        });
      
      // Act
      const response = await request(app)
        .put('/api/senders/sender123/category')
        .send({ category: 'call-me' });
      
      // Assert
      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.sender.id).toBe('sender123');
      expect(response.body.data.sender.category).toBe('call-me');
      expect(updateSenderCategorySpy.calledOnce).toBe(true);
    });
  });
  
  describe('POST /api/senders/bulk-update', () => {
    it('should bulk update senders', async () => {
      // Arrange
      const bulkUpdateSendersSpy = sinon.stub(EmailController.prototype, 'bulkUpdateSenders')
        .callsFake((req, res) => {
          res.json({
            success: true,
            data: {
              updatedCount: 2,
              results: [
                { senderId: 'sender1', status: 'updated' },
                { senderId: 'sender2', status: 'updated' }
              ]
            }
          });
        });
      
      // Act
      const response = await request(app)
        .post('/api/senders/bulk-update')
        .send({
          updates: [
            { senderId: 'sender1', category: 'call-me' },
            { senderId: 'sender2', category: 'remind-me' }
          ]
        });
      
      // Assert
      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.updatedCount).toBe(2);
      expect(response.body.data.results).toBeInstanceOf(Array);
      expect(bulkUpdateSendersSpy.calledOnce).toBe(true);
    });
  });
  
  describe('GET /api/emails/preview/:senderId', () => {
    it('should return email preview', async () => {
      // Arrange
      const getEmailPreviewSpy = sinon.stub(EmailController.prototype, 'getEmailPreview')
        .callsFake((req, res) => {
          res.json({
            success: true,
            data: {
              emails: [
                {
                  id: 'email1',
                  subject: 'Payment Receipt',
                  receivedAt: new Date(),
                  snippet: 'Your payment was successful',
                  isRead: false,
                  hasAttachments: false
                }
              ]
            }
          });
        });
      
      // Act
      const response = await request(app).get('/api/emails/preview/sender123');
      
      // Assert
      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.emails).toBeInstanceOf(Array);
      expect(getEmailPreviewSpy.calledOnce).toBe(true);
    });
  });
});
```

## Test Execution Strategy

### 1. Unit Test Execution

```bash
# Run all unit tests
npm test

# Run specific test file
npm test -- tests/unit/services/gmail.service.test.ts

# Run tests with coverage
npm test -- --coverage
```

### 2. Test Coverage Goals

- **Controllers**: 90%+ coverage
- **Services**: 85%+ coverage
- **Models**: 80%+ coverage
- **Routes**: 90%+ coverage

### 3. Mocking Strategy

1. **External APIs**:
   - Gmail API: Mock responses for authentication, message retrieval, and search
   - Twilio API: Mock call initiation and status webhooks
   - ElevenLabs API: Mock audio generation responses

2. **Database Models**:
   - Use Sinon to stub model methods (findOne, findAll, create, update, etc.)
   - Create mock data that matches expected model structures

3. **File System**:
   - Mock file read/write operations for credential files

### 4. Error Handling Tests

For each component, include tests for:
- Missing required parameters
- Invalid parameter values
- Database errors
- External API failures
- Authentication failures
- Rate limiting and quota issues

### 5. Edge Case Testing

- Empty email lists
- Very large email counts
- Malformed email addresses
- Special characters in email content
- Token expiration during operations
- Concurrent operations

## Integration Testing Strategy

After unit tests pass, implement integration tests to verify:

1. **Email Flow**:
   - Gmail authentication
   - Email scanning
   - Sender categorization
   - Domain bucketing

2. **Call Flow**:
   - Transcript generation
   - Audio synthesis
   - Call scheduling
   - Status updates

3. **Newsletter Flow**:
   - Content extraction
   - Summarization
   - Digest generation

## Next Steps

1. **Implement Unit Tests**:
   - Create test files following the structure above
   - Implement tests for all controllers and services
   - Verify error handling and edge cases

2. **Run Tests and Fix Issues**:
   - Execute tests and address any failures
   - Refine implementation based on test results
   - Ensure all critical paths are covered

3. **Prepare for Integration Testing**:
   - Set up test environment with mock Gmail API
   - Create test data for integration scenarios
   - Implement integration test cases
