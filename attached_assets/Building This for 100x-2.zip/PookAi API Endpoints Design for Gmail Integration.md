# PookAi API Endpoints Design for Gmail Integration

## Overview

This document outlines the API endpoints needed to integrate the gmail-inbox library with PookAi's backend, supporting the email categorization, parsing, and voice call features required for the buildathon.

## Gmail Integration Endpoints

### Authentication & Connection

#### `POST /api/integrations/email/connect`
- **Purpose**: Connect user's Gmail account via OAuth
- **Request Body**:
  ```json
  {
    "provider": "gmail",
    "authCode": "oauth_authorization_code",
    "redirectUri": "https://pookai.com/auth/callback"
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "integration": {
        "id": "integration_123",
        "provider": "gmail",
        "email": "founder@startup.com",
        "status": "connected",
        "connectedAt": "2025-05-31T10:30:00Z"
      }
    }
  }
  ```
- **Implementation Notes**:
  - Uses gmail-inbox's `authenticateAccount()` method
  - Stores OAuth tokens securely for future API calls
  - Handles token refresh and expiration

#### `GET /api/integrations/email/status`
- **Purpose**: Check Gmail connection status
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "connected": true,
      "provider": "gmail",
      "email": "founder@startup.com",
      "lastSync": "2025-05-31T09:00:00Z",
      "permissions": ["read", "metadata"],
      "health": "healthy"
    }
  }
  ```

### Email Scanning & Retrieval

#### `POST /api/senders/scan`
- **Purpose**: Trigger Gmail inbox scan to identify senders
- **Request Body**:
  ```json
  {
    "provider": "gmail",
    "forceRescan": false,
    "lookbackDays": 30
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "jobId": "scan_789",
      "status": "processing",
      "estimatedCompletion": "2025-05-31T10:45:00Z"
    }
  }
  ```
- **Implementation Notes**:
  - Uses gmail-inbox's `getLatestMessages()` method
  - Processes emails in batches to avoid rate limits
  - Extracts sender information and categorizes by domain
  - Runs as background job with progress tracking

#### `GET /api/senders/scan/:jobId`
- **Purpose**: Check status of email scan job
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "jobId": "scan_789",
      "status": "completed",
      "progress": 100,
      "sendersFound": 156,
      "newSenders": 12,
      "completedAt": "2025-05-31T10:42:00Z"
    }
  }
  ```

#### `GET /api/senders`
- **Purpose**: Retrieve all email senders for the authenticated user
- **Query Parameters**:
  - `page` (optional): Page number for pagination (default: 1)
  - `limit` (optional): Items per page (default: 50, max: 100)
  - `category` (optional): Filter by category
  - `search` (optional): Search sender names or emails
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "senders": [
        {
          "id": "sender_456",
          "name": "Stripe",
          "email": "receipts@stripe.com",
          "domain": "stripe.com",
          "category": "call-me",
          "emailCount": 42,
          "latestSubject": "Payment failed for subscription",
          "latestDate": "2025-05-31T09:15:00Z",
          "latestPreview": "Your payment method was declined...",
          "type": "tool",
          "avatar": "https://logo.clearbit.com/stripe.com"
        }
      ],
      "pagination": {
        "page": 1,
        "limit": 20,
        "total": 156,
        "pages": 8
      }
    }
  }
  ```
- **Implementation Notes**:
  - Uses cached sender data from scan job
  - Supports filtering by category, domain, and search terms
  - Includes pagination for large sender lists

### Email Categorization

#### `PUT /api/senders/:id/category`
- **Purpose**: Update category for a specific sender
- **Request Body**:
  ```json
  {
    "category": "call-me"
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "sender": {
        "id": "sender_456",
        "category": "call-me",
        "updatedAt": "2025-05-31T10:30:00Z"
      }
    }
  }
  ```

#### `POST /api/senders/bulk-update`
- **Purpose**: Update categories for multiple senders
- **Request Body**:
  ```json
  {
    "updates": [
      {"senderId": "sender_456", "category": "call-me"},
      {"senderId": "sender_789", "category": "keep-quiet"},
      {"senderId": "sender_012", "category": "remind-me"}
    ]
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "updatedCount": 3,
      "results": [
        {"senderId": "sender_456", "status": "updated"},
        {"senderId": "sender_789", "status": "updated"},
        {"senderId": "sender_012", "status": "updated"}
      ]
    }
  }
  ```

### Email Content & Processing

#### `GET /api/emails/preview/:senderId`
- **Purpose**: Get preview of latest emails from a specific sender
- **Query Parameters**:
  - `limit` (optional): Number of emails to retrieve (default: 5)
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "emails": [
        {
          "id": "email_123",
          "subject": "Payment failed for subscription",
          "receivedAt": "2025-05-31T09:15:00Z",
          "snippet": "Your payment method was declined...",
          "isRead": false,
          "hasAttachments": false
        }
      ]
    }
  }
  ```
- **Implementation Notes**:
  - Uses gmail-inbox's `findMessages()` method with sender-specific query
  - Retrieves only metadata for preview purposes
  - Caches results for performance

#### `GET /api/emails/:emailId`
- **Purpose**: Get full content of a specific email
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "email": {
        "id": "email_123",
        "threadId": "thread_456",
        "subject": "Payment failed for subscription",
        "from": {
          "name": "Stripe Payments",
          "email": "receipts@stripe.com"
        },
        "to": {
          "name": "Jane Founder",
          "email": "founder@startup.com"
        },
        "receivedAt": "2025-05-31T09:15:00Z",
        "body": {
          "html": "<html>...</html>",
          "text": "Your payment method was declined..."
        },
        "attachments": []
      }
    }
  }
  ```
- **Implementation Notes**:
  - Uses gmail-inbox's `getMessageById()` method
  - Processes HTML content for security
  - Extracts plain text for voice synthesis

### Domain Bucketing & Analysis

#### `GET /api/domains/analysis`
- **Purpose**: Get domain-based analysis of email senders
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "domains": [
        {
          "domain": "stripe.com",
          "senderCount": 3,
          "emailCount": 42,
          "categories": {
            "call-me": 1,
            "remind-me": 2
          },
          "type": "tool"
        }
      ]
    }
  }
  ```
- **Implementation Notes**:
  - Aggregates sender data by domain
  - Provides statistics for domain-level categorization
  - Helps identify patterns across similar senders

#### `POST /api/domains/categorize`
- **Purpose**: Categorize all senders from a specific domain
- **Request Body**:
  ```json
  {
    "domain": "stripe.com",
    "category": "call-me"
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "updatedCount": 3,
      "domain": "stripe.com"
    }
  }
  ```

### User Recommendations

#### `GET /api/recommendations/senders`
- **Purpose**: Get AI-generated categorization recommendations for senders
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "recommendations": [
        {
          "senderId": "sender_456",
          "currentCategory": "unassigned",
          "recommendedCategory": "call-me",
          "confidence": 0.92,
          "reason": "Financial service emails often contain important payment information"
        }
      ]
    }
  }
  ```
- **Implementation Notes**:
  - Uses sender patterns and domain information
  - Applies heuristics based on email content and frequency
  - Improves with user feedback

#### `POST /api/recommendations/apply`
- **Purpose**: Apply recommended categories to senders
- **Request Body**:
  ```json
  {
    "applyAll": true,
    "minConfidence": 0.8,
    "senderIds": ["sender_456", "sender_789"]
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "appliedCount": 2,
      "skippedCount": 0
    }
  }
  ```

## Call Management Endpoints

### Call Scheduling & Content

#### `POST /api/calls/schedule-urgent`
- **Purpose**: Schedule immediate call for urgent notifications
- **Request Body**:
  ```json
  {
    "content": "Critical payment failure from Stripe",
    "priority": "high",
    "context": {
      "senderIds": ["sender_456"],
      "emailIds": ["email_789"]
    }
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "call": {
        "id": "call_456",
        "type": "urgent",
        "status": "scheduled",
        "scheduledAt": "2025-05-31T10:35:00Z",
        "estimatedDuration": 120
      }
    }
  }
  ```

#### `GET /api/calls/next-digest`
- **Purpose**: Get preview of next scheduled digest call
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "nextCall": {
        "scheduledAt": "2025-06-01T09:00:00Z",
        "contentPreview": {
          "callMeItems": 2,
          "remindMeItems": 5,
          "meetingReminders": 3,
          "topSenders": ["Stripe", "Y Combinator", "GitHub"]
        },
        "estimatedDuration": 180
      }
    }
  }
  ```

#### `POST /api/calls/generate-transcript`
- **Purpose**: Generate call transcript from email content
- **Request Body**:
  ```json
  {
    "emailIds": ["email_123", "email_456"],
    "callType": "urgent",
    "voiceId": "nova"
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "transcript": "Hey there! Quick update: Your Stripe payment for the Pro plan failed. The card ending in 4242 was declined. You might want to update your payment method soon to avoid service interruption.",
      "estimatedDuration": 12,
      "wordCount": 32
    }
  }
  ```
- **Implementation Notes**:
  - Processes email content for voice synthesis
  - Formats content based on call type and urgency
  - Optimizes for natural speech patterns

### Newsletter Summarization

#### `POST /api/newsletters/summarize`
- **Purpose**: Generate summaries of newsletter emails
- **Request Body**:
  ```json
  {
    "emailIds": ["email_123", "email_456"],
    "maxLength": 200
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "summaries": [
        {
          "emailId": "email_123",
          "subject": "This Week in Startups",
          "summary": "Key points: 1) Funding rounds slowed by 15% this quarter, 2) New AI regulations proposed in EU, 3) Top YC companies focusing on healthcare tech",
          "keyTopics": ["funding", "regulations", "healthcare"]
        }
      ]
    }
  }
  ```
- **Implementation Notes**:
  - Extracts key information from newsletter content
  - Focuses on actionable insights for founders
  - Formats for both text and voice delivery

## Integration with External Services

### Twilio Integration

#### `POST /api/calls/twilio/initiate`
- **Purpose**: Initiate Twilio call with generated transcript
- **Request Body**:
  ```json
  {
    "callId": "call_456",
    "phoneNumber": "+15551234567",
    "transcript": "Hey there! Quick update about your Stripe payment..."
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "twilioCallId": "CA123456789",
      "status": "initiated",
      "estimatedStartTime": "2025-05-31T10:36:00Z"
    }
  }
  ```

#### `POST /api/calls/twilio/status-webhook`
- **Purpose**: Receive call status updates from Twilio
- **Request Body** (from Twilio):
  ```json
  {
    "CallSid": "CA123456789",
    "CallStatus": "completed",
    "CallDuration": "45",
    "Timestamp": "2025-05-31T10:37:00Z"
  }
  ```
- **Response**:
  ```json
  {
    "success": true
  }
  ```

### ElevenLabs Integration

#### `POST /api/voice/generate`
- **Purpose**: Generate voice audio from transcript using ElevenLabs
- **Request Body**:
  ```json
  {
    "text": "Hey there! Quick update about your Stripe payment...",
    "voiceId": "nova",
    "stability": 0.5,
    "similarityBoost": 0.7
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "audioUrl": "https://storage.pookai.com/audio/call_456.mp3",
      "durationSeconds": 12,
      "wordCount": 32
    }
  }
  ```

## Database Schema Requirements

To support these endpoints, the following database schema will be needed:

1. **Users Table**
   - User authentication and profile information

2. **EmailIntegrations Table**
   - OAuth tokens and connection status for Gmail

3. **EmailSenders Table**
   - Sender information extracted from emails
   - Category assignments and metadata

4. **Emails Table**
   - Email metadata (not full content)
   - References to senders

5. **Domains Table**
   - Domain-level aggregation and categorization

6. **UserPreferences Table**
   - Call settings and notification preferences

7. **Calls Table**
   - Call history, status, and content references

8. **CallTranscripts Table**
   - Generated voice transcripts and metadata

## Implementation Priorities

1. **Authentication & Email Scanning**
   - Gmail OAuth integration
   - Basic email scanning and sender extraction

2. **Sender Categorization**
   - Sender storage and category assignment
   - Bulk update capabilities

3. **Domain Bucketing**
   - Domain-level analysis and categorization
   - Recommendation engine

4. **Call Management**
   - Transcript generation
   - Twilio integration

5. **Newsletter Summarization**
   - Content extraction and summarization
   - Voice-optimized formatting
