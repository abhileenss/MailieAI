# PookAi End-to-End Integration Flow

## Overview

This document outlines the implementation and testing of the complete end-to-end integration flow for the PookAi project. The flow encompasses the entire process from email retrieval to voice call delivery, ensuring all components work together seamlessly.

## Integration Flow Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Gmail API  │────▶│ Email Parser │────▶│ Categorizer │────▶│ DB Storage  │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
                                                                   │
                                                                   ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Twilio API │◀────│ Voice Call  │◀────│ Transcript  │◀────│ Scheduler   │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
       │                                        ▲
       │                                        │
       ▼                                        │
┌─────────────┐                         ┌─────────────┐
│  User Phone │                         │ ElevenLabs  │
└─────────────┘                         └─────────────┘
```

## Implementation Steps

### 1. Email Retrieval and Processing Flow

```typescript
// server/src/controllers/integration.controller.ts
import { Request, Response } from 'express';
import { EmailIntegration, ScanJob } from '../models';
import { GmailService } from '../services/gmail.service';
import { logger } from '../utils/logger';

export class IntegrationController {
  // Connect email account
  async connectEmail(req: Request, res: Response) {
    try {
      const { provider, authCode, redirectUri } = req.body;
      const userId = req.user.id;
      
      if (!provider || !authCode) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Provider and authCode are required'
          }
        });
      }
      
      if (provider !== 'gmail') {
        return res.status(400).json({
          success: false,
          error: {
            code: 'UNSUPPORTED_PROVIDER',
            message: 'Only Gmail is supported at this time'
          }
        });
      }
      
      // Exchange auth code for tokens
      const tokens = await this.exchangeAuthCode(authCode, redirectUri);
      
      // Get user email from Google
      const email = await this.getUserEmail(tokens.access_token);
      
      // Calculate token expiry
      const expiryDate = new Date();
      expiryDate.setSeconds(expiryDate.getSeconds() + tokens.expires_in);
      
      // Check if integration already exists
      const existingIntegration = await EmailIntegration.findOne({
        where: {
          user_id: userId,
          provider,
          email
        }
      });
      
      let integration;
      
      if (existingIntegration) {
        // Update existing integration
        await EmailIntegration.update({
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token || existingIntegration.refresh_token,
          token_expiry: expiryDate,
          scopes: tokens.scope.split(' '),
          status: 'connected',
          last_connected_at: new Date()
        }, {
          where: {
            id: existingIntegration.id
          }
        });
        
        integration = existingIntegration;
      } else {
        // Create new integration
        integration = await EmailIntegration.create({
          user_id: userId,
          provider,
          email,
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token,
          token_expiry: expiryDate,
          scopes: tokens.scope.split(' '),
          status: 'connected',
          last_connected_at: new Date()
        });
      }
      
      return res.json({
        success: true,
        data: {
          integration: {
            id: integration.id,
            provider: integration.provider,
            email: integration.email,
            status: 'connected',
            connectedAt: integration.last_connected_at
          }
        }
      });
    } catch (error) {
      logger.error('Failed to connect email account:', error);
      return res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to connect email account',
          details: error.message
        }
      });
    }
  }
  
  // Start email scan process
  async scanEmails(req: Request, res: Response) {
    try {
      const { provider = 'gmail', forceRescan = false } = req.body;
      const userId = req.user.id;
      
      // Check if scan already in progress
      const activeJob = await ScanJob.findOne({
        where: {
          user_id: userId,
          status: ['queued', 'processing']
        }
      });
      
      if (activeJob && !forceRescan) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'SCAN_IN_PROGRESS',
            message: 'A scan is already in progress',
            details: {
              jobId: activeJob.id,
              progress: activeJob.progress
            }
          }
        });
      }
      
      // Create new scan job
      const job = await ScanJob.create({
        user_id: userId,
        provider,
        status: 'queued',
        progress: 0,
        started_at: new Date()
      });
      
      // Start scan process in background
      this.startScanProcess(userId, job.id, provider);
      
      // Estimate completion time (5 minutes for now)
      const estimatedCompletion = new Date();
      estimatedCompletion.setMinutes(estimatedCompletion.getMinutes() + 5);
      
      return res.json({
        success: true,
        data: {
          jobId: job.id,
          status: 'processing',
          estimatedCompletion
        }
      });
    } catch (error) {
      logger.error('Failed to start email scan:', error);
      return res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to start email scan',
          details: error.message
        }
      });
    }
  }
  
  // Private method to start scan process
  private async startScanProcess(userId: string, jobId: string, provider: string) {
    try {
      // Update job status
      await ScanJob.update({
        status: 'processing',
        progress: 5
      }, {
        where: { id: jobId }
      });
      
      // Initialize Gmail service
      const gmailService = new GmailService(userId);
      const initialized = await gmailService.initialize();
      
      if (!initialized) {
        await ScanJob.update({
          status: 'failed',
          error_message: 'Failed to initialize Gmail service',
          completed_at: new Date()
        }, {
          where: { id: jobId }
        });
        return;
      }
      
      // Scan inbox
      await gmailService.scanInbox(jobId);
      
    } catch (error) {
      logger.error('Scan process failed:', error);
      await ScanJob.update({
        status: 'failed',
        error_message: error.message,
        completed_at: new Date()
      }, {
        where: { id: jobId }
      });
    }
  }
  
  // Private method to exchange auth code for tokens
  private async exchangeAuthCode(code: string, redirectUri: string) {
    // Implementation using Google OAuth API
    // ...
  }
  
  // Private method to get user email from Google
  private async getUserEmail(accessToken: string) {
    // Implementation using Google People API
    // ...
  }
}
```

### 2. Email Categorization and Domain Bucketing

```typescript
// server/src/services/gmail.service.ts
import { Inbox } from 'gmail-inbox';
import { EmailIntegration, EmailSender, EmailMetadata, Domain, ScanJob } from '../models';
import { logger } from '../utils/logger';

export class GmailService {
  private userId: string;
  private inbox: any;
  private initialized: boolean = false;
  
  constructor(userId: string) {
    this.userId = userId;
  }
  
  // Initialize Gmail service
  async initialize() {
    try {
      // Get user's Gmail integration
      const integration = await EmailIntegration.findOne({
        where: {
          user_id: this.userId,
          provider: 'gmail',
          status: 'connected'
        }
      });
      
      if (!integration) {
        logger.warn(`No active Gmail integration found for user ${this.userId}`);
        return false;
      }
      
      // Initialize inbox with tokens
      this.inbox = new Inbox({
        clientId: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        redirectUri: process.env.GOOGLE_REDIRECT_URI,
        accessToken: integration.access_token,
        refreshToken: integration.refresh_token
      });
      
      // Authenticate
      await this.inbox.authenticateAccount();
      this.initialized = true;
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize Gmail service:', error);
      throw error;
    }
  }
  
  // Scan inbox and process messages
  async scanInbox(jobId: string) {
    if (!this.initialized) {
      throw new Error('Gmail service not initialized');
    }
    
    try {
      // Update job status
      await ScanJob.update({
        status: 'processing',
        progress: 10
      }, {
        where: { id: jobId }
      });
      
      // Get latest messages (limit to 100 for now)
      const messages = await this.inbox.getLatestMessages(100);
      logger.info(`Retrieved ${messages.length} messages for user ${this.userId}`);
      
      // Update job progress
      await ScanJob.update({
        progress: 30
      }, {
        where: { id: jobId }
      });
      
      // Process messages
      let newSenders = 0;
      
      for (let i = 0; i < messages.length; i++) {
        const message = messages[i];
        
        // Extract sender information
        const email = this.extractEmailFromSender(message.from);
        const name = this.extractNameFromSender(message.from);
        const domain = this.extractDomainFromEmail(email);
        
        // Check if message already exists
        const existingEmail = await EmailMetadata.findOne({
          where: {
            user_id: this.userId,
            message_id: message.messageId
          }
        });
        
        if (existingEmail) {
          continue; // Skip if already processed
        }
        
        // Find or create domain
        let domainRecord = await Domain.findOne({
          where: {
            user_id: this.userId,
            domain_name: domain
          }
        });
        
        if (!domainRecord) {
          domainRecord = await Domain.create({
            user_id: this.userId,
            domain_name: domain,
            email_count: 1
          });
        } else {
          await domainRecord.increment('email_count');
        }
        
        // Find or create sender
        let sender = await EmailSender.findOne({
          where: {
            user_id: this.userId,
            email
          }
        });
        
        if (!sender) {
          sender = await EmailSender.create({
            user_id: this.userId,
            name,
            email,
            domain,
            category: this.guessSenderType(domain, message),
            email_count: 1,
            latest_subject: message.subject,
            latest_date: message.receivedOn,
            latest_preview: message.snippet
          });
          
          newSenders++;
        } else {
          await sender.update({
            email_count: sender.email_count + 1,
            latest_subject: message.subject,
            latest_date: message.receivedOn,
            latest_preview: message.snippet
          });
        }
        
        // Create email metadata
        await EmailMetadata.create({
          user_id: this.userId,
          message_id: message.messageId,
          thread_id: message.threadId,
          sender_id: sender.id,
          subject: message.subject,
          received_at: message.receivedOn,
          snippet: message.snippet,
          is_read: !message.labelIds.includes('UNREAD'),
          has_attachments: message.labelIds.includes('HAS_ATTACHMENT')
        });
        
        // Update job progress periodically
        if (i % 10 === 0) {
          const progress = Math.min(30 + Math.floor((i / messages.length) * 60), 90);
          await ScanJob.update({
            progress
          }, {
            where: { id: jobId }
          });
        }
      }
      
      // Update job status to completed
      await ScanJob.update({
        status: 'completed',
        progress: 100,
        senders_found: messages.length,
        new_senders: newSenders,
        completed_at: new Date()
      }, {
        where: { id: jobId }
      });
      
      logger.info(`Completed inbox scan for user ${this.userId}, processed ${messages.length} messages, found ${newSenders} new senders`);
      
    } catch (error) {
      logger.error('Failed to scan inbox:', error);
      
      // Update job status to failed
      await ScanJob.update({
        status: 'failed',
        error_message: error.message,
        completed_at: new Date()
      }, {
        where: { id: jobId }
      });
      
      throw error;
    }
  }
  
  // Find emails from a specific sender
  async findEmailsFromSender(senderId: string, limit: number = 10) {
    if (!this.initialized) {
      throw new Error('Gmail service not initialized');
    }
    
    try {
      // Get sender
      const sender = await EmailSender.findOne({
        where: {
          id: senderId,
          user_id: this.userId
        }
      });
      
      if (!sender) {
        throw new Error(`Sender not found: ${senderId}`);
      }
      
      // Search for emails from this sender
      const query = `from:${sender.email}`;
      const messages = await this.inbox.findMessages(query, limit);
      
      return messages;
    } catch (error) {
      logger.error(`Failed to find emails from sender ${senderId}:`, error);
      throw error;
    }
  }
  
  // Get full email content
  async getEmailContent(messageId: string) {
    if (!this.initialized) {
      throw new Error('Gmail service not initialized');
    }
    
    try {
      const message = await this.inbox.getMessageById(messageId);
      return message;
    } catch (error) {
      logger.error(`Failed to get email content for message ${messageId}:`, error);
      throw error;
    }
  }
  
  // Private helper methods
  private extractEmailFromSender(from: string): string {
    const match = from.match(/<([^>]+)>/);
    return match ? match[1] : from;
  }
  
  private extractNameFromSender(from: string): string {
    const match = from.match(/([^<]+)</);
    return match ? match[1].trim() : null;
  }
  
  private extractDomainFromEmail(email: string): string {
    const parts = email.split('@');
    return parts.length > 1 ? parts[1] : null;
  }
  
  private guessSenderType(domain: string, message: any): string {
    // Simple heuristic for now, can be improved with ML later
    const subject = message.subject.toLowerCase();
    const snippet = message.snippet ? message.snippet.toLowerCase() : '';
    
    // Check for newsletter indicators
    if (
      domain.includes('newsletter') ||
      domain.includes('updates') ||
      subject.includes('newsletter') ||
      subject.includes('digest') ||
      subject.includes('weekly')
    ) {
      return 'newsletter';
    }
    
    // Check for urgent/important indicators
    if (
      subject.includes('urgent') ||
      subject.includes('important') ||
      subject.includes('action required') ||
      subject.includes('payment') ||
      subject.includes('invoice') ||
      snippet.includes('urgent') ||
      snippet.includes('payment')
    ) {
      return 'call-me';
    }
    
    // Check for reminder indicators
    if (
      subject.includes('reminder') ||
      subject.includes('don\'t forget') ||
      subject.includes('upcoming') ||
      subject.includes('meeting') ||
      snippet.includes('reminder') ||
      snippet.includes('meeting')
    ) {
      return 'remind-me';
    }
    
    // Default to ignore
    return 'ignore';
  }
}
```

### 3. Call Scheduling and Transcript Generation

```typescript
// server/src/controllers/call.controller.ts
import { Request, Response } from 'express';
import { Call, CallTranscript, CallEmailReference, EmailMetadata, UserPreferences, EmailSender } from '../models';
import { TwilioService } from '../services/twilio.service';
import { ElevenLabsService } from '../services/elevenlabs.service';
import { logger } from '../utils/logger';
import { Op } from 'sequelize';

export class CallController {
  // Schedule an urgent call
  async scheduleUrgentCall(req: Request, res: Response) {
    try {
      const { content, priority = 'medium', context = {} } = req.body;
      const userId = req.user.id;
      
      if (!content) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Content is required'
          }
        });
      }
      
      // Get user preferences for voice
      const preferences = await UserPreferences.findOne({
        where: { user_id: userId }
      });
      
      const voiceId = preferences?.voice_preference || 'nova'; // Default voice
      
      // Create transcript
      const transcript = await CallTranscript.create({
        user_id: userId,
        transcript_text: content,
        voice_id: voiceId
      });
      
      // Calculate call time (immediate for urgent calls)
      const callTime = new Date();
      callTime.setMinutes(callTime.getMinutes() + 1); // 1 minute from now
      
      // Create call record
      const call = await Call.create({
        user_id: userId,
        call_type: 'urgent',
        status: 'scheduled',
        scheduled_at: callTime,
        content_summary: content,
        transcript_id: transcript.id,
        priority
      });
      
      // Add email references if provided
      if (context.emailIds && Array.isArray(context.emailIds)) {
        for (const emailId of context.emailIds) {
          await CallEmailReference.create({
            call_id: call.id,
            email_id: emailId
          });
        }
      }
      
      // Process urgent call immediately
      this.processUrgentCall(call.id);
      
      // Estimate call duration (30 seconds per 100 characters)
      const estimatedDuration = Math.max(60, Math.ceil(content.length / 100) * 30);
      
      return res.json({
        success: true,
        data: {
          call: {
            id: call.id,
            type: 'urgent',
            status: 'scheduled',
            scheduledAt: callTime,
            estimatedDuration
          }
        }
      });
    } catch (error) {
      logger.error('Failed to schedule urgent call:', error);
      return res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to schedule urgent call',
          details: error.message
        }
      });
    }
  }
  
  // Get next digest call preview
  async getNextDigestCall(req: Request, res: Response) {
    try {
      const userId = req.user.id;
      
      // Get user preferences
      const preferences = await UserPreferences.findOne({
        where: { user_id: userId }
      });
      
      // Determine next call time based on preferences
      const preferredTime = preferences?.preferred_call_time || '09:00';
      const [hours, minutes] = preferredTime.split(':').map(Number);
      
      const now = new Date();
      const nextCall = new Date();
      nextCall.setHours(hours, minutes, 0, 0);
      
      // If preferred time is already past for today, schedule for tomorrow
      if (nextCall <= now) {
        nextCall.setDate(nextCall.getDate() + 1);
      }
      
      // Count emails by category
      const callMeCount = await EmailSender.count({
        where: {
          user_id: userId,
          category: 'call-me'
        }
      });
      
      const remindMeCount = await EmailSender.count({
        where: {
          user_id: userId,
          category: 'remind-me'
        }
      });
      
      // Get top senders
      const topSenders = await EmailSender.findAll({
        where: {
          user_id: userId,
          category: {
            [Op.in]: ['call-me', 'remind-me']
          }
        },
        order: [['email_count', 'DESC']],
        limit: 5
      });
      
      // Format sender names
      const senderNames = topSenders.map(sender => sender.name || sender.domain);
      
      // Estimate call duration (3 minutes for digest calls)
      const estimatedDuration = 180;
      
      return res.json({
        success: true,
        data: {
          nextCall: {
            scheduledAt: nextCall,
            contentPreview: {
              callMeItems: callMeCount,
              remindMeItems: remindMeCount,
              meetingReminders: 0, // Future feature
              topSenders: senderNames
            },
            estimatedDuration
          }
        }
      });
    } catch (error) {
      logger.error('Failed to get next digest call:', error);
      return res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to get next digest call',
          details: error.message
        }
      });
    }
  }
  
  // Generate transcript from email content
  async generateTranscript(req: Request, res: Response) {
    try {
      const { emailIds, callType = 'urgent', voiceId = 'nova' } = req.body;
      const userId = req.user.id;
      
      if (!emailIds || !Array.isArray(emailIds) || emailIds.length === 0) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Email IDs are required'
          }
        });
      }
      
      // Get email content
      const emails = await EmailMetadata.findAll({
        where: {
          id: {
            [Op.in]: emailIds
          },
          user_id: userId
        },
        include: [
          {
            model: EmailSender,
            as: 'sender'
          }
        ]
      });
      
      if (emails.length === 0) {
        return res.status(404).json({
          success: false,
          error: {
            code: 'EMAILS_NOT_FOUND',
            message: 'No emails found with the provided IDs'
          }
        });
      }
      
      // Generate transcript based on call type
      let transcript;
      if (callType === 'urgent') {
        transcript = this.generateUrgentTranscript(emails);
      } else if (callType === 'digest') {
        transcript = this.generateDigestTranscript(emails);
      } else {
        transcript = this.generateGenericTranscript(emails);
      }
      
      // Estimate duration (30 seconds per 100 characters)
      const wordCount = transcript.split(' ').length;
      const estimatedDuration = Math.max(60, Math.ceil(wordCount / 30) * 10);
      
      return res.json({
        success: true,
        data: {
          transcript,
          estimatedDuration,
          wordCount
        }
      });
    } catch (error) {
      logger.error('Failed to generate transcript:', error);
      return res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to generate transcript',
          details: error.message
        }
      });
    }
  }
  
  // Private method to process urgent call
  private async processUrgentCall(callId: string) {
    try {
      // Get call details
      const call = await Call.findByPk(callId, {
        include: [
          {
            model: CallTranscript,
            as: 'transcript'
          }
        ]
      });
      
      if (!call) {
        logger.error(`Call not found: ${callId}`);
        return;
      }
      
      // Update call status
      await call.update({
        status: 'processing'
      });
      
      // Generate audio using ElevenLabs
      const elevenLabsService = new ElevenLabsService();
      const audioUrl = await elevenLabsService.generateAudio(
        call.transcript.transcript_text,
        call.transcript.voice_id
      );
      
      // Update call with audio URL
      await call.update({
        audio_url: audioUrl
      });
      
      // Get user's phone number
      const preferences = await UserPreferences.findOne({
        where: { user_id: call.user_id }
      });
      
      if (!preferences || !preferences.phone_number) {
        logger.error(`No phone number found for user ${call.user_id}`);
        await call.update({
          status: 'failed',
          error_message: 'No phone number configured'
        });
        return;
      }
      
      // Initiate call using Twilio
      const twilioService = new TwilioService();
      const callSid = await twilioService.initiateCall(
        preferences.phone_number,
        audioUrl,
        callId
      );
      
      // Update call with Twilio SID
      await call.update({
        status: 'in-progress',
        twilio_call_sid: callSid
      });
      
      logger.info(`Initiated urgent call ${callId} with Twilio SID ${callSid}`);
      
    } catch (error) {
      logger.error(`Failed to process urgent call ${callId}:`, error);
      
      // Update call status to failed
      await Call.update({
        status: 'failed',
        error_message: error.message
      }, {
        where: { id: callId }
      });
    }
  }
  
  // Private method to generate urgent transcript
  private generateUrgentTranscript(emails: any[]): string {
    // Simple template for now, can be improved with more context
    const intro = "Hey there! Quick urgent update: ";
    
    const emailSummaries = emails.map(email => {
      const sender = email.sender.name || email.sender.email.split('@')[0];
      return `${sender} sent an email with the subject "${email.subject}". Here's a preview: ${email.snippet}`;
    }).join(' ');
    
    const outro = "This seemed important based on your preferences, so I wanted to let you know right away.";
    
    return `${intro}${emailSummaries} ${outro}`;
  }
  
  // Private method to generate digest transcript
  private generateDigestTranscript(emails: any[]): string {
    const intro = "Good morning! Here's your daily email digest. ";
    
    const summary = `You have ${emails.length} important emails that need your attention. `;
    
    const emailSummaries = emails.map(email => {
      const sender = email.sender.name || email.sender.email.split('@')[0];
      return `${sender} sent "${email.subject}"`;
    }).join('. ');
    
    const outro = "Would you like me to read any of these in detail? Just let me know which ones interest you.";
    
    return `${intro}${summary}${emailSummaries}. ${outro}`;
  }
  
  // Private method to generate generic transcript
  private generateGenericTranscript(emails: any[]): string {
    return `You have ${emails.length} new messages. ${emails.map(e => e.subject).join('. ')}`;
  }
}
```

### 4. Voice Synthesis and Call Execution

```typescript
// server/src/services/elevenlabs.service.ts
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { Storage } from '@google-cloud/storage';
import { logger } from '../utils/logger';

export class ElevenLabsService {
  private apiKey: string;
  private baseUrl: string = 'https://api.elevenlabs.io/v1';
  private storage: Storage;
  private bucketName: string;
  
  constructor() {
    this.apiKey = process.env.ELEVENLABS_API_KEY;
    
    // Initialize Google Cloud Storage
    this.storage = new Storage();
    this.bucketName = process.env.GCS_BUCKET_NAME || 'pookai-audio';
  }
  
  // Generate audio from text
  async generateAudio(text: string, voiceId: string = 'nova'): Promise<string> {
    if (!this.apiKey) {
      throw new Error('ElevenLabs API key not configured');
    }
    
    try {
      // Call ElevenLabs API
      const response = await axios.post(
        `${this.baseUrl}/text-to-speech/${voiceId}`,
        {
          text,
          model_id: 'eleven_monolingual_v1',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75
          }
        },
        {
          headers: {
            'xi-api-key': this.apiKey,
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg'
          },
          responseType: 'arraybuffer'
        }
      );
      
      // Generate unique filename
      const filename = `call_${uuidv4()}.mp3`;
      
      // Upload to Google Cloud Storage
      const file = this.storage.bucket(this.bucketName).file(filename);
      await file.save(response.data, {
        metadata: {
          contentType: 'audio/mpeg'
        }
      });
      
      // Make file publicly accessible
      await file.makePublic();
      
      // Get public URL
      const publicUrl = `https://storage.googleapis.com/${this.bucketName}/${filename}`;
      
      logger.info(`Generated audio file: ${publicUrl}`);
      return publicUrl;
      
    } catch (error) {
      logger.error('Failed to generate audio:', error);
      throw error;
    }
  }
  
  // Get available voices
  async getVoices() {
    if (!this.apiKey) {
      throw new Error('ElevenLabs API key not configured');
    }
    
    try {
      const response = await axios.get(
        `${this.baseUrl}/voices`,
        {
          headers: {
            'xi-api-key': this.apiKey,
            'Content-Type': 'application/json'
          }
        }
      );
      
      return response.data.voices.map(voice => ({
        voice_id: voice.voice_id,
        name: voice.name,
        description: voice.description || null,
        gender: this.guessGender(voice.name, voice.description)
      }));
      
    } catch (error) {
      logger.error('Failed to get voices:', error);
      throw error;
    }
  }
  
  // Helper method to guess gender from voice name/description
  private guessGender(name: string, description: string): string {
    const femaleIndicators = ['female', 'woman', 'girl', 'feminine'];
    const maleIndicators = ['male', 'man', 'boy', 'masculine'];
    
    const combinedText = `${name} ${description || ''}`.toLowerCase();
    
    if (femaleIndicators.some(term => combinedText.includes(term))) {
      return 'female';
    }
    
    if (maleIndicators.some(term => combinedText.includes(term))) {
      return 'male';
    }
    
    return 'unknown';
  }
}
```

```typescript
// server/src/services/twilio.service.ts
import twilio from 'twilio';
import { Call } from '../models';
import { logger } from '../utils/logger';

export class TwilioService {
  private client: any;
  private accountSid: string;
  private authToken: string;
  private phoneNumber: string;
  
  constructor() {
    this.accountSid = process.env.TWILIO_ACCOUNT_SID;
    this.authToken = process.env.TWILIO_AUTH_TOKEN;
    this.phoneNumber = process.env.TWILIO_PHONE_NUMBER;
    
    if (this.accountSid && this.authToken) {
      this.client = twilio(this.accountSid, this.authToken);
    }
  }
  
  // Initiate a call
  async initiateCall(to: string, audioUrl: string, callId: string): Promise<string> {
    if (!this.client) {
      throw new Error('Twilio credentials not configured');
    }
    
    try {
      // Create TwiML for the call
      const twiml = this.generateTwiML(audioUrl);
      
      // Create a TwiML Bin to host the TwiML
      const twimlBin = await this.client.twiml.twimlApps.create({
        friendlyName: `PookAi Call ${callId}`,
        voiceMethod: 'GET',
        voiceUrl: `data:application/xml;base64,${Buffer.from(twiml).toString('base64')}`
      });
      
      // Make the call
      const call = await this.client.calls.create({
        to,
        from: this.phoneNumber,
        applicationSid: twimlBin.sid,
        statusCallback: `${process.env.API_BASE_URL}/api/calls/webhook`,
        statusCallbackEvent: ['completed', 'failed', 'busy', 'no-answer'],
        statusCallbackMethod: 'POST'
      });
      
      logger.info(`Initiated call to ${to} with SID ${call.sid}`);
      return call.sid;
      
    } catch (error) {
      logger.error('Failed to initiate call:', error);
      throw error;
    }
  }
  
  // Generate TwiML for the call
  generateTwiML(audioUrl: string): string {
    return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Play>${audioUrl}</Play>
  <Say>This is the end of your PookAi update. Have a great day!</Say>
</Response>`;
  }
  
  // Process status webhook from Twilio
  async processStatusWebhook(data: any) {
    try {
      const { CallSid, CallStatus, CallDuration } = data;
      
      // Find call by Twilio SID
      const call = await Call.findOne({
        where: {
          twilio_call_sid: CallSid
        }
      });
      
      if (!call) {
        logger.warn(`Call not found for Twilio SID ${CallSid}`);
        return;
      }
      
      // Update call status
      if (CallStatus === 'completed') {
        await Call.update({
          status: 'completed',
          duration_seconds: parseInt(CallDuration, 10),
          completed_at: new Date()
        }, {
          where: {
            id: call.id
          }
        });
        
        logger.info(`Call ${call.id} completed, duration: ${CallDuration} seconds`);
      } else if (['failed', 'busy', 'no-answer'].includes(CallStatus)) {
        await Call.update({
          status: 'failed',
          completed_at: new Date()
        }, {
          where: {
            id: call.id
          }
        });
        
        logger.warn(`Call ${call.id} failed with status: ${CallStatus}`);
      }
      
    } catch (error) {
      logger.error('Failed to process status webhook:', error);
    }
  }
}
```

### 5. Newsletter Summarization

```typescript
// server/src/services/newsletter.service.ts
import { EmailMetadata, NewsletterSummary, EmailSender } from '../models';
import { logger } from '../utils/logger';
import { Op } from 'sequelize';

export class NewsletterService {
  // Summarize newsletter emails
  async summarizeNewsletters(emailIds: string[], userId: string, maxLength: number = 500) {
    try {
      // Get email content
      const emails = await EmailMetadata.findAll({
        where: {
          id: {
            [Op.in]: emailIds
          },
          user_id: userId
        },
        include: [
          {
            model: EmailSender,
            as: 'sender'
          }
        ]
      });
      
      if (emails.length === 0) {
        return [];
      }
      
      const summaries = [];
      
      for (const email of emails) {
        // Check if summary already exists
        let summary = await NewsletterSummary.findOne({
          where: {
            user_id: userId,
            email_id: email.id
          }
        });
        
        if (!summary) {
          // Generate simple summary for now
          // In a real implementation, this would use an AI service
          const summaryText = this.generateSimpleSummary(email.snippet, maxLength);
          const keyTopics = this.extractKeyTopics(email.subject, email.snippet);
          
          // Create summary
          summary = await NewsletterSummary.create({
            user_id: userId,
            email_id: email.id,
            summary_text: summaryText,
            key_topics: keyTopics
          });
        }
        
        summaries.push({
          emailId: email.id,
          subject: email.subject,
          sender: {
            name: email.sender.name,
            email: email.sender.email
          },
          receivedAt: email.received_at,
          summary: summary.summary_text,
          keyTopics: summary.key_topics
        });
      }
      
      return summaries;
      
    } catch (error) {
      logger.error('Failed to summarize newsletters:', error);
      throw error;
    }
  }
  
  // Generate simple summary from text
  private generateSimpleSummary(text: string, maxLength: number): string {
    if (!text) {
      return 'No content available to summarize.';
    }
    
    // Split by sentences
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
    
    let summary = '';
    let currentLength = 0;
    
    for (const sentence of sentences) {
      if (currentLength + sentence.length <= maxLength) {
        summary += sentence;
        currentLength += sentence.length;
      } else {
        break;
      }
    }
    
    return summary || text.substring(0, maxLength);
  }
  
  // Extract key topics from text
  private extractKeyTopics(subject: string, text: string): string[] {
    const combinedText = `${subject} ${text}`;
    
    // Simple extraction of capitalized words and phrases
    const words = combinedText.split(/\s+/);
    const topics = new Set<string>();
    
    for (const word of words) {
      // Check if word starts with capital letter and is at least 3 characters
      if (word.length >= 3 && /^[A-Z][a-z]+$/.test(word)) {
        topics.add(word);
      }
    }
    
    // Extract phrases (adjacent capitalized words)
    const phrases = combinedText.match(/[A-Z][a-z]+(\s+[A-Z][a-z]+)+/g) || [];
    for (const phrase of phrases) {
      topics.add(phrase);
    }
    
    return Array.from(topics).slice(0, 5); // Limit to 5 topics
  }
}
```

## Integration Testing

### 1. End-to-End Flow Test Script

```typescript
// tests/integration/end-to-end-flow.test.ts
import { GmailService } from '../../services/gmail.service';
import { CallController } from '../../controllers/call.controller';
import { NewsletterService } from '../../services/newsletter.service';
import { EmailIntegration, ScanJob, EmailSender, EmailMetadata, Call } from '../../models';
import { sequelize } from '../../config/database';
import { v4 as uuidv4 } from 'uuid';

describe('End-to-End Integration Flow', () => {
  // Test user ID
  const userId = uuidv4();
  
  // Test data
  let integrationId;
  let scanJobId;
  let senderIds = [];
  let emailIds = [];
  let callId;
  
  beforeAll(async () => {
    // Initialize database
    await sequelize.sync({ force: true });
    
    // Create test user integration
    const integration = await EmailIntegration.create({
      user_id: userId,
      provider: 'gmail',
      email: 'test@example.com',
      access_token: 'test_access_token',
      refresh_token: 'test_refresh_token',
      token_expiry: new Date(Date.now() + 3600 * 1000),
      scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
      status: 'connected'
    });
    
    integrationId = integration.id;
  });
  
  afterAll(async () => {
    // Clean up
    await sequelize.close();
  });
  
  test('1. Email Retrieval Flow', async () => {
    // Create scan job
    const job = await ScanJob.create({
      user_id: userId,
      provider: 'gmail',
      status: 'queued',
      progress: 0,
      started_at: new Date()
    });
    
    scanJobId = job.id;
    
    // Mock GmailService
    const gmailService = new GmailService(userId);
    
    // Override initialize method
    gmailService.initialize = jest.fn().mockResolvedValue(true);
    
    // Override scanInbox method
    gmailService.scanInbox = jest.fn().mockImplementation(async (jobId) => {
      // Update job status
      await ScanJob.update({
        status: 'processing',
        progress: 10
      }, {
        where: { id: jobId }
      });
      
      // Create test domains and senders
      const domains = [
        { name: 'example.com', category: 'call-me' },
        { name: 'newsletter.com', category: 'newsletter' },
        { name: 'reminder.com', category: 'remind-me' }
      ];
      
      for (const domain of domains) {
        // Create test senders
        const sender = await EmailSender.create({
          user_id: userId,
          name: `${domain.name.split('.')[0]} Team`,
          email: `info@${domain.name}`,
          domain: domain.name,
          category: domain.category,
          email_count: 3,
          latest_subject: `Latest from ${domain.name}`,
          latest_date: new Date(),
          latest_preview: `This is a preview from ${domain.name}`
        });
        
        senderIds.push(sender.id);
        
        // Create test emails
        for (let i = 0; i < 3; i++) {
          const email = await EmailMetadata.create({
            user_id: userId,
            message_id: `msg_${domain.name}_${i}`,
            thread_id: `thread_${domain.name}_${i}`,
            sender_id: sender.id,
            subject: `Email ${i + 1} from ${domain.name}`,
            received_at: new Date(Date.now() - i * 3600 * 1000),
            snippet: `This is email ${i + 1} from ${domain.name}. It contains important information.`,
            is_read: i > 0,
            has_attachments: i === 1
          });
          
          emailIds.push(email.id);
        }
      }
      
      // Update job status to completed
      await ScanJob.update({
        status: 'completed',
        progress: 100,
        senders_found: 9,
        new_senders: 3,
        completed_at: new Date()
      }, {
        where: { id: jobId }
      });
    });
    
    // Execute scan
    await gmailService.scanInbox(scanJobId);
    
    // Verify results
    const updatedJob = await ScanJob.findByPk(scanJobId);
    expect(updatedJob.status).toBe('completed');
    expect(updatedJob.progress).toBe(100);
    
    const senders = await EmailSender.findAll({
      where: { user_id: userId }
    });
    expect(senders.length).toBe(3);
    
    const emails = await EmailMetadata.findAll({
      where: { user_id: userId }
    });
    expect(emails.length).toBe(9);
  });
  
  test('2. Email Categorization Flow', async () => {
    // Verify categorization
    const callMeSenders = await EmailSender.findAll({
      where: {
        user_id: userId,
        category: 'call-me'
      }
    });
    expect(callMeSenders.length).toBe(1);
    expect(callMeSenders[0].domain).toBe('example.com');
    
    const newsletterSenders = await EmailSender.findAll({
      where: {
        user_id: userId,
        category: 'newsletter'
      }
    });
    expect(newsletterSenders.length).toBe(1);
    expect(newsletterSenders[0].domain).toBe('newsletter.com');
    
    const remindMeSenders = await EmailSender.findAll({
      where: {
        user_id: userId,
        category: 'remind-me'
      }
    });
    expect(remindMeSenders.length).toBe(1);
    expect(remindMeSenders[0].domain).toBe('reminder.com');
  });
  
  test('3. Call Scheduling Flow', async () => {
    // Create call controller
    const callController = new CallController();
    
    // Mock methods
    callController['processUrgentCall'] = jest.fn().mockImplementation(async (callId) => {
      // Update call status
      await Call.update({
        status: 'completed',
        twilio_call_sid: 'test_call_sid',
        audio_url: 'https://example.com/audio.mp3',
        duration_seconds: 45,
        completed_at: new Date()
      }, {
        where: { id: callId }
      });
    });
    
    // Mock request and response
    const req = {
      user: { id: userId },
      body: {
        content: 'This is an urgent test call',
        priority: 'high',
        context: {
          emailIds: [emailIds[0]]
        }
      }
    };
    
    const res = {
      json: jest.fn(),
      status: jest.fn().mockReturnThis()
    };
    
    // Schedule call
    await callController.scheduleUrgentCall(req as any, res as any);
    
    // Verify response
    expect(res.json).toHaveBeenCalled();
    const responseData = res.json.mock.calls[0][0];
    expect(responseData.success).toBe(true);
    expect(responseData.data.call.type).toBe('urgent');
    
    callId = responseData.data.call.id;
    
    // Verify call record
    const call = await Call.findByPk(callId);
    expect(call).not.toBeNull();
    expect(call.status).toBe('completed');
    expect(call.twilio_call_sid).toBe('test_call_sid');
  });
  
  test('4. Newsletter Summarization Flow', async () => {
    // Get newsletter emails
    const newsletterEmails = await EmailMetadata.findAll({
      include: [
        {
          model: EmailSender,
          as: 'sender',
          where: {
            category: 'newsletter'
          }
        }
      ],
      where: {
        user_id: userId
      }
    });
    
    expect(newsletterEmails.length).toBe(3);
    
    // Create newsletter service
    const newsletterService = new NewsletterService();
    
    // Summarize newsletters
    const summaries = await newsletterService.summarizeNewsletters(
      newsletterEmails.map(e => e.id),
      userId
    );
    
    // Verify summaries
    expect(summaries.length).toBe(3);
    expect(summaries[0].summary).toBeDefined();
    expect(summaries[0].keyTopics).toBeDefined();
  });
  
  test('5. End-to-End Flow Verification', async () => {
    // Verify all components are connected
    
    // 1. Check email retrieval and categorization
    const totalEmails = await EmailMetadata.count({
      where: { user_id: userId }
    });
    expect(totalEmails).toBe(9);
    
    // 2. Check call creation and execution
    const calls = await Call.findAll({
      where: { user_id: userId }
    });
    expect(calls.length).toBe(1);
    expect(calls[0].status).toBe('completed');
    
    // 3. Verify email references in call
    const callEmailRefs = await sequelize.query(
      `SELECT * FROM call_email_references WHERE call_id = '${callId}'`,
      { type: sequelize.QueryTypes.SELECT }
    );
    expect(callEmailRefs.length).toBe(1);
    expect(callEmailRefs[0].email_id).toBe(emailIds[0]);
  });
});
```

### 2. Integration Test for Gmail API

```typescript
// tests/integration/gmail-api.test.ts
import { GmailService } from '../../services/gmail.service';
import { EmailIntegration } from '../../models';
import { sequelize } from '../../config/database';
import dotenv from 'dotenv';

dotenv.config();

// This test requires real Gmail API credentials
// It should be run manually with proper setup
describe('Gmail API Integration', () => {
  // Skip tests if no credentials
  const hasCredentials = process.env.GOOGLE_CLIENT_ID && 
                         process.env.GOOGLE_CLIENT_SECRET && 
                         process.env.TEST_REFRESH_TOKEN;
  
  if (!hasCredentials) {
    test.skip('Skipping Gmail API tests - no credentials', () => {});
    return;
  }
  
  const userId = 'test_user';
  let gmailService: GmailService;
  
  beforeAll(async () => {
    // Initialize database
    await sequelize.sync({ force: true });
    
    // Create test integration with real refresh token
    await EmailIntegration.create({
      user_id: userId,
      provider: 'gmail',
      email: 'test@example.com',
      access_token: 'will_be_refreshed',
      refresh_token: process.env.TEST_REFRESH_TOKEN,
      token_expiry: new Date(Date.now() - 1000), // Expired to force refresh
      scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
      status: 'connected'
    });
    
    // Initialize service
    gmailService = new GmailService(userId);
  });
  
  afterAll(async () => {
    await sequelize.close();
  });
  
  test('Should initialize and authenticate with Gmail', async () => {
    const result = await gmailService.initialize();
    expect(result).toBe(true);
  });
  
  test('Should retrieve messages from Gmail', async () => {
    // Ensure initialized
    await gmailService.initialize();
    
    // Create a test scan job
    const scanJobId = 'test_job';
    
    // Mock the database methods to avoid actual DB operations
    const originalScanInbox = gmailService.scanInbox;
    gmailService.scanInbox = async (jobId) => {
      // Get messages but don't save to DB
      const inbox = (gmailService as any).inbox;
      const messages = await inbox.getLatestMessages(5);
      
      return {
        messageCount: messages.length,
        messages: messages.map(m => ({
          from: m.from,
          subject: m.subject,
          receivedOn: m.receivedOn
        }))
      };
    };
    
    // Execute scan
    const result = await gmailService.scanInbox(scanJobId);
    
    // Verify results
    expect(result.messageCount).toBeGreaterThan(0);
    expect(result.messages[0].from).toBeDefined();
    expect(result.messages[0].subject).toBeDefined();
    
    // Restore original method
    gmailService.scanInbox = originalScanInbox;
  });
});
```

### 3. Integration Test for Twilio and ElevenLabs

```typescript
// tests/integration/voice-call.test.ts
import { TwilioService } from '../../services/twilio.service';
import { ElevenLabsService } from '../../services/elevenlabs.service';
import dotenv from 'dotenv';

dotenv.config();

// These tests require real API credentials
// They should be run manually with proper setup
describe('Voice Call Integration', () => {
  // Test ElevenLabs integration
  describe('ElevenLabs Integration', () => {
    // Skip if no API key
    const hasElevenLabsKey = !!process.env.ELEVENLABS_API_KEY;
    
    if (!hasElevenLabsKey) {
      test.skip('Skipping ElevenLabs tests - no API key', () => {});
    } else {
      let elevenLabsService: ElevenLabsService;
      
      beforeAll(() => {
        elevenLabsService = new ElevenLabsService();
      });
      
      test('Should get available voices', async () => {
        const voices = await elevenLabsService.getVoices();
        expect(voices).toBeInstanceOf(Array);
        expect(voices.length).toBeGreaterThan(0);
        expect(voices[0]).toHaveProperty('voice_id');
        expect(voices[0]).toHaveProperty('name');
      });
      
      test('Should generate audio from text', async () => {
        const text = 'This is a test message for PookAi voice synthesis.';
        const audioUrl = await elevenLabsService.generateAudio(text, 'nova');
        
        expect(audioUrl).toMatch(/^https:\/\/storage\.googleapis\.com\//);
        expect(audioUrl).toMatch(/\.mp3$/);
      });
    }
  });
  
  // Test Twilio integration
  describe('Twilio Integration', () => {
    // Skip if no credentials
    const hasTwilioCredentials = process.env.TWILIO_ACCOUNT_SID && 
                                process.env.TWILIO_AUTH_TOKEN && 
                                process.env.TWILIO_PHONE_NUMBER && 
                                process.env.TEST_PHONE_NUMBER;
    
    if (!hasTwilioCredentials) {
      test.skip('Skipping Twilio tests - no credentials', () => {});
    } else {
      let twilioService: TwilioService;
      
      beforeAll(() => {
        twilioService = new TwilioService();
      });
      
      test('Should generate valid TwiML', () => {
        const audioUrl = 'https://example.com/audio.mp3';
        const twiml = twilioService.generateTwiML(audioUrl);
        
        expect(twiml).toContain('<?xml version="1.0" encoding="UTF-8"?>');
        expect(twiml).toContain('<Response>');
        expect(twiml).toContain(`<Play>${audioUrl}</Play>`);
        expect(twiml).toContain('</Response>');
      });
      
      // This test will make an actual phone call - use with caution
      test.skip('Should initiate a call', async () => {
        const audioUrl = 'https://demo.twilio.com/docs/classic.mp3'; // Twilio demo audio
        const to = process.env.TEST_PHONE_NUMBER;
        const callId = 'test_call';
        
        const callSid = await twilioService.initiateCall(to, audioUrl, callId);
        
        expect(callSid).toMatch(/^CA/);
      });
    }
  });
});
```

## Potential Issues and Solutions

### 1. Gmail API Limitations

```typescript
// server/src/utils/rate-limiter.ts
import { Redis } from 'ioredis';
import { logger } from './logger';

export class RateLimiter {
  private redis: Redis;
  private namespace: string;
  
  constructor(namespace: string) {
    this.redis = new Redis(process.env.REDIS_URL);
    this.namespace = namespace;
  }
  
  // Check if operation is allowed
  async isAllowed(key: string, limit: number, windowSeconds: number): Promise<boolean> {
    const redisKey = `${this.namespace}:${key}`;
    
    // Get current count
    const count = await this.redis.get(redisKey);
    
    if (!count) {
      // First operation, set to 1 with expiry
      await this.redis.set(redisKey, 1, 'EX', windowSeconds);
      return true;
    }
    
    const currentCount = parseInt(count, 10);
    
    if (currentCount < limit) {
      // Increment count
      await this.redis.incr(redisKey);
      return true;
    }
    
    return false;
  }
  
  // Wait for rate limit to reset
  async waitForReset(key: string): Promise<void> {
    const redisKey = `${this.namespace}:${key}`;
    
    // Get TTL
    const ttl = await this.redis.ttl(redisKey);
    
    if (ttl > 0) {
      logger.info(`Rate limit reached for ${key}, waiting ${ttl} seconds`);
      return new Promise(resolve => setTimeout(resolve, ttl * 1000));
    }
  }
}

// Usage in GmailService
export class GmailService {
  private rateLimiter: RateLimiter;
  
  constructor(userId: string) {
    this.userId = userId;
    this.rateLimiter = new RateLimiter('gmail');
  }
  
  async scanInbox(jobId: string) {
    // Check rate limit for user
    const isAllowed = await this.rateLimiter.isAllowed(
      `user:${this.userId}:scan`,
      1, // 1 scan per hour
      3600 // 1 hour window
    );
    
    if (!isAllowed) {
      await ScanJob.update({
        status: 'rate_limited',
        error_message: 'Rate limit reached, try again later'
      }, {
        where: { id: jobId }
      });
      
      throw new Error('Rate limit reached for inbox scanning');
    }
    
    // Continue with scan...
  }
}
```

### 2. Twilio Call Handling

```typescript
// server/src/controllers/call.controller.ts
// Additional methods for call handling

// Retry failed calls
async retryFailedCall(req: Request, res: Response) {
  try {
    const { callId } = req.params;
    const userId = req.user.id;
    
    // Get call details
    const call = await Call.findOne({
      where: {
        id: callId,
        user_id: userId,
        status: 'failed'
      },
      include: [
        {
          model: CallTranscript,
          as: 'transcript'
        }
      ]
    });
    
    if (!call) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'CALL_NOT_FOUND',
          message: 'Failed call not found'
        }
      });
    }
    
    // Reset call status
    await call.update({
      status: 'scheduled',
      scheduled_at: new Date(),
      error_message: null
    });
    
    // Process call
    this.processUrgentCall(call.id);
    
    return res.json({
      success: true,
      data: {
        call: {
          id: call.id,
          status: 'scheduled',
          scheduledAt: call.scheduled_at
        }
      }
    });
  } catch (error) {
    logger.error('Failed to retry call:', error);
    return res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_ERROR',
        message: 'Failed to retry call',
        details: error.message
      }
    });
  }
}

// Handle call feedback
async recordCallFeedback(req: Request, res: Response) {
  try {
    const { callId } = req.params;
    const { rating, feedback } = req.body;
    const userId = req.user.id;
    
    // Validate input
    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_RATING',
          message: 'Rating must be between 1 and 5'
        }
      });
    }
    
    // Get call
    const call = await Call.findOne({
      where: {
        id: callId,
        user_id: userId
      }
    });
    
    if (!call) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'CALL_NOT_FOUND',
          message: 'Call not found'
        }
      });
    }
    
    // Update call with feedback
    await call.update({
      user_rating: rating,
      user_feedback: feedback || null
    });
    
    return res.json({
      success: true,
      data: {
        call: {
          id: call.id,
          rating,
          feedback: feedback || null
        }
      }
    });
  } catch (error) {
    logger.error('Failed to record call feedback:', error);
    return res.status(500).json({
      success: false,
      error: {
        code: 'SERVER_ERROR',
        message: 'Failed to record call feedback',
        details: error.message
      }
    });
  }
}
```

### 3. Error Handling and Recovery

```typescript
// server/src/utils/error-handler.ts
import { logger } from './logger';

export class ErrorHandler {
  // Handle API errors with retry
  static async withRetry<T>(
    operation: () => Promise<T>,
    options: {
      retries?: number;
      backoff?: number;
      onRetry?: (error: Error, attempt: number) => void;
    } = {}
  ): Promise<T> {
    const { retries = 3, backoff = 1000, onRetry } = options;
    
    let lastError: Error;
    
    for (let attempt = 1; attempt <= retries + 1; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        
        // Check if we should retry
        if (attempt <= retries) {
          // Calculate backoff with exponential increase
          const delay = backoff * Math.pow(2, attempt - 1);
          
          logger.warn(`Operation failed, retrying in ${delay}ms (attempt ${attempt}/${retries})`, {
            error: error.message,
            stack: error.stack
          });
          
          if (onRetry) {
            onRetry(error, attempt);
          }
          
          // Wait before retrying
          await new Promise(resolve => setTimeout(resolve, delay));
        } else {
          // No more retries
          logger.error(`Operation failed after ${retries} retries`, {
            error: error.message,
            stack: error.stack
          });
          throw error;
        }
      }
    }
    
    throw lastError;
  }
  
  // Handle transaction with rollback
  static async withTransaction<T>(
    sequelize: any,
    operation: (transaction: any) => Promise<T>
  ): Promise<T> {
    const transaction = await sequelize.transaction();
    
    try {
      const result = await operation(transaction);
      await transaction.commit();
      return result;
    } catch (error) {
      await transaction.rollback();
      throw error;
    }
  }
}

// Usage in GmailService
async scanInbox(jobId: string) {
  try {
    // Update job status
    await ScanJob.update({
      status: 'processing',
      progress: 10
    }, {
      where: { id: jobId }
    });
    
    // Get messages with retry
    const messages = await ErrorHandler.withRetry(
      () => this.inbox.getLatestMessages(100),
      {
        retries: 3,
        backoff: 2000,
        onRetry: (error, attempt) => {
          logger.warn(`Failed to get messages, retrying (${attempt}/3)`, {
            error: error.message,
            jobId
          });
        }
      }
    );
    
    // Continue processing...
  } catch (error) {
    // Handle error...
  }
}
```

## Next Steps and Recommendations

### 1. Complete Integration Testing

```typescript
// Complete the integration tests for all components
// Ensure all edge cases are covered
// Test with real data when possible
```

### 2. Add Newsletter Summarization

```typescript
// Implement newsletter summarization using OpenAI API
// Add scheduled digest calls for newsletters
// Create UI for newsletter management
```

### 3. Implement Voice Call Features

```typescript
// Complete Twilio integration
// Add call scheduling and reminders
// Implement call feedback and learning
```

### 4. Optimize for API Limits

```typescript
// Implement rate limiting and quotas
// Add caching for frequently accessed data
// Use batch operations where possible
```

### 5. Enhance Error Handling

```typescript
// Add comprehensive error tracking
// Implement automatic recovery
// Add user notifications for failures
```

## Conclusion

The end-to-end integration flow for PookAi connects Gmail inbox scanning, email categorization, voice synthesis, and call execution into a seamless experience. By implementing the components described in this document, the application will be able to:

1. Authenticate with Gmail and retrieve emails
2. Categorize emails by domain and importance
3. Generate voice transcripts for important emails
4. Schedule and execute calls using Twilio and ElevenLabs
5. Summarize newsletters and provide digest calls

The implementation includes robust error handling, rate limiting, and testing to ensure reliability and performance.
