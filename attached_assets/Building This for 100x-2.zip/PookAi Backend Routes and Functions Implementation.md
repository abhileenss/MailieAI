# PookAi Backend Routes and Functions Implementation

## Overview

This document outlines the implementation of backend routes and functions for the PookAi application, focusing on Gmail integration, email categorization, and external service connections. The implementation follows the API endpoints and database schema designs previously established.

## Project Structure

```
server/
├── config/                 # Configuration files
│   ├── database.ts         # Database connection setup
│   └── auth.ts             # Authentication configuration
├── controllers/            # Route controllers
│   ├── auth.controller.ts  # Authentication endpoints
│   ├── email.controller.ts # Email and sender management
│   ├── domain.controller.ts # Domain bucketing and analysis
│   ├── call.controller.ts  # Call scheduling and management
│   └── integration.controller.ts # External service integrations
├── models/                 # Database models
│   ├── user.model.ts       # User model
│   ├── email.model.ts      # Email-related models
│   ├── call.model.ts       # Call-related models
│   └── integration.model.ts # Integration models
├── services/               # Business logic services
│   ├── gmail.service.ts    # Gmail API integration
│   ├── categorization.service.ts # Email categorization logic
│   ├── twilio.service.ts   # Twilio integration
│   └── elevenlabs.service.ts # ElevenLabs voice generation
├── routes/                 # API route definitions
│   ├── auth.routes.ts      # Authentication routes
│   ├── email.routes.ts     # Email and sender routes
│   ├── call.routes.ts      # Call management routes
│   └── integration.routes.ts # External integration routes
├── middleware/             # Express middleware
│   ├── auth.middleware.ts  # Authentication middleware
│   ├── error.middleware.ts # Error handling middleware
│   └── validation.middleware.ts # Request validation
├── utils/                  # Utility functions
│   ├── logger.ts           # Logging utility
│   ├── error-handler.ts    # Error handling utility
│   └── validators.ts       # Input validation functions
├── types/                  # TypeScript type definitions
│   ├── models.types.ts     # Database model types
│   ├── requests.types.ts   # API request types
│   └── responses.types.ts  # API response types
└── index.ts                # Main application entry point
```

## Core Implementation Components

### 1. Gmail Integration Service

**File: `services/gmail.service.ts`**

```typescript
import { Inbox } from 'gmail-inbox';
import { EmailIntegration, EmailSender, EmailMetadata, ScanJob } from '../models';
import { logger } from '../utils/logger';

export class GmailService {
  private inbox: Inbox | null = null;
  
  constructor(private userId: string) {}
  
  /**
   * Initialize Gmail inbox with stored credentials
   */
  async initialize(): Promise<boolean> {
    try {
      // Get user's Gmail integration from database
      const integration = await EmailIntegration.findOne({
        where: { user_id: this.userId, provider: 'gmail', status: 'connected' }
      });
      
      if (!integration) {
        logger.error(`No active Gmail integration found for user ${this.userId}`);
        return false;
      }
      
      // Create credentials file from stored tokens
      const credentialsPath = `/tmp/gmail-credentials-${this.userId}.json`;
      const tokenPath = `/tmp/gmail-token-${this.userId}.json`;
      
      // Write credentials and token files
      await this.writeCredentialsFile(credentialsPath, integration);
      await this.writeTokenFile(tokenPath, integration);
      
      // Initialize inbox
      this.inbox = new Inbox(credentialsPath, tokenPath);
      await this.inbox.authenticateAccount();
      
      return true;
    } catch (error) {
      logger.error(`Failed to initialize Gmail inbox: ${error.message}`);
      return false;
    }
  }
  
  /**
   * Scan Gmail inbox for senders
   */
  async scanInbox(scanJobId: string): Promise<void> {
    if (!this.inbox) {
      throw new Error('Gmail inbox not initialized');
    }
    
    try {
      // Update scan job status
      await ScanJob.update(
        { status: 'processing', progress: 10 },
        { where: { id: scanJobId } }
      );
      
      // Get latest messages
      const messages = await this.inbox.getLatestMessages();
      
      // Extract unique senders
      const senders = this.extractSendersFromMessages(messages);
      
      // Update scan job progress
      await ScanJob.update(
        { progress: 50 },
        { where: { id: scanJobId } }
      );
      
      // Store senders in database
      const newSenderCount = await this.storeSenders(senders);
      
      // Store email metadata
      await this.storeEmailMetadata(messages);
      
      // Update scan job completion
      await ScanJob.update(
        { 
          status: 'completed', 
          progress: 100,
          senders_found: senders.length,
          new_senders: newSenderCount,
          completed_at: new Date()
        },
        { where: { id: scanJobId } }
      );
      
    } catch (error) {
      // Update scan job with error
      await ScanJob.update(
        { 
          status: 'failed', 
          error_message: error.message,
          completed_at: new Date()
        },
        { where: { id: scanJobId } }
      );
      
      logger.error(`Inbox scan failed: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Find emails from a specific sender
   */
  async findEmailsFromSender(senderId: string, limit: number = 5): Promise<any[]> {
    if (!this.inbox) {
      throw new Error('Gmail inbox not initialized');
    }
    
    try {
      // Get sender details
      const sender = await EmailSender.findOne({
        where: { id: senderId, user_id: this.userId }
      });
      
      if (!sender) {
        throw new Error(`Sender not found: ${senderId}`);
      }
      
      // Create search query
      const searchQuery = {
        from: sender.email,
        maxResults: limit
      };
      
      // Find messages
      const messages = await this.inbox.findMessages(searchQuery);
      
      return messages;
    } catch (error) {
      logger.error(`Failed to find emails from sender: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Extract sender information from messages
   */
  private extractSendersFromMessages(messages: any[]): any[] {
    const senderMap = new Map();
    
    messages.forEach(message => {
      if (!message.from) return;
      
      const email = this.extractEmailFromSender(message.from);
      const name = this.extractNameFromSender(message.from);
      const domain = this.extractDomainFromEmail(email);
      
      if (!senderMap.has(email)) {
        senderMap.set(email, {
          name,
          email,
          domain,
          count: 1,
          latestSubject: message.subject,
          latestDate: message.receivedOn,
          latestPreview: message.snippet,
          category: 'unassigned',
          type: this.guessSenderType(domain, message)
        });
      } else {
        const sender = senderMap.get(email);
        sender.count += 1;
        
        // Update latest message info if this message is newer
        const messageDate = new Date(message.receivedOn);
        const latestDate = new Date(sender.latestDate);
        
        if (messageDate > latestDate) {
          sender.latestSubject = message.subject;
          sender.latestDate = message.receivedOn;
          sender.latestPreview = message.snippet;
        }
      }
    });
    
    return Array.from(senderMap.values());
  }
  
  /**
   * Store senders in database
   */
  private async storeSenders(senders: any[]): Promise<number> {
    let newSenderCount = 0;
    
    for (const sender of senders) {
      // Check if sender already exists
      const existingSender = await EmailSender.findOne({
        where: { user_id: this.userId, email: sender.email }
      });
      
      if (existingSender) {
        // Update existing sender
        await EmailSender.update(
          {
            email_count: sender.count,
            latest_subject: sender.latestSubject,
            latest_date: sender.latestDate,
            latest_preview: sender.latestPreview,
            updated_at: new Date()
          },
          { where: { id: existingSender.id } }
        );
      } else {
        // Create new sender
        await EmailSender.create({
          user_id: this.userId,
          name: sender.name,
          email: sender.email,
          domain: sender.domain,
          category: 'unassigned',
          sender_type: sender.type,
          email_count: sender.count,
          latest_subject: sender.latestSubject,
          latest_date: sender.latestDate,
          latest_preview: sender.latestPreview,
          avatar_url: await this.getAvatarUrl(sender.domain)
        });
        
        newSenderCount++;
      }
      
      // Update domain statistics
      await this.updateDomainStats(sender.domain);
    }
    
    return newSenderCount;
  }
  
  /**
   * Store email metadata in database
   */
  private async storeEmailMetadata(messages: any[]): Promise<void> {
    for (const message of messages) {
      // Find sender
      const senderEmail = this.extractEmailFromSender(message.from);
      const sender = await EmailSender.findOne({
        where: { user_id: this.userId, email: senderEmail }
      });
      
      if (!sender) continue;
      
      // Check if email already exists
      const existingEmail = await EmailMetadata.findOne({
        where: { user_id: this.userId, message_id: message.messageId }
      });
      
      if (!existingEmail) {
        // Create new email metadata
        await EmailMetadata.create({
          user_id: this.userId,
          sender_id: sender.id,
          message_id: message.messageId,
          thread_id: message.threadId,
          subject: message.subject,
          received_at: message.receivedOn,
          snippet: message.snippet,
          is_read: message.labelIds.includes('UNREAD') ? false : true,
          has_attachments: message.labelIds.includes('HAS_ATTACHMENT') ? true : false,
          labels: message.labelIds
        });
      }
    }
  }
  
  /**
   * Update domain statistics
   */
  private async updateDomainStats(domainName: string): Promise<void> {
    // Get all senders for this domain
    const senders = await EmailSender.findAll({
      where: { user_id: this.userId, domain: domainName }
    });
    
    if (senders.length === 0) return;
    
    // Calculate domain statistics
    const totalEmails = senders.reduce((sum, sender) => sum + sender.email_count, 0);
    
    // Calculate category distribution
    const categoryDistribution = {};
    senders.forEach(sender => {
      if (!categoryDistribution[sender.category]) {
        categoryDistribution[sender.category] = 1;
      } else {
        categoryDistribution[sender.category]++;
      }
    });
    
    // Determine domain type based on majority of senders
    const typeCount = {};
    senders.forEach(sender => {
      if (sender.sender_type) {
        if (!typeCount[sender.sender_type]) {
          typeCount[sender.sender_type] = 1;
        } else {
          typeCount[sender.sender_type]++;
        }
      }
    });
    
    let domainType = null;
    let maxCount = 0;
    
    Object.entries(typeCount).forEach(([type, count]) => {
      if (count > maxCount) {
        domainType = type;
        maxCount = count as number;
      }
    });
    
    // Update or create domain record
    const existingDomain = await Domain.findOne({
      where: { user_id: this.userId, domain: domainName }
    });
    
    if (existingDomain) {
      await Domain.update(
        {
          sender_count: senders.length,
          email_count: totalEmails,
          domain_type: domainType,
          category_distribution: categoryDistribution,
          updated_at: new Date()
        },
        { where: { id: existingDomain.id } }
      );
    } else {
      await Domain.create({
        user_id: this.userId,
        domain: domainName,
        sender_count: senders.length,
        email_count: totalEmails,
        domain_type: domainType,
        category_distribution: categoryDistribution
      });
    }
  }
  
  /**
   * Helper methods for processing email data
   */
  private extractEmailFromSender(from: string): string {
    const match = from.match(/<([^>]+)>/);
    return match ? match[1] : from;
  }
  
  private extractNameFromSender(from: string): string | null {
    const match = from.match(/^([^<]+)</);
    return match ? match[1].trim() : null;
  }
  
  private extractDomainFromEmail(email: string): string {
    const parts = email.split('@');
    return parts.length > 1 ? parts[1] : '';
  }
  
  private guessSenderType(domain: string, message: any): string {
    // Simple heuristics to guess sender type
    if (domain.includes('newsletter') || message.subject?.includes('Newsletter')) {
      return 'newsletter';
    }
    
    if (message.subject?.includes('meeting') || message.subject?.includes('calendar')) {
      return 'meeting';
    }
    
    if (domain.includes('stripe') || domain.includes('paypal') || domain.includes('invoice')) {
      return 'tool';
    }
    
    if (message.subject?.includes('offer') || message.subject?.includes('discount') || message.subject?.includes('sale')) {
      return 'promotional';
    }
    
    // Default to personal for unknown types
    return 'personal';
  }
  
  private async getAvatarUrl(domain: string): Promise<string | null> {
    // Try to get logo from clearbit
    return `https://logo.clearbit.com/${domain}`;
  }
  
  /**
   * Write credentials and token files for Gmail API
   */
  private async writeCredentialsFile(path: string, integration: any): Promise<void> {
    // Implementation details for creating credentials file
  }
  
  private async writeTokenFile(path: string, integration: any): Promise<void> {
    // Implementation details for creating token file
  }
}
```

### 2. Email Controller

**File: `controllers/email.controller.ts`**

```typescript
import { Request, Response } from 'express';
import { GmailService } from '../services/gmail.service';
import { EmailSender, ScanJob, Domain, EmailMetadata } from '../models';
import { logger } from '../utils/logger';

export class EmailController {
  /**
   * Get all email senders for the authenticated user
   */
  async getSenders(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { page = 1, limit = 50, category, search } = req.query;
      
      // Build query conditions
      const where: any = { user_id: userId };
      
      if (category) {
        where.category = category;
      }
      
      if (search) {
        where[Op.or] = [
          { name: { [Op.iLike]: `%${search}%` } },
          { email: { [Op.iLike]: `%${search}%` } },
          { domain: { [Op.iLike]: `%${search}%` } }
        ];
      }
      
      // Calculate pagination
      const offset = (Number(page) - 1) * Number(limit);
      
      // Get senders
      const { count, rows } = await EmailSender.findAndCountAll({
        where,
        limit: Number(limit),
        offset,
        order: [['latest_date', 'DESC']]
      });
      
      // Calculate total pages
      const totalPages = Math.ceil(count / Number(limit));
      
      res.json({
        success: true,
        data: {
          senders: rows,
          pagination: {
            page: Number(page),
            limit: Number(limit),
            total: count,
            pages: totalPages
          }
        }
      });
    } catch (error) {
      logger.error(`Failed to get senders: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to retrieve email senders',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Trigger a new email scan
   */
  async scanEmails(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { provider = 'gmail', forceRescan = false } = req.body;
      
      // Check if a scan is already in progress
      const activeScan = await ScanJob.findOne({
        where: {
          user_id: userId,
          status: { [Op.in]: ['queued', 'processing'] }
        }
      });
      
      if (activeScan && !forceRescan) {
        return res.status(409).json({
          success: false,
          error: {
            code: 'SCAN_IN_PROGRESS',
            message: 'A scan is already in progress',
            details: {
              jobId: activeScan.id,
              progress: activeScan.progress
            }
          }
        });
      }
      
      // Create new scan job
      const scanJob = await ScanJob.create({
        user_id: userId,
        status: 'queued',
        progress: 0,
        started_at: new Date()
      });
      
      // Start scan process in background
      this.startScanProcess(userId, scanJob.id, provider);
      
      res.json({
        success: true,
        data: {
          jobId: scanJob.id,
          status: 'processing',
          estimatedCompletion: new Date(Date.now() + 5 * 60 * 1000) // Estimate 5 minutes
        }
      });
    } catch (error) {
      logger.error(`Failed to start email scan: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to start email scan',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Check status of an email scan job
   */
  async getScanStatus(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { jobId } = req.params;
      
      // Get scan job
      const scanJob = await ScanJob.findOne({
        where: {
          id: jobId,
          user_id: userId
        }
      });
      
      if (!scanJob) {
        return res.status(404).json({
          success: false,
          error: {
            code: 'JOB_NOT_FOUND',
            message: 'Scan job not found'
          }
        });
      }
      
      res.json({
        success: true,
        data: {
          jobId: scanJob.id,
          status: scanJob.status,
          progress: scanJob.progress,
          sendersFound: scanJob.senders_found,
          newSenders: scanJob.new_senders,
          error: scanJob.error_message,
          startedAt: scanJob.started_at,
          completedAt: scanJob.completed_at
        }
      });
    } catch (error) {
      logger.error(`Failed to get scan status: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to retrieve scan status',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Update category for a specific sender
   */
  async updateSenderCategory(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { id } = req.params;
      const { category } = req.body;
      
      // Validate category
      const validCategories = ['call-me', 'remind-me', 'keep-quiet', 'why-did-i-signup', 'dont-tell-anyone', 'unassigned'];
      
      if (!validCategories.includes(category)) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_CATEGORY',
            message: 'Invalid category value',
            details: `Category must be one of: ${validCategories.join(', ')}`
          }
        });
      }
      
      // Update sender
      const [updated] = await EmailSender.update(
        { category, updated_at: new Date() },
        { where: { id, user_id: userId } }
      );
      
      if (updated === 0) {
        return res.status(404).json({
          success: false,
          error: {
            code: 'SENDER_NOT_FOUND',
            message: 'Sender not found'
          }
        });
      }
      
      // Get updated sender
      const sender = await EmailSender.findOne({
        where: { id, user_id: userId }
      });
      
      // Update domain statistics
      await this.updateDomainCategoryStats(userId, sender.domain);
      
      res.json({
        success: true,
        data: {
          sender: {
            id: sender.id,
            category: sender.category,
            updatedAt: sender.updated_at
          }
        }
      });
    } catch (error) {
      logger.error(`Failed to update sender category: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to update sender category',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Update categories for multiple senders
   */
  async bulkUpdateSenders(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { updates } = req.body;
      
      if (!Array.isArray(updates)) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Updates must be an array'
          }
        });
      }
      
      // Validate categories
      const validCategories = ['call-me', 'remind-me', 'keep-quiet', 'why-did-i-signup', 'dont-tell-anyone', 'unassigned'];
      
      for (const update of updates) {
        if (!update.senderId || !update.category) {
          return res.status(400).json({
            success: false,
            error: {
              code: 'INVALID_REQUEST',
              message: 'Each update must include senderId and category'
            }
          });
        }
        
        if (!validCategories.includes(update.category)) {
          return res.status(400).json({
            success: false,
            error: {
              code: 'INVALID_CATEGORY',
              message: `Invalid category: ${update.category}`,
              details: `Category must be one of: ${validCategories.join(', ')}`
            }
          });
        }
      }
      
      // Process updates
      const results = [];
      const domainsToUpdate = new Set();
      
      for (const update of updates) {
        try {
          // Update sender
          const [updated] = await EmailSender.update(
            { category: update.category, updated_at: new Date() },
            { where: { id: update.senderId, user_id: userId } }
          );
          
          if (updated === 0) {
            results.push({
              senderId: update.senderId,
              status: 'not_found'
            });
          } else {
            results.push({
              senderId: update.senderId,
              status: 'updated'
            });
            
            // Track domain for stats update
            const sender = await EmailSender.findOne({
              where: { id: update.senderId, user_id: userId }
            });
            
            if (sender) {
              domainsToUpdate.add(sender.domain);
            }
          }
        } catch (error) {
          results.push({
            senderId: update.senderId,
            status: 'error',
            message: error.message
          });
        }
      }
      
      // Update domain statistics
      for (const domain of domainsToUpdate) {
        await this.updateDomainCategoryStats(userId, domain);
      }
      
      // Count successful updates
      const updatedCount = results.filter(r => r.status === 'updated').length;
      
      res.json({
        success: true,
        data: {
          updatedCount,
          results
        }
      });
    } catch (error) {
      logger.error(`Failed to bulk update senders: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to bulk update senders',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Get preview of latest emails from a specific sender
   */
  async getEmailPreview(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { senderId } = req.params;
      const { limit = 5 } = req.query;
      
      // Check if sender exists
      const sender = await EmailSender.findOne({
        where: { id: senderId, user_id: userId }
      });
      
      if (!sender) {
        return res.status(404).json({
          success: false,
          error: {
            code: 'SENDER_NOT_FOUND',
            message: 'Sender not found'
          }
        });
      }
      
      // Get email metadata
      const emails = await EmailMetadata.findAll({
        where: { user_id: userId, sender_id: senderId },
        limit: Number(limit),
        order: [['received_at', 'DESC']]
      });
      
      // Format response
      const formattedEmails = emails.map(email => ({
        id: email.id,
        subject: email.subject,
        receivedAt: email.received_at,
        snippet: email.snippet,
        isRead: email.is_read,
        hasAttachments: email.has_attachments
      }));
      
      res.json({
        success: true,
        data: {
          emails: formattedEmails
        }
      });
    } catch (error) {
      logger.error(`Failed to get email preview: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to retrieve email preview',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Start email scan process in background
   */
  private async startScanProcess(userId: string, jobId: string, provider: string): Promise<void> {
    try {
      // Initialize Gmail service
      const gmailService = new GmailService(userId);
      const initialized = await gmailService.initialize();
      
      if (!initialized) {
        await ScanJob.update(
          { 
            status: 'failed', 
            error_message: 'Failed to initialize Gmail service',
            completed_at: new Date()
          },
          { where: { id: jobId } }
        );
        return;
      }
      
      // Start scan
      await gmailService.scanInbox(jobId);
    } catch (error) {
      logger.error(`Scan process failed: ${error.message}`);
      
      // Update job status
      await ScanJob.update(
        { 
          status: 'failed', 
          error_message: error.message,
          completed_at: new Date()
        },
        { where: { id: jobId } }
      );
    }
  }
  
  /**
   * Update domain category statistics
   */
  private async updateDomainCategoryStats(userId: string, domainName: string): Promise<void> {
    try {
      // Get all senders for this domain
      const senders = await EmailSender.findAll({
        where: { user_id: userId, domain: domainName }
      });
      
      if (senders.length === 0) return;
      
      // Calculate category distribution
      const categoryDistribution = {};
      senders.forEach(sender => {
        if (!categoryDistribution[sender.category]) {
          categoryDistribution[sender.category] = 1;
        } else {
          categoryDistribution[sender.category]++;
        }
      });
      
      // Update domain record
      await Domain.update(
        {
          category_distribution: categoryDistribution,
          updated_at: new Date()
        },
        { where: { user_id: userId, domain: domainName } }
      );
    } catch (error) {
      logger.error(`Failed to update domain category stats: ${error.message}`);
    }
  }
}
```

### 3. Domain Controller

**File: `controllers/domain.controller.ts`**

```typescript
import { Request, Response } from 'express';
import { Domain, EmailSender } from '../models';
import { logger } from '../utils/logger';

export class DomainController {
  /**
   * Get domain-based analysis of email senders
   */
  async getDomainAnalysis(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      
      // Get domains
      const domains = await Domain.findAll({
        where: { user_id: userId },
        order: [['email_count', 'DESC']]
      });
      
      res.json({
        success: true,
        data: {
          domains
        }
      });
    } catch (error) {
      logger.error(`Failed to get domain analysis: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to retrieve domain analysis',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Categorize all senders from a specific domain
   */
  async categorizeDomain(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { domain, category } = req.body;
      
      // Validate category
      const validCategories = ['call-me', 'remind-me', 'keep-quiet', 'why-did-i-signup', 'dont-tell-anyone', 'unassigned'];
      
      if (!validCategories.includes(category)) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_CATEGORY',
            message: 'Invalid category value',
            details: `Category must be one of: ${validCategories.join(', ')}`
          }
        });
      }
      
      // Update all senders for this domain
      const [updatedCount] = await EmailSender.update(
        { category, updated_at: new Date() },
        { where: { user_id: userId, domain } }
      );
      
      // Update domain category distribution
      if (updatedCount > 0) {
        await Domain.update(
          {
            category_distribution: { [category]: updatedCount },
            updated_at: new Date()
          },
          { where: { user_id: userId, domain } }
        );
      }
      
      res.json({
        success: true,
        data: {
          updatedCount,
          domain
        }
      });
    } catch (error) {
      logger.error(`Failed to categorize domain: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to categorize domain',
          details: error.message
        }
      });
    }
  }
}
```

### 4. Call Controller

**File: `controllers/call.controller.ts`**

```typescript
import { Request, Response } from 'express';
import { Call, CallTranscript, CallEmailReference, EmailMetadata, UserPreferences } from '../models';
import { TwilioService } from '../services/twilio.service';
import { ElevenLabsService } from '../services/elevenlabs.service';
import { logger } from '../utils/logger';

export class CallController {
  /**
   * Schedule an immediate call for urgent notifications
   */
  async scheduleUrgentCall(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { content, priority = 'medium', context } = req.body;
      
      // Validate request
      if (!content) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Content is required'
          }
        });
      }
      
      // Get user preferences for voice
      const preferences = await UserPreferences.findOne({
        where: { user_id: userId }
      });
      
      const voiceId = preferences?.voice_preference || 'nova';
      
      // Generate transcript
      const transcript = await CallTranscript.create({
        user_id: userId,
        transcript_text: content,
        voice_id: voiceId
      });
      
      // Schedule call
      const call = await Call.create({
        user_id: userId,
        call_type: 'urgent',
        status: 'scheduled',
        scheduled_at: new Date(Date.now() + 60 * 1000), // Schedule 1 minute from now
        content_summary: content,
        transcript_id: transcript.id
      });
      
      // Link referenced emails if provided
      if (context && context.emailIds && Array.isArray(context.emailIds)) {
        for (const emailId of context.emailIds) {
          await CallEmailReference.create({
            call_id: call.id,
            email_id: emailId
          });
        }
      }
      
      // Start call process in background
      this.processUrgentCall(call.id, userId);
      
      res.json({
        success: true,
        data: {
          call: {
            id: call.id,
            type: call.call_type,
            status: call.status,
            scheduledAt: call.scheduled_at,
            estimatedDuration: Math.ceil(content.split(' ').length / 3) // Rough estimate: 3 words per second
          }
        }
      });
    } catch (error) {
      logger.error(`Failed to schedule urgent call: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to schedule urgent call',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Get preview of next scheduled digest call
   */
  async getNextDigestCall(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      
      // Get user preferences
      const preferences = await UserPreferences.findOne({
        where: { user_id: userId }
      });
      
      // Calculate next call time based on preferred time
      const preferredTime = preferences?.preferred_call_time || '09:00';
      const [hours, minutes] = preferredTime.split(':').map(Number);
      
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(hours, minutes, 0, 0);
      
      // Get content preview
      const callMeItems = await EmailSender.count({
        where: { user_id: userId, category: 'call-me' }
      });
      
      const remindMeItems = await EmailSender.count({
        where: { user_id: userId, category: 'remind-me' }
      });
      
      // Get top senders
      const topSenders = await EmailSender.findAll({
        where: { user_id: userId, category: { [Op.in]: ['call-me', 'remind-me'] } },
        limit: 3,
        order: [['email_count', 'DESC']]
      });
      
      const topSenderNames = topSenders.map(sender => sender.name || sender.domain);
      
      // Get meeting count (placeholder for calendar integration)
      const meetingReminders = 0;
      
      res.json({
        success: true,
        data: {
          nextCall: {
            scheduledAt: tomorrow,
            contentPreview: {
              callMeItems,
              remindMeItems,
              meetingReminders,
              topSenders: topSenderNames
            },
            estimatedDuration: 180 // 3 minutes estimate
          }
        }
      });
    } catch (error) {
      logger.error(`Failed to get next digest call: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to retrieve next digest call',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Generate call transcript from email content
   */
  async generateTranscript(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { emailIds, callType = 'urgent', voiceId = 'nova' } = req.body;
      
      if (!emailIds || !Array.isArray(emailIds) || emailIds.length === 0) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Email IDs are required'
          }
        });
      }
      
      // Get emails
      const emails = await EmailMetadata.findAll({
        where: {
          id: { [Op.in]: emailIds },
          user_id: userId
        },
        include: [
          {
            model: EmailSender,
            as: 'sender'
          }
        ]
      });
      
      if (emails.length === 0) {
        return res.status(404).json({
          success: false,
          error: {
            code: 'EMAILS_NOT_FOUND',
            message: 'No emails found with the provided IDs'
          }
        });
      }
      
      // Generate transcript based on call type
      let transcript = '';
      
      if (callType === 'urgent') {
        transcript = this.generateUrgentTranscript(emails);
      } else if (callType === 'digest') {
        transcript = this.generateDigestTranscript(emails);
      } else {
        transcript = this.generateMeetingReminderTranscript(emails);
      }
      
      // Calculate metrics
      const wordCount = transcript.split(' ').length;
      const estimatedDuration = Math.ceil(wordCount / 3); // Rough estimate: 3 words per second
      
      res.json({
        success: true,
        data: {
          transcript,
          estimatedDuration,
          wordCount
        }
      });
    } catch (error) {
      logger.error(`Failed to generate transcript: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to generate transcript',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Process urgent call in background
   */
  private async processUrgentCall(callId: string, userId: string): Promise<void> {
    try {
      // Get call details
      const call = await Call.findOne({
        where: { id: callId },
        include: [
          {
            model: CallTranscript,
            as: 'transcript'
          }
        ]
      });
      
      if (!call) {
        logger.error(`Call not found: ${callId}`);
        return;
      }
      
      // Get user preferences
      const preferences = await UserPreferences.findOne({
        where: { user_id: userId }
      });
      
      // Get user phone number (placeholder - would come from user profile)
      const phoneNumber = '+15551234567';
      
      // Generate audio with ElevenLabs
      const elevenLabsService = new ElevenLabsService();
      const audioUrl = await elevenLabsService.generateAudio(
        call.transcript.transcript_text,
        call.transcript.voice_id
      );
      
      // Update transcript with audio URL
      await CallTranscript.update(
        { audio_url: audioUrl },
        { where: { id: call.transcript.id } }
      );
      
      // Initiate call with Twilio
      const twilioService = new TwilioService();
      const twilioCallSid = await twilioService.initiateCall(
        phoneNumber,
        audioUrl,
        callId
      );
      
      // Update call with Twilio SID
      await Call.update(
        { 
          status: 'in-progress',
          twilio_call_sid: twilioCallSid
        },
        { where: { id: callId } }
      );
    } catch (error) {
      logger.error(`Failed to process urgent call: ${error.message}`);
      
      // Update call status to failed
      await Call.update(
        { 
          status: 'failed',
          completed_at: new Date()
        },
        { where: { id: callId } }
      );
    }
  }
  
  /**
   * Generate transcript for urgent call
   */
  private generateUrgentTranscript(emails: any[]): string {
    // Simple implementation - would be more sophisticated in production
    const email = emails[0];
    
    return `Hey there! Quick urgent update: ${email.sender.name || 'A sender'} sent an email with the subject "${email.subject}". Here's a preview: ${email.snippet}. This seemed important based on your preferences, so I wanted to let you know right away.`;
  }
  
  /**
   * Generate transcript for digest call
   */
  private generateDigestTranscript(emails: any[]): string {
    // Simple implementation - would be more sophisticated in production
    const emailSummaries = emails.map(email => 
      `${email.sender.name || email.sender.domain} sent "${email.subject}"`
    ).join('. ');
    
    return `Good morning! Here's your daily email digest. You have ${emails.length} important emails to review. ${emailSummaries}. Would you like me to read any of these in detail?`;
  }
  
  /**
   * Generate transcript for meeting reminder
   */
  private generateMeetingReminderTranscript(emails: any[]): string {
    // Simple implementation - would be more sophisticated in production
    const email = emails[0];
    
    return `Hey there! Just a reminder that you have a meeting coming up based on this email from ${email.sender.name || 'a sender'} with the subject "${email.subject}". It might be starting soon, so I wanted to make sure you're prepared.`;
  }
}
```

### 5. Integration Controller

**File: `controllers/integration.controller.ts`**

```typescript
import { Request, Response } from 'express';
import { EmailIntegration } from '../models';
import { logger } from '../utils/logger';

export class IntegrationController {
  /**
   * Connect user's email account (Gmail, Outlook, etc.)
   */
  async connectEmail(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      const { provider, authCode, redirectUri } = req.body;
      
      // Validate request
      if (!provider || !authCode) {
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Provider and authCode are required'
          }
        });
      }
      
      // Only support Gmail for now
      if (provider !== 'gmail') {
        return res.status(400).json({
          success: false,
          error: {
            code: 'UNSUPPORTED_PROVIDER',
            message: 'Only Gmail is supported at this time'
          }
        });
      }
      
      // Exchange auth code for tokens
      const tokens = await this.exchangeAuthCode(authCode, redirectUri);
      
      // Get user email from tokens
      const userEmail = await this.getUserEmail(tokens.access_token);
      
      // Check if integration already exists
      const existingIntegration = await EmailIntegration.findOne({
        where: {
          user_id: userId,
          provider,
          email: userEmail
        }
      });
      
      if (existingIntegration) {
        // Update existing integration
        await EmailIntegration.update(
          {
            access_token: tokens.access_token,
            refresh_token: tokens.refresh_token,
            token_expiry: new Date(Date.now() + tokens.expires_in * 1000),
            scopes: tokens.scope.split(' '),
            status: 'connected',
            error_message: null,
            updated_at: new Date()
          },
          { where: { id: existingIntegration.id } }
        );
        
        res.json({
          success: true,
          data: {
            integration: {
              id: existingIntegration.id,
              provider,
              email: userEmail,
              status: 'connected',
              connectedAt: new Date()
            }
          }
        });
      } else {
        // Create new integration
        const integration = await EmailIntegration.create({
          user_id: userId,
          provider,
          email: userEmail,
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token,
          token_expiry: new Date(Date.now() + tokens.expires_in * 1000),
          scopes: tokens.scope.split(' '),
          status: 'connected'
        });
        
        res.json({
          success: true,
          data: {
            integration: {
              id: integration.id,
              provider,
              email: userEmail,
              status: 'connected',
              connectedAt: integration.created_at
            }
          }
        });
      }
    } catch (error) {
      logger.error(`Failed to connect email: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'CONNECTION_FAILED',
          message: 'Failed to connect email account',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Check email integration status
   */
  async getEmailStatus(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user.id;
      
      // Get integration
      const integration = await EmailIntegration.findOne({
        where: {
          user_id: userId,
          status: 'connected'
        },
        order: [['updated_at', 'DESC']]
      });
      
      if (!integration) {
        return res.json({
          success: true,
          data: {
            connected: false
          }
        });
      }
      
      // Check if token is expired
      const now = new Date();
      const isExpired = integration.token_expiry < now;
      
      if (isExpired) {
        // Try to refresh token
        try {
          const tokens = await this.refreshToken(integration.refresh_token);
          
          // Update integration
          await EmailIntegration.update(
            {
              access_token: tokens.access_token,
              token_expiry: new Date(Date.now() + tokens.expires_in * 1000),
              updated_at: new Date()
            },
            { where: { id: integration.id } }
          );
          
          integration.access_token = tokens.access_token;
          integration.token_expiry = new Date(Date.now() + tokens.expires_in * 1000);
        } catch (error) {
          logger.error(`Failed to refresh token: ${error.message}`);
          
          // Update integration status
          await EmailIntegration.update(
            {
              status: 'error',
              error_message: 'Failed to refresh token',
              updated_at: new Date()
            },
            { where: { id: integration.id } }
          );
          
          return res.json({
            success: true,
            data: {
              connected: false,
              provider: integration.provider,
              email: integration.email,
              status: 'error',
              error: 'Authentication expired'
            }
          });
        }
      }
      
      // Check connection health
      const isHealthy = await this.checkConnectionHealth(integration.access_token);
      
      res.json({
        success: true,
        data: {
          connected: true,
          provider: integration.provider,
          email: integration.email,
          lastSync: integration.last_sync,
          permissions: integration.scopes,
          health: isHealthy ? 'healthy' : 'unhealthy'
        }
      });
    } catch (error) {
      logger.error(`Failed to get email status: ${error.message}`);
      res.status(500).json({
        success: false,
        error: {
          code: 'SERVER_ERROR',
          message: 'Failed to retrieve email status',
          details: error.message
        }
      });
    }
  }
  
  /**
   * Exchange auth code for tokens
   */
  private async exchangeAuthCode(authCode: string, redirectUri: string): Promise<any> {
    // Implementation would use OAuth2 library to exchange code for tokens
    // This is a placeholder for the actual implementation
    return {
      access_token: 'mock_access_token',
      refresh_token: 'mock_refresh_token',
      expires_in: 3600,
      scope: 'https://www.googleapis.com/auth/gmail.readonly'
    };
  }
  
  /**
   * Refresh access token
   */
  private async refreshToken(refreshToken: string): Promise<any> {
    // Implementation would use OAuth2 library to refresh token
    // This is a placeholder for the actual implementation
    return {
      access_token: 'mock_refreshed_access_token',
      expires_in: 3600
    };
  }
  
  /**
   * Get user email from access token
   */
  private async getUserEmail(accessToken: string): Promise<string> {
    // Implementation would call Google API to get user profile
    // This is a placeholder for the actual implementation
    return 'user@example.com';
  }
  
  /**
   * Check connection health
   */
  private async checkConnectionHealth(accessToken: string): Promise<boolean> {
    // Implementation would make a test API call to verify token works
    // This is a placeholder for the actual implementation
    return true;
  }
}
```

### 6. Twilio Service

**File: `services/twilio.service.ts`**

```typescript
import { logger } from '../utils/logger';

export class TwilioService {
  private accountSid: string;
  private authToken: string;
  private phoneNumber: string;
  
  constructor() {
    // Load from environment variables
    this.accountSid = process.env.TWILIO_ACCOUNT_SID || '';
    this.authToken = process.env.TWILIO_AUTH_TOKEN || '';
    this.phoneNumber = process.env.TWILIO_PHONE_NUMBER || '';
    
    if (!this.accountSid || !this.authToken || !this.phoneNumber) {
      logger.warn('Twilio credentials not fully configured');
    }
  }
  
  /**
   * Initiate a call with Twilio
   */
  async initiateCall(toNumber: string, audioUrl: string, callId: string): Promise<string> {
    try {
      // In a real implementation, this would use the Twilio SDK
      // For now, we'll simulate the call initiation
      
      if (!this.accountSid || !this.authToken || !this.phoneNumber) {
        throw new Error('Twilio credentials not configured');
      }
      
      logger.info(`Initiating Twilio call to ${toNumber} with audio ${audioUrl}`);
      
      // Simulate Twilio API call
      // In production, this would be:
      // const twilio = require('twilio')(this.accountSid, this.authToken);
      // const call = await twilio.calls.create({
      //   to: toNumber,
      //   from: this.phoneNumber,
      //   url: `https://api.pookai.com/api/calls/twilio/twiml?audioUrl=${encodeURIComponent(audioUrl)}&callId=${callId}`
      // });
      
      // Simulate a call SID
      const callSid = `CA${Math.random().toString(36).substring(2, 15)}`;
      
      return callSid;
    } catch (error) {
      logger.error(`Failed to initiate Twilio call: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Generate TwiML for call
   */
  generateTwiML(audioUrl: string): string {
    return `
      <?xml version="1.0" encoding="UTF-8"?>
      <Response>
        <Play>${audioUrl}</Play>
        <Pause length="1"/>
        <Say>This is the end of your PookAi update. Have a great day!</Say>
      </Response>
    `;
  }
  
  /**
   * Process call status webhook
   */
  async processStatusWebhook(webhookData: any): Promise<void> {
    try {
      const { CallSid, CallStatus, CallDuration } = webhookData;
      
      logger.info(`Received Twilio status webhook: ${CallSid}, status: ${CallStatus}`);
      
      // Find call by Twilio SID
      const call = await Call.findOne({
        where: { twilio_call_sid: CallSid }
      });
      
      if (!call) {
        logger.warn(`Call not found for Twilio SID: ${CallSid}`);
        return;
      }
      
      // Update call status
      if (CallStatus === 'completed') {
        await Call.update(
          {
            status: 'completed',
            duration_seconds: parseInt(CallDuration, 10),
            completed_at: new Date()
          },
          { where: { id: call.id } }
        );
      } else if (CallStatus === 'failed' || CallStatus === 'busy' || CallStatus === 'no-answer') {
        await Call.update(
          {
            status: 'failed',
            completed_at: new Date()
          },
          { where: { id: call.id } }
        );
      }
    } catch (error) {
      logger.error(`Failed to process Twilio webhook: ${error.message}`);
    }
  }
}
```

### 7. ElevenLabs Service

**File: `services/elevenlabs.service.ts`**

```typescript
import { logger } from '../utils/logger';

export class ElevenLabsService {
  private apiKey: string;
  private apiUrl: string;
  
  constructor() {
    // Load from environment variables
    this.apiKey = process.env.ELEVENLABS_API_KEY || '';
    this.apiUrl = 'https://api.elevenlabs.io/v1';
    
    if (!this.apiKey) {
      logger.warn('ElevenLabs API key not configured');
    }
  }
  
  /**
   * Generate audio from text
   */
  async generateAudio(text: string, voiceId: string = 'nova'): Promise<string> {
    try {
      if (!this.apiKey) {
        throw new Error('ElevenLabs API key not configured');
      }
      
      logger.info(`Generating audio for text: ${text.substring(0, 50)}...`);
      
      // In a real implementation, this would call the ElevenLabs API
      // For now, we'll simulate the audio generation
      
      // Simulate API call
      // In production, this would be:
      // const response = await fetch(`${this.apiUrl}/text-to-speech/${voiceId}`, {
      //   method: 'POST',
      //   headers: {
      //     'xi-api-key': this.apiKey,
      //     'Content-Type': 'application/json'
      //   },
      //   body: JSON.stringify({
      //     text,
      //     model_id: 'eleven_monolingual_v1',
      //     voice_settings: {
      //       stability: 0.5,
      //       similarity_boost: 0.75
      //     }
      //   })
      // });
      
      // Simulate a storage URL
      const audioUrl = `https://storage.pookai.com/audio/call_${Math.random().toString(36).substring(2, 15)}.mp3`;
      
      return audioUrl;
    } catch (error) {
      logger.error(`Failed to generate audio: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Get available voices
   */
  async getVoices(): Promise<any[]> {
    try {
      if (!this.apiKey) {
        throw new Error('ElevenLabs API key not configured');
      }
      
      // In a real implementation, this would call the ElevenLabs API
      // For now, we'll return mock voices
      
      return [
        {
          voice_id: 'nova',
          name: 'Nova',
          description: 'Professional, warm tone',
          gender: 'female'
        },
        {
          voice_id: 'alex',
          name: 'Alex',
          description: 'Clear, authoritative voice',
          gender: 'male'
        },
        {
          voice_id: 'morgan',
          name: 'Morgan',
          description: 'Friendly, conversational',
          gender: 'neutral'
        }
      ];
    } catch (error) {
      logger.error(`Failed to get voices: ${error.message}`);
      throw error;
    }
  }
}
```

### 8. Newsletter Summarization Service

**File: `services/newsletter.service.ts`**

```typescript
import { EmailMetadata, NewsletterSummary } from '../models';
import { logger } from '../utils/logger';

export class NewsletterService {
  /**
   * Summarize newsletter emails
   */
  async summarizeNewsletters(emailIds: string[], userId: string, maxLength: number = 200): Promise<any[]> {
    try {
      // Get emails
      const emails = await EmailMetadata.findAll({
        where: {
          id: { [Op.in]: emailIds },
          user_id: userId
        },
        include: [
          {
            model: EmailSender,
            as: 'sender'
          }
        ]
      });
      
      const summaries = [];
      
      for (const email of emails) {
        // Check if summary already exists
        const existingSummary = await NewsletterSummary.findOne({
          where: { email_id: email.id }
        });
        
        if (existingSummary) {
          summaries.push({
            emailId: email.id,
            subject: email.subject,
            summary: existingSummary.summary_text,
            keyTopics: existingSummary.key_topics
          });
          continue;
        }
        
        // Generate summary
        // In a real implementation, this would use an LLM or similar
        // For now, we'll use a simple approach
        const summary = this.generateSimpleSummary(email.snippet, maxLength);
        const keyTopics = this.extractKeyTopics(email.subject, email.snippet);
        
        // Store summary
        const newSummary = await NewsletterSummary.create({
          user_id: userId,
          email_id: email.id,
          summary_text: summary,
          key_topics: keyTopics
        });
        
        summaries.push({
          emailId: email.id,
          subject: email.subject,
          summary,
          keyTopics
        });
      }
      
      return summaries;
    } catch (error) {
      logger.error(`Failed to summarize newsletters: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Generate a simple summary from text
   */
  private generateSimpleSummary(text: string, maxLength: number): string {
    if (!text) return 'No content available to summarize.';
    
    // Simple approach: truncate and add ellipsis
    if (text.length <= maxLength) return text;
    
    // Find the last complete sentence within maxLength
    const truncated = text.substring(0, maxLength);
    const lastSentenceEnd = Math.max(
      truncated.lastIndexOf('.'),
      truncated.lastIndexOf('!'),
      truncated.lastIndexOf('?')
    );
    
    if (lastSentenceEnd > 0) {
      return truncated.substring(0, lastSentenceEnd + 1);
    }
    
    return truncated + '...';
  }
  
  /**
   * Extract key topics from text
   */
  private extractKeyTopics(subject: string, text: string): string[] {
    // Simple approach: extract nouns and named entities
    // In a real implementation, this would use NLP techniques
    
    const combined = `${subject} ${text}`;
    const words = combined.split(/\s+/);
    
    // Filter for capitalized words (potential topics)
    const potentialTopics = words.filter(word => 
      word.length > 3 && 
      word[0] === word[0].toUpperCase() &&
      word !== word.toUpperCase() // Exclude ALL CAPS words
    );
    
    // Remove duplicates and limit to 5 topics
    return [...new Set(potentialTopics)].slice(0, 5);
  }
}
```

### 9. API Routes

**File: `routes/email.routes.ts`**

```typescript
import { Router } from 'express';
import { EmailController } from '../controllers/email.controller';
import { authMiddleware } from '../middleware/auth.middleware';
import { validationMiddleware } from '../middleware/validation.middleware';

const router = Router();
const emailController = new EmailController();

// Apply authentication middleware to all routes
router.use(authMiddleware);

// Get all email senders
router.get(
  '/senders',
  emailController.getSenders.bind(emailController)
);

// Trigger email scan
router.post(
  '/senders/scan',
  validationMiddleware({
    provider: { type: 'string', optional: true },
    forceRescan: { type: 'boolean', optional: true }
  }),
  emailController.scanEmails.bind(emailController)
);

// Check scan status
router.get(
  '/senders/scan/:jobId',
  emailController.getScanStatus.bind(emailController)
);

// Update sender category
router.put(
  '/senders/:id/category',
  validationMiddleware({
    category: { type: 'string', required: true }
  }),
  emailController.updateSenderCategory.bind(emailController)
);

// Bulk update senders
router.post(
  '/senders/bulk-update',
  validationMiddleware({
    updates: { type: 'array', required: true }
  }),
  emailController.bulkUpdateSenders.bind(emailController)
);

// Get email preview
router.get(
  '/emails/preview/:senderId',
  emailController.getEmailPreview.bind(emailController)
);

export default router;
```

**File: `routes/domain.routes.ts`**

```typescript
import { Router } from 'express';
import { DomainController } from '../controllers/domain.controller';
import { authMiddleware } from '../middleware/auth.middleware';
import { validationMiddleware } from '../middleware/validation.middleware';

const router = Router();
const domainController = new DomainController();

// Apply authentication middleware to all routes
router.use(authMiddleware);

// Get domain analysis
router.get(
  '/domains/analysis',
  domainController.getDomainAnalysis.bind(domainController)
);

// Categorize domain
router.post(
  '/domains/categorize',
  validationMiddleware({
    domain: { type: 'string', required: true },
    category: { type: 'string', required: true }
  }),
  domainController.categorizeDomain.bind(domainController)
);

export default router;
```

**File: `routes/call.routes.ts`**

```typescript
import { Router } from 'express';
import { CallController } from '../controllers/call.controller';
import { authMiddleware } from '../middleware/auth.middleware';
import { validationMiddleware } from '../middleware/validation.middleware';

const router = Router();
const callController = new CallController();

// Apply authentication middleware to all routes (except webhook)
router.use('/twilio/status-webhook', (req, res, next) => next());
router.use(authMiddleware);

// Schedule urgent call
router.post(
  '/calls/schedule-urgent',
  validationMiddleware({
    content: { type: 'string', required: true },
    priority: { type: 'string', optional: true },
    context: { type: 'object', optional: true }
  }),
  callController.scheduleUrgentCall.bind(callController)
);

// Get next digest call
router.get(
  '/calls/next-digest',
  callController.getNextDigestCall.bind(callController)
);

// Generate transcript
router.post(
  '/calls/generate-transcript',
  validationMiddleware({
    emailIds: { type: 'array', required: true },
    callType: { type: 'string', optional: true },
    voiceId: { type: 'string', optional: true }
  }),
  callController.generateTranscript.bind(callController)
);

// Twilio status webhook (no auth)
router.post(
  '/calls/twilio/status-webhook',
  (req, res) => {
    const twilioService = new TwilioService();
    twilioService.processStatusWebhook(req.body)
      .then(() => res.json({ success: true }))
      .catch(error => {
        logger.error(`Webhook processing error: ${error.message}`);
        res.status(500).json({ success: false });
      });
  }
);

export default router;
```

**File: `routes/integration.routes.ts`**

```typescript
import { Router } from 'express';
import { IntegrationController } from '../controllers/integration.controller';
import { authMiddleware } from '../middleware/auth.middleware';
import { validationMiddleware } from '../middleware/validation.middleware';

const router = Router();
const integrationController = new IntegrationController();

// Apply authentication middleware to all routes
router.use(authMiddleware);

// Connect email provider
router.post(
  '/integrations/email/connect',
  validationMiddleware({
    provider: { type: 'string', required: true },
    authCode: { type: 'string', required: true },
    redirectUri: { type: 'string', optional: true }
  }),
  integrationController.connectEmail.bind(integrationController)
);

// Get email integration status
router.get(
  '/integrations/email/status',
  integrationController.getEmailStatus.bind(integrationController)
);

export default router;
```

### 10. Main Application Entry Point

**File: `index.ts`**

```typescript
import express from 'express';
import session from 'express-session';
import { createServer } from 'http';
import { json, urlencoded } from 'body-parser';
import cors from 'cors';
import { errorMiddleware } from './middleware/error.middleware';
import { logger } from './utils/logger';

// Import routes
import emailRoutes from './routes/email.routes';
import domainRoutes from './routes/domain.routes';
import callRoutes from './routes/call.routes';
import integrationRoutes from './routes/integration.routes';
import authRoutes from './routes/auth.routes';

// Create Express app
const app = express();
const httpServer = createServer(app);

// Middleware
app.use(cors());
app.use(json());
app.use(urlencoded({ extended: true }));

// Session middleware
app.use(session({
  secret: process.env.SESSION_SECRET || 'pookai-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// API routes
app.use('/api', authRoutes);
app.use('/api', emailRoutes);
app.use('/api', domainRoutes);
app.use('/api', callRoutes);
app.use('/api', integrationRoutes);

// Error handling middleware
app.use(errorMiddleware);

// Start server
const PORT = process.env.PORT || 5000;
httpServer.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`);
});

export default app;
```

## Implementation Notes

### 1. Gmail Integration

The implementation uses the gmail-inbox library to:
- Authenticate with Gmail API
- Scan inbox for email senders
- Retrieve email metadata
- Search for specific emails

Key considerations:
- OAuth tokens are securely stored in the database
- Token refresh is handled automatically
- Email content is not stored, only metadata
- Sender information is extracted and categorized

### 2. Email Categorization

The implementation provides:
- Sender-based categorization
- Domain-level bucketing
- Category updates (individual and bulk)
- Smart recommendations based on sender patterns

Key considerations:
- Categories align with product requirements
- Domain statistics are updated when categories change
- Bulk operations are supported for efficiency
- Validation ensures categories are valid

### 3. Call Management

The implementation supports:
- Urgent call scheduling
- Digest call previews
- Transcript generation
- Twilio integration for call delivery

Key considerations:
- Calls are processed asynchronously
- Transcripts are generated based on call type
- Audio is generated using ElevenLabs
- Call status is tracked and updated

### 4. External Service Integration

The implementation connects with:
- Gmail API (via gmail-inbox)
- Twilio for call delivery
- ElevenLabs for voice generation

Key considerations:
- Service credentials are loaded from environment variables
- Error handling for service failures
- Webhook support for status updates
- Simulated implementations for development

### 5. Error Handling

The implementation includes:
- Comprehensive error logging
- Structured error responses
- Status code mapping
- Error middleware for centralized handling

### 6. Security Considerations

The implementation addresses:
- Authentication middleware for all routes
- Input validation for all endpoints
- Secure token storage
- Rate limiting (to be implemented)

## Next Steps

1. **Unit Testing**
   - Implement tests for all controllers and services
   - Mock external dependencies
   - Test error handling and edge cases

2. **Gmail API Integration**
   - Complete OAuth flow implementation
   - Test with real Gmail accounts
   - Implement rate limiting and quota management

3. **End-to-End Testing**
   - Test complete email flow from scanning to categorization
   - Test call scheduling and delivery
   - Test newsletter summarization

4. **Deployment**
   - Set up environment variables
   - Configure production database
   - Implement monitoring and logging
